/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : php1

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-09-19 17:38:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for bgk_baogao
-- ----------------------------
DROP TABLE IF EXISTS `bgk_baogao`;
CREATE TABLE `bgk_baogao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(255) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '栏目名称',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `fujian` varchar(255) DEFAULT NULL,
  `isread` int(11) DEFAULT '0',
  `reply` text,
  `tousers` text,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类管理';

-- ----------------------------
-- Records of bgk_baogao
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_caiwu
-- ----------------------------
DROP TABLE IF EXISTS `bgk_caiwu`;
CREATE TABLE `bgk_caiwu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '关联单号',
  `model` varchar(255) DEFAULT NULL,
  `xid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT '',
  `outin` tinyint(4) DEFAULT '1' COMMENT '收入支出 1收 2支',
  `type` varchar(255) DEFAULT '',
  `type1` varchar(255) DEFAULT NULL,
  `type0` varchar(255) DEFAULT NULL,
  `money` decimal(11,2) DEFAULT '0.00',
  `content` text COMMENT '处理结果',
  `szfs` varchar(255) DEFAULT NULL,
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `reason` varchar(255) DEFAULT '',
  `isdel` tinyint(1) DEFAULT '0' COMMENT '1删除  0正常',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='财务管理';

-- ----------------------------
-- Records of bgk_caiwu
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_callrecord
-- ----------------------------
DROP TABLE IF EXISTS `bgk_callrecord`;
CREATE TABLE `bgk_callrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT '0' COMMENT '客户ID',
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT '' COMMENT '类型',
  `state` tinyint(1) DEFAULT NULL,
  `recordfile` text,
  `timing` varchar(255) DEFAULT NULL,
  `stime` datetime DEFAULT NULL,
  `atime` datetime DEFAULT NULL,
  `etime` datetime DEFAULT NULL,
  `devicename` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0正常 1删除',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='通话管理';

-- ----------------------------
-- Records of bgk_callrecord
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_chanpin
-- ----------------------------
DROP TABLE IF EXISTS `bgk_chanpin`;
CREATE TABLE `bgk_chanpin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `class1` varchar(255) DEFAULT '',
  `class2` varchar(255) DEFAULT '',
  `name` varchar(255) DEFAULT '',
  `pic` varchar(255) DEFAULT '0',
  `xinghao` varchar(255) DEFAULT '0',
  `guige` varchar(255) DEFAULT NULL,
  `danwei` varchar(255) DEFAULT NULL,
  `kucun` int(11) DEFAULT NULL,
  `kucunyujing` int(11) DEFAULT NULL,
  `chengben` decimal(11,0) NOT NULL,
  `shoujia` decimal(11,0) DEFAULT NULL,
  `content` text,
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT '',
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `option_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品管理';

-- ----------------------------
-- Records of bgk_chanpin
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_chanpin_class
-- ----------------------------
DROP TABLE IF EXISTS `bgk_chanpin_class`;
CREATE TABLE `bgk_chanpin_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='产品分类';

-- ----------------------------
-- Records of bgk_chanpin_class
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_config
-- ----------------------------
DROP TABLE IF EXISTS `bgk_config`;
CREATE TABLE `bgk_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `value` text,
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bgk_config
-- ----------------------------
INSERT INTO `bgk_config` VALUES ('1', 'config_dom', '', '0');
INSERT INTO `bgk_config` VALUES ('2', 'config_sqm', '3A792FE42117E4B8C9134XU021AD7E93B0369A497F77017889E961524F3XU3C2027BTV8FB0FA56D397ZF4C0XUD87B62A52F3', '0');
INSERT INTO `bgk_config` VALUES ('3', 'call_open', '0', '0');

-- ----------------------------
-- Table structure for bgk_dingdan
-- ----------------------------
DROP TABLE IF EXISTS `bgk_dingdan`;
CREATE TABLE `bgk_dingdan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT '0' COMMENT '客户ID',
  `name` varchar(255) DEFAULT '' COMMENT '客户姓名',
  `linkman` varchar(255) DEFAULT '' COMMENT '联系人',
  `number` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '单据编号',
  `stime` datetime DEFAULT NULL,
  `etime` datetime DEFAULT NULL,
  `money` decimal(11,2) DEFAULT NULL,
  `ysmoney` decimal(11,2) DEFAULT NULL COMMENT '已收款',
  `qkmoney` decimal(11,2) DEFAULT NULL,
  `content` text COMMENT '详情备注',
  `shenhe` varchar(255) DEFAULT '待审',
  `shenhebeizhu` text,
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '1删除  0正常',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单管理';

-- ----------------------------
-- Records of bgk_dingdan
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_dingdan_chanpin
-- ----------------------------
DROP TABLE IF EXISTS `bgk_dingdan_chanpin`;
CREATE TABLE `bgk_dingdan_chanpin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dingdanid` int(11) DEFAULT '0',
  `chanpinid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '' COMMENT '产品名称',
  `pic` varchar(255) DEFAULT NULL,
  `xinghao` varchar(255) DEFAULT NULL,
  `guige` varchar(255) DEFAULT NULL,
  `danwei` varchar(255) DEFAULT NULL,
  `nums` int(11) DEFAULT '0' COMMENT '数量',
  `chengben` decimal(11,0) DEFAULT NULL,
  `shoujia` decimal(11,2) DEFAULT '0.00' COMMENT '单价',
  `zhekou` decimal(11,2) DEFAULT '0.00' COMMENT '折扣',
  `money` decimal(11,2) DEFAULT '0.00' COMMENT '总金额',
  `content` text,
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '1删除  0正常',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单产品';

-- ----------------------------
-- Records of bgk_dingdan_chanpin
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_files
-- ----------------------------
DROP TABLE IF EXISTS `bgk_files`;
CREATE TABLE `bgk_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `xid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `class` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filepath` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `isshare` varchar(255) COLLATE utf8_unicode_ci DEFAULT '否',
  `nowuser` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `adduser` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='在线客服';

-- ----------------------------
-- Records of bgk_files
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_gendan
-- ----------------------------
DROP TABLE IF EXISTS `bgk_gendan`;
CREATE TABLE `bgk_gendan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT '0' COMMENT '客户ID',
  `name` varchar(255) DEFAULT NULL,
  `linkman` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT '' COMMENT '跟单类型',
  `state` varchar(255) DEFAULT '' COMMENT '跟单进度',
  `nexttime` datetime DEFAULT NULL,
  `remind` int(50) DEFAULT '0' COMMENT '提醒',
  `content` text COMMENT '营业项目',
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0正常 1删除',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='跟单管理';

-- ----------------------------
-- Records of bgk_gendan
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_gonggao
-- ----------------------------
DROP TABLE IF EXISTS `bgk_gonggao`;
CREATE TABLE `bgk_gonggao` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(255) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '栏目名称',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `fujian` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类管理';

-- ----------------------------
-- Records of bgk_gonggao
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_gongzi
-- ----------------------------
DROP TABLE IF EXISTS `bgk_gongzi`;
CREATE TABLE `bgk_gongzi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `yuefen` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `cq_t1` decimal(11,2) DEFAULT NULL,
  `cq_t2` decimal(11,2) DEFAULT NULL,
  `cq_t3` decimal(11,2) DEFAULT NULL,
  `cq_t4` decimal(11,2) DEFAULT NULL,
  `cq_t5` decimal(11,2) DEFAULT NULL,
  `cq_t6` decimal(11,2) DEFAULT NULL,
  `yf_t1` decimal(11,2) DEFAULT NULL,
  `yf_t2` decimal(11,2) DEFAULT NULL,
  `yf_t3` decimal(11,2) DEFAULT NULL,
  `yf_t4` decimal(11,2) DEFAULT NULL,
  `yf_t5` decimal(11,2) DEFAULT NULL,
  `yf_t6` decimal(11,2) DEFAULT NULL,
  `yf_t7` decimal(11,2) DEFAULT NULL,
  `yf_t8` decimal(11,2) DEFAULT NULL,
  `yf_t9` decimal(11,2) DEFAULT NULL,
  `yf_t10` decimal(11,2) DEFAULT NULL,
  `yk_t1` decimal(11,2) DEFAULT NULL,
  `yk_t2` decimal(11,2) DEFAULT NULL,
  `yk_t3` decimal(11,2) DEFAULT NULL,
  `yk_t4` decimal(11,2) DEFAULT NULL,
  `yk_t5` decimal(11,2) DEFAULT NULL,
  `yk_t6` decimal(11,2) DEFAULT NULL,
  `qt_t1` decimal(11,2) DEFAULT NULL,
  `qt_t2` decimal(11,2) DEFAULT NULL,
  `qt_t3` decimal(11,2) DEFAULT NULL,
  `shifa` decimal(11,2) DEFAULT NULL,
  `groupid` int(11) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `upduser` varchar(255) DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类管理';

-- ----------------------------
-- Records of bgk_gongzi
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_hetong
-- ----------------------------
DROP TABLE IF EXISTS `bgk_hetong`;
CREATE TABLE `bgk_hetong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT '0' COMMENT '客户ID',
  `name` varchar(255) DEFAULT '' COMMENT '客户姓名',
  `linkman` varchar(11) DEFAULT '' COMMENT '联系人',
  `number` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '单据编号',
  `type` varchar(255) DEFAULT NULL,
  `stime` datetime DEFAULT NULL,
  `etime` datetime DEFAULT NULL,
  `money` decimal(11,2) DEFAULT NULL,
  `ysmoney` decimal(11,2) DEFAULT NULL COMMENT '已收款',
  `qkmoney` decimal(11,2) DEFAULT NULL,
  `content` text COMMENT '详情备注',
  `fujian` text,
  `shenhe` varchar(255) DEFAULT '待审',
  `shenhebeizhu` varchar(255) DEFAULT '',
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '1删除  0正常',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='订单管理';

-- ----------------------------
-- Records of bgk_hetong
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_jiliyu
-- ----------------------------
DROP TABLE IF EXISTS `bgk_jiliyu`;
CREATE TABLE `bgk_jiliyu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(255) DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '栏目名称',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类管理';

-- ----------------------------
-- Records of bgk_jiliyu
-- ----------------------------
INSERT INTO `bgk_jiliyu` VALUES ('1', null, '', '不要轻言放弃，否则对不起自己', '超级管理员', '2019-07-15 00:00:00', '0', null);
INSERT INTO `bgk_jiliyu` VALUES ('2', null, '', '积极思考造就积极人生，消极思考造就消极人生', '超级管理员', '2019-07-15 00:00:00', '0', null);
INSERT INTO `bgk_jiliyu` VALUES ('3', null, '', '无论才能、知识多么卓越，如果缺乏热情，则无异纸上画饼充饥，无补于事', '超级管理员', '2019-07-15 00:00:00', '0', null);
INSERT INTO `bgk_jiliyu` VALUES ('4', null, '', '如果你还可以努力，可以付出，就不要轻言停止和放弃', '超级管理员', '2019-07-15 00:00:00', '0', null);
INSERT INTO `bgk_jiliyu` VALUES ('5', null, '', '顾客后还有顾客，服务的开始才是销售的开始', '超级管理员', '2019-07-15 00:00:00', '0', null);

-- ----------------------------
-- Table structure for bgk_kehu
-- ----------------------------
DROP TABLE IF EXISTS `bgk_kehu`;
CREATE TABLE `bgk_kehu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `weizhi` tinyint(1) DEFAULT '1',
  `name` varchar(255) DEFAULT NULL,
  `chengjiao` varchar(255) DEFAULT '否',
  `type` varchar(255) DEFAULT NULL,
  `linkman` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `area` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `content` text,
  `groupid` int(11) DEFAULT NULL,
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `squser` varchar(255) DEFAULT NULL,
  `sqtime` datetime DEFAULT NULL,
  `olduser` varchar(255) DEFAULT NULL,
  `isshare` varchar(255) DEFAULT '0',
  `share_users` text,
  `drpc` varchar(255) DEFAULT NULL COMMENT '导入批次',
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bgk_kehu
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_linkman
-- ----------------------------
DROP TABLE IF EXISTS `bgk_linkman`;
CREATE TABLE `bgk_linkman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zhu` tinyint(1) DEFAULT NULL,
  `cid` int(11) DEFAULT '0' COMMENT '客户ID',
  `name` varchar(255) DEFAULT NULL,
  `linkman` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '0' COMMENT '联系人',
  `sex` varchar(255) DEFAULT '' COMMENT '性别',
  `job` varchar(255) DEFAULT '' COMMENT '职位',
  `mobile` varchar(255) DEFAULT '' COMMENT '手机号',
  `email` varchar(255) DEFAULT '',
  `qq` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `content` text COMMENT '备注',
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL COMMENT '税率',
  `addtime` datetime DEFAULT NULL,
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '0正常 1删除',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联系人';

-- ----------------------------
-- Records of bgk_linkman
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_mail
-- ----------------------------
DROP TABLE IF EXISTS `bgk_mail`;
CREATE TABLE `bgk_mail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(255) DEFAULT '',
  `email` varchar(255) DEFAULT '' COMMENT '接收邮箱',
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `sendtime` datetime DEFAULT NULL,
  `senduser` varchar(255) DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件管理';

-- ----------------------------
-- Records of bgk_mail
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_menu
-- ----------------------------
DROP TABLE IF EXISTS `bgk_menu`;
CREATE TABLE `bgk_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '导航栏目',
  `parentid` int(11) DEFAULT NULL COMMENT '上级栏目ID',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '栏目名称',
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bgcolor` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `width` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `height` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lever` int(11) DEFAULT NULL,
  `inuse` varchar(255) COLLATE utf8_unicode_ci DEFAULT '是',
  `w_icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `w_class` int(11) DEFAULT NULL,
  `w_ordnum` int(11) DEFAULT NULL,
  `class` int(11) DEFAULT NULL,
  `ordnum` int(11) DEFAULT '50' COMMENT '排序',
  `m_inuse` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `m_class` int(11) DEFAULT NULL,
  `m_ordnum` int(11) DEFAULT NULL,
  `isicon` tinyint(1) DEFAULT NULL,
  `system` int(11) DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `parentId` (`parentid`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=268 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜单管理';

-- ----------------------------
-- Records of bgk_menu
-- ----------------------------
INSERT INTO `bgk_menu` VALUES ('1', '0', '客户管理', 'fa-users', '/index.php/kehu/index', '#44abeb', '#0cb2ff', '', '', '1', '是', '/themes/windows/images/icon/2/01kehu.png', '1', '10', '2', '10', '是', '1', '10', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('2', '1', '新增', '', '', null, null, null, null, '2', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('3', '1', '修改', '', '', null, null, null, null, '3', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('4', '1', '删除', '', '', null, null, null, null, '4', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('5', '1', '共享', '', '', null, null, null, null, '5', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('6', '1', '转移', '', '', null, null, null, null, '6', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('7', '1', '转移到公海', '', '/themes/free.htm', null, null, null, null, '7', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('8', '1', '导入', '', '/themes/free.htm', null, null, null, null, '8', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('9', '1', '导出', '', '/themes/free.htm', null, null, null, null, '9', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('11', '0', '联系人', 'fa-vcard-o', '/index.php/linkman/index', '#44abeb', '#14d3af', '', '', '11', '是', '/themes/windows/images/icon/2/02lianxiren.png', '1', '20', '2', '20', '是', '1', '20', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('12', '11', '新增', '', '', null, null, null, null, '12', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('13', '11', '修改', '', '', null, null, null, null, '13', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('14', '11', '删除', '', '', null, null, null, null, '14', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('15', '11', '导入', '', '/themes/free.htm', null, null, null, null, '15', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('16', '11', '导出', '', '/themes/free.htm', null, null, null, null, '16', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('21', '0', '跟单管理', 'fa-fax', '/index.php/gendan/index', '#44abeb', '#7230cd', '', '', '21', '是', '/themes/windows/images/icon/2/03gendan.png', '1', '30', '2', '30', '是', '1', '30', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('22', '21', '新增', '', '', null, null, null, null, '22', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('23', '21', '修改', '', '', null, null, null, null, '23', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('24', '21', '删除', '', '', null, null, null, null, '24', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('25', '21', '导入', '', '/themes/free.htm', null, null, null, null, '25', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('26', '21', '导出', '', '/themes/free.htm', null, null, null, null, '26', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('31', '0', '订单管理', 'fa-line-chart', '/index.php/dingdan/index', '#44abeb', '#fda621', '', '', '31', '是', '/themes/windows/images/icon/2/04dingdan.png', '1', '40', '2', '40', '是', '1', '35', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('32', '31', '新增', '', '', null, null, null, null, '32', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('33', '31', '修改', '', '', null, null, null, null, '33', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('34', '31', '删除', '', '', null, null, null, null, '34', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('35', '31', '收款', '', '', null, null, null, null, '35', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('36', '31', '审核', '', '', null, null, null, null, '36', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('37', '31', '产品', '', '', null, null, null, null, '37', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('38', '31', '导入', '', '/themes/free.htm', null, null, null, null, '38', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('39', '31', '导出', '', '/themes/free.htm', null, null, null, null, '39', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('41', '0', '合同管理', 'fa-handshake-o', '/index.php/hetong/index', '#44abeb', '#3a91fc', '', '', '41', '是', '/themes/windows/images/icon/2/05hetong.png', '1', '50', '2', '50', '是', '1', '40', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('42', '41', '新增', '', '', null, null, null, null, '42', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('43', '41', '修改', '', '', null, null, null, null, '43', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('44', '41', '删除', '', '', null, null, null, null, '44', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('45', '41', '收款', '', '', null, null, null, null, '45', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('46', '41', '审核', '', '', null, null, null, null, '46', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('47', '41', '续费', '', '', null, null, null, null, '47', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('48', '41', '导入', '', '/themes/free.htm', null, null, null, null, '48', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('49', '41', '导出', '', '/themes/free.htm', null, null, null, null, '49', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('51', '0', '售后管理', 'fa-exclamation-triangle', '/index.php/shouhou/index', '#44abeb', '#fc760a', '', '', '51', '是', '/themes/windows/images/icon/2/06shouhou.png', '1', '60', '2', '60', '是', '1', '50', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('52', '51', '新增', '', '', null, null, null, null, '52', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('53', '51', '修改', '', '', null, null, null, null, '53', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('54', '51', '删除', '', '', null, null, null, null, '54', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('55', '51', '处理', '', '', null, null, null, null, '55', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('56', '51', '审核', '', '', null, null, null, null, '56', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('57', '51', '导入', '', '/themes/free.htm', null, null, null, null, '57', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('58', '51', '导出', '', '/themes/free.htm', null, null, null, null, '58', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('61', '0', '财务管理', 'fa-database', '/index.php/caiwu/index', '#44abeb', '#3cc9b5', '', '', '61', '是', '/themes/windows/images/icon/2/07caiwu.png', '1', '70', '2', '70', '是', '1', '60', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('62', '61', '新增收入', '', '', null, null, null, null, '62', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('63', '61', '新增支出', '', '', null, null, null, null, '63', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('64', '61', '修改', '', '', null, null, null, null, '64', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('65', '61', '删除', '', '', null, null, null, null, '65', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('66', '61', '审核', '', '', null, null, null, null, '66', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('67', '61', '导入', '', '/themes/free.htm', null, null, null, null, '67', '否', null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('68', '61', '导出', '', '/themes/free.htm', null, null, null, null, '68', '否', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('71', '0', '客户公海', 'fa-user-o', '/themes/free.htm', '#44abeb', '#008bf1', '', '', '71', '否', '/themes/windows/images/icon/2/08gonghai.png', '1', '80', '2', '80', '是', '1', '80', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('72', '71', '新增', '', '', null, null, null, null, '72', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('73', '71', '修改', '', '', null, null, null, null, '73', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('74', '71', '删除', '', '', null, null, null, null, '74', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('75', '71', '申请', '', '', null, null, null, null, '75', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('76', '71', '审核', '', '', null, null, null, null, '76', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('77', '71', '导入', '', '', null, null, null, null, '77', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('78', '71', '导出', '', '', null, null, null, null, '78', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('81', '0', '回收站', 'fa-institution', '/index.php/huishouzhan', '#44abeb', '#86a6d9', '', '', '81', '是', '/themes/windows/images/icon/2/09huishouzhan.png', '1', '90', '2', '90', '是', '1', '90', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('82', '81', '恢复数据', '', '', null, null, null, null, '82', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('83', '81', '彻底删除', '', '', null, null, null, null, '83', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('91', '0', '产品列表', 'fa-th', '/index.php/chanpin/index', '#44abeb', '#bd9a69', '', '', '91', '是', '/themes/windows/images/icon/2/10chanpin.png', '1', '100', '3', '10', '是', '3', '50', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('92', '91', '新增', '', '', null, null, null, null, '92', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('93', '91', '修改', '', '', null, null, null, null, '93', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('94', '91', '删除', '', '', null, null, null, null, '94', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('95', '91', '采购', '', '', null, null, null, null, '95', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('101', '0', '产品分类', 'fa-cogs', '/index.php/chanpin/class_', '', null, '', '', '101', '是', '', null, null, null, '20', '是', '3', '60', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('102', '101', '新增', '', '', null, null, null, null, '102', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('103', '101', '修改', '', '', null, null, null, null, '103', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('104', '101', '删除', '', '', null, null, null, null, '104', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('111', '0', '内部公告', 'fa-volume-up', '/index.php/gonggao', '#44abeb', '#ec6b77', '', '', '111', '是', '/themes/windows/images/icon/2/12gonggao.png', '1', '120', '4', '10', '是', '2', '10', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('112', '111', '新增', null, null, null, null, null, null, '112', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('113', '111', '修改', '', '', null, null, null, null, '113', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('114', '111', '删除', '', '', null, null, null, null, '114', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('121', '0', '工作报告', 'fa-flag', '/themes/free.htm', '#44abeb', '#f47c06', '', '', '121', '否', '/themes/windows/images/icon/2/13baogao.png', '1', '130', '4', '20', '是', '2', '20', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('122', '121', '新增', '', '', null, null, null, null, '122', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('123', '121', '修改', '', '', null, null, null, null, '123', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('124', '121', '删除', '', '', null, null, null, null, '124', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('125', '121', '批注', '', '', null, null, null, null, '125', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('131', '0', '文件管理', 'fa-folder-open', '/themes/free.htm', '#44abeb', '#c820fd', '', '', '131', '否', '/themes/windows/images/icon/2/14wenjian.png', '1', '140', '4', '40', '是', '2', '30', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('132', '131', '新增', '', '', null, null, null, null, '132', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('133', '131', '修改', '', '', null, null, null, null, '133', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('134', '131', '删除', '', '', null, null, null, null, '134', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('141', '0', '工资管理', 'fa-cny', '/themes/free.htm', '#44abeb', '#d1997c', '', '', '141', '否', '/themes/windows/images/icon/2/15gongzi.png', '1', '150', '4', '50', '是', '0', '40', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('142', '141', '个人工资', '', '', null, null, null, null, '142', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('143', '141', '所有工资', null, null, null, null, null, null, '143', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('144', '141', '修改数据', '', '', null, null, null, null, '144', null, null, null, null, null, '0', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('151', '0', '邮件管理', 'fa-envelope-square', '/themes/free.htm', '#44abeb', '#c05ed1', '', '', '151', '否', '/themes/windows/images/icon/2/17youjian.png', '1', '170', '4', '70', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('152', '151', '发送', '', '', null, null, null, null, '152', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('153', '151', '删除', '', '', null, null, null, null, '153', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('161', '0', '内部通讯录', 'fa-address-book-o', '/index.php/tongxunlu', '#44abeb', '#78a3bf', '', '', '161', '是', '/themes/windows/images/icon/2/11tongxunlu.png', '1', '110', '4', '30', '是', '2', '50', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('171', '0', '快递查询', 'fa-truck', 'http://www.kuaidi100.com/frame/hao123/new.html', null, null, null, null, '171', null, null, '2', '70', null, '70', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('181', '0', '数据统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '181', '否', null, null, null, null, '10', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('182', '181', '数据概况', 'fa-pie-chart', '/themes/free.htm', '#44abeb', '#f3c006', '', '', '182', '否', '/themes/windows/images/icon/2/18gaikuang.png', '1', '180', '5', '10', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('183', '181', '客户统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '183', '否', null, null, null, '5', '20', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('184', '181', '跟单统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '184', '否', null, null, null, '5', '30', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('185', '181', '订单统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '185', '否', null, null, null, '5', '40', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('186', '181', '合同统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '186', '否', null, null, null, '5', '50', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('187', '181', '售后统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '187', '否', null, null, null, '5', '60', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('188', '181', '财务统计', 'fa-pie-chart', '/themes/free.htm', null, null, null, null, '188', '否', null, null, null, '5', '70', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('191', '0', '员工管理', 'fa-user-circle', '/index.php/user/index', '#44abeb', '#008ff0', '', '', '191', '是', '/themes/windows/images/icon/2/19yuangong.png', '1', '190', '6', '10', '是', '3', '10', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('192', '191', '新增', '', '', null, null, null, null, '192', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('193', '191', '修改', '', '', null, null, null, null, '193', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('194', '191', '删除', '', '', null, null, null, null, '194', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('195', '191', '部门设置', 'fa-sitemap', '/index.php/set_group', null, null, null, null, '195', '是', null, '3', '30', '6', '20', '是', '3', '20', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('196', '191', '权限角色', 'fa-check-circle', '/index.php/set_role', null, null, null, null, '196', '是', null, '3', '40', '6', '30', '是', '3', '30', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('197', '191', '导入', '', '', null, null, null, null, '197', null, null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('198', '191', '导出', '', '', null, null, null, null, '198', null, null, null, null, null, '50', null, null, null, null, null, '1');
INSERT INTO `bgk_menu` VALUES ('201', '0', '系统设置', 'fa-cog', '/index.php/setting', null, null, '880', '500', '201', '是', null, '3', '10', '7', '10', '是', '3', '10', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('202', '201', '邮箱设置', 'fa-envelope-o', '/themes/free.htm', null, null, '880', '500', '202', '否', null, '3', '60', '7', '30', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('203', '201', '短信设置', 'fa-commenting-o', '/themes/free.htm', null, null, '880', '500', '203', '否', null, '3', '50', '7', '20', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('204', '201', '自定义菜单', 'fa-television', '/themes/free.htm', null, null, null, null, '204', '否', null, '3', '70', '7', '40', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('205', '204', '新增', '', '', null, null, null, null, '205', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('206', '204', '修改', '', '', null, null, null, null, '206', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('207', '204', '删除', '', '', null, null, null, null, '207', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('208', '201', '自定义字段', 'fa-gears', '/index.php/ziduan/index', null, null, null, null, '208', '是', null, '3', '80', '7', '50', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('209', '208', '新增', '', '', null, null, null, null, '209', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('210', '208', '修改', '', '', null, null, null, null, '210', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('211', '208', '删除', '', '', null, null, null, null, '211', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('221', '0', '控制台', 'fa-home', '/index.php/home/work', '#44abeb', null, '', '', '221', '是', null, null, null, '1', '10', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('222', '221', '消息中心', 'fa-commenting', '/index.php/message', null, null, '880', '500', '222', '是', null, '3', '20', '1', '20', '是', '2', '5', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('223', '222', '新增', '', '', null, null, null, null, '223', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('224', '222', '修改', '', '', null, null, null, null, '224', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('225', '222', '删除', '', '', null, null, null, null, '225', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('226', '221', '个人资料', 'fa-user-circle', '/index.php/user/info', null, null, '880', '500', '226', '是', null, '2', '40', '1', '30', '是', '3', '30', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('227', '221', '登录日志', 'fa-file-text-o', '/index.php/userloginlog', null, null, null, null, '227', '是', null, '2', '50', '1', '40', '是', '3', '70', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('228', '221', '操作日志', 'fa-file-text-o', '/index.php/userlog', null, null, null, null, '228', '是', null, '2', '60', '1', '50', '是', '3', '80', '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('231', '0', '帮助中心', '', '', null, null, null, null, '231', '', null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('232', '231', '使用帮助', 'fa-info-circle', 'https://www.kancloud.cn/bgk100/bgkcrm/1201638', null, null, null, null, '232', '是', null, '2', '80', '8', '10', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('233', '231', '问题反馈', 'fa-info-circle', '/index.php/help/feedback', null, null, null, null, '233', '是', null, '2', '90', '8', '20', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('234', '231', '开发团队', 'fa-info-circle', '/index.php/help/team', null, null, null, null, '234', '是', null, '2', '100', '8', '30', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('235', '0', '短信管理', 'fa-envelope-o', '/themes/free.htm', '#44abeb', '#23ad79', '', '', '235', '否', '/themes/windows/images/icon/2/16duanxin.png', '1', '160', '4', '60', null, null, null, '1', '1', '0');
INSERT INTO `bgk_menu` VALUES ('236', '235', '发送', '', '', null, null, null, null, '236', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('237', '235', '删除', '', '', null, null, null, null, '237', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('238', '235', '新增模板', '', '', null, null, null, null, '238', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('239', '235', '修改模板', '', '', null, null, null, null, '239', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('240', '235', '删除模板', '', '', null, null, null, null, '240', null, null, null, null, null, '50', null, null, null, null, null, '0');
INSERT INTO `bgk_menu` VALUES ('250', '0', '其它权限', '', '', null, null, null, null, '250', '', null, null, null, null, '50', null, null, null, null, null, '0');

-- ----------------------------
-- Table structure for bgk_message
-- ----------------------------
DROP TABLE IF EXISTS `bgk_message`;
CREATE TABLE `bgk_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT NULL,
  `xid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL COMMENT '客户ID',
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT '' COMMENT '性别',
  `content` text COMMENT '职位',
  `backurl` text COMMENT '手机号',
  `showtime` datetime DEFAULT NULL,
  `show_web` tinyint(1) DEFAULT '0',
  `show_app` tinyint(1) DEFAULT '0',
  `show_dingding` tinyint(1) DEFAULT '0',
  `show_wechat` tinyint(1) DEFAULT '0',
  `isread` tinyint(1) DEFAULT '0',
  `readtime` datetime DEFAULT NULL,
  `reply` text,
  `replytime` datetime DEFAULT NULL,
  `touser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL COMMENT '税率',
  `addtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '0正常 1删除',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='联系人';

-- ----------------------------
-- Records of bgk_message
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_set_group
-- ----------------------------
DROP TABLE IF EXISTS `bgk_set_group`;
CREATE TABLE `bgk_set_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentid` int(11) DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '栏目名称',
  `zhuguan` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '',
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='分类管理';

-- ----------------------------
-- Records of bgk_set_group
-- ----------------------------
INSERT INTO `bgk_set_group` VALUES ('1', '0', '总经办', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('2', '0', '业务部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('3', '2', '业务一部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('4', '2', '业务二部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('5', '0', '财务部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('6', '0', '渠道招商部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('7', '0', '客服部', '', '0', null);
INSERT INTO `bgk_set_group` VALUES ('12', '5', '77', '', '0', null);

-- ----------------------------
-- Table structure for bgk_set_role
-- ----------------------------
DROP TABLE IF EXISTS `bgk_set_role`;
CREATE TABLE `bgk_set_role` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lever` text COLLATE utf8_unicode_ci,
  `right` int(11) DEFAULT '0' COMMENT '权限值',
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户角色';

-- ----------------------------
-- Records of bgk_set_role
-- ----------------------------
INSERT INTO `bgk_set_role` VALUES ('1', '总经理', '1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,21,22,23,24,25,26,31,32,33,34,35,36,37,38,39,41,42,43,44,45,46,47,48,49,51,52,53,54,55,56,57,58,61,62,63,64,65,66,67,68,71,72,73,74,75,76,77,78,81,82,83,91,92,93,94,95,101,102,103,104,111,112,113,114,121,122,123,124,125,131,132,133,134,141,142,143,144,151,152,153,161,171,181,182,183,184,185,186,187,188,191,192,193,194,195,196,197,198,221,222,226,227,228,231,232,233,234', null, '0', null);
INSERT INTO `bgk_set_role` VALUES ('2', '部门主管', '1,2,3,5,6,7,8,9,11,12,13,15,16,21,22,23,25,26,31,32,33,35,36,37,38,39,41,42,43,45,46,47,48,49,51,52,53,55,56,57,58,61,62,63,64,66,67,68,71,72,73,75,76,77,78,81,82,91,92,93,101,102,103,111,112,113,121,122,123,125,131,132,133,141,142,143,151,152,161,171,181,182,183,184,185,186,187,188,191,192,221,222,226,227,228,231,232,233,234', '0', '0', null);
INSERT INTO `bgk_set_role` VALUES ('3', '业务员', '1,2,3,5,6,7,11,12,13,21,22,23,31,32,33,41,42,43,47,51,52,53,61,62,63,64,71,72,73,74,75,81,91,92,101,102,111,121,122,123,131,132,133,141,142,151,152,161,171,181,182,183,221,222,226,227,228,231,232,233,234', '0', '0', null);
INSERT INTO `bgk_set_role` VALUES ('4', '售后专员', '1,11,21,31,41,51,61,67,71,72,73,81,125,131,141,142,151,161,171,181,182,191,221,222,226,227,228,231,232,233,234', '0', '0', null);
INSERT INTO `bgk_set_role` VALUES ('5', '客服', '1,11,21,31,41,51,61,111,121,122,123,131,132,133,141,142,161,171,181,221,222,226,227,228,231,232,233,234', '0', '0', null);

-- ----------------------------
-- Table structure for bgk_shouhou
-- ----------------------------
DROP TABLE IF EXISTS `bgk_shouhou`;
CREATE TABLE `bgk_shouhou` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT '0',
  `name` varchar(255) DEFAULT '',
  `linkman` varchar(11) DEFAULT '' COMMENT '联系人',
  `type` varchar(255) DEFAULT '',
  `title` varchar(255) DEFAULT '' COMMENT '反馈主题',
  `content` text COMMENT '处理结果',
  `stime` datetime DEFAULT NULL COMMENT '反馈日期',
  `etime` datetime DEFAULT NULL COMMENT '处理日期',
  `issolve` varchar(255) DEFAULT '否' COMMENT '是否解决',
  `solvecontent` text COMMENT '详情备注',
  `nowuser` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `reason` varchar(255) DEFAULT '',
  `updtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0' COMMENT '1删除  0正常',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='售后服务';

-- ----------------------------
-- Records of bgk_shouhou
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_sms
-- ----------------------------
DROP TABLE IF EXISTS `bgk_sms`;
CREATE TABLE `bgk_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(255) DEFAULT '',
  `mobile` varchar(255) DEFAULT '' COMMENT '接收邮箱',
  `content` text,
  `sendtime` datetime DEFAULT NULL,
  `senduser` varchar(255) DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件管理';

-- ----------------------------
-- Records of bgk_sms
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_sms_log_send
-- ----------------------------
DROP TABLE IF EXISTS `bgk_sms_log_send`;
CREATE TABLE `bgk_sms_log_send` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smsid` int(11) DEFAULT NULL,
  `smsuser` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `mobile` text COLLATE utf8_unicode_ci,
  `content` text COLLATE utf8_unicode_ci,
  `sendurl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sendtime` datetime DEFAULT NULL,
  `backjson` text COLLATE utf8_unicode_ci,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户管理';

-- ----------------------------
-- Records of bgk_sms_log_send
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_sms_template
-- ----------------------------
DROP TABLE IF EXISTS `bgk_sms_template`;
CREATE TABLE `bgk_sms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mbid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `state` tinyint(1) DEFAULT '0',
  `backjson` text,
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='邮件管理';

-- ----------------------------
-- Records of bgk_sms_template
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_theme
-- ----------------------------
DROP TABLE IF EXISTS `bgk_theme`;
CREATE TABLE `bgk_theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT '',
  `yulan` text,
  `bgurl` text COMMENT '大图',
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='主题管理';

-- ----------------------------
-- Records of bgk_theme
-- ----------------------------
INSERT INTO `bgk_theme` VALUES ('1', '1', '/themes/windows/images/bg/bg1_yulan.jpg', '/themes/windows/images/bg/bg1.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('2', '2', '/themes/windows/images/bg/bg2_yulan.jpg', '/themes/windows/images/bg/bg2.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('3', '3', '/themes/windows/images/bg/bg3_yulan.jpg', '/themes/windows/images/bg/bg3.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('4', '4', '/themes/windows/images/bg/bg4_yulan.jpg', '/themes/windows/images/bg/bg4.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('5', '5', '/themes/windows/images/bg/bg5_yulan.jpg', '/themes/windows/images/bg/bg5.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('6', '6', '/themes/windows/images/bg/bg6_yulan.jpg', '/themes/windows/images/bg/bg6.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('7', '7', '/themes/windows/images/bg/bg7_yulan.jpg', '/themes/windows/images/bg/bg7.jpg', '0', null);
INSERT INTO `bgk_theme` VALUES ('8', '8', '/themes/windows/images/bg/bg8_yulan.jpg', '/themes/windows/images/bg/bg8.jpg', '0', null);

-- ----------------------------
-- Table structure for bgk_user
-- ----------------------------
DROP TABLE IF EXISTS `bgk_user`;
CREATE TABLE `bgk_user` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '用户名称',
  `userpwd` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '密码',
  `groupid` int(11) DEFAULT '0',
  `roleid` tinyint(1) DEFAULT '1' COMMENT '角色ID',
  `lever` text COLLATE utf8_unicode_ci COMMENT '权限',
  `manage` text COLLATE utf8_unicode_ci COMMENT '跨部门权限',
  `iszhuguan` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `maxnum` int(11) DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `hasim` char(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '打开im',
  `avatar` text COLLATE utf8_unicode_ci,
  `theme` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `theme_id` int(11) DEFAULT NULL,
  `theme_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` tinyint(1) DEFAULT '1',
  `adduser` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  `deltime` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='用户管理';

-- ----------------------------
-- Records of bgk_user
-- ----------------------------
INSERT INTO `bgk_user` VALUES ('1', '超级管理员', 'admin', '7fef6171469e80d32c0559f88b377245', '1', '0', null, null, '0', '0', '', '', '1', '/themes/default/images/avatar.png', null, null, null, '1', null, '2019-09-19 17:32:12', '0', null);

-- ----------------------------
-- Table structure for bgk_userlog
-- ----------------------------
DROP TABLE IF EXISTS `bgk_userlog`;
CREATE TABLE `bgk_userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) DEFAULT '' COMMENT '数据表模块',
  `xid` int(11) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT '' COMMENT '行为',
  `reason` text COMMENT '原因',
  `ip` varchar(255) DEFAULT '',
  `adduser` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '' COMMENT '企业名称',
  `addtime` datetime DEFAULT NULL COMMENT '写入日期',
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='操作日志';

-- ----------------------------
-- Records of bgk_userlog
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_userloginlog
-- ----------------------------
DROP TABLE IF EXISTS `bgk_userloginlog`;
CREATE TABLE `bgk_userloginlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT '',
  `type` varchar(255) DEFAULT NULL,
  `adduser` varchar(255) DEFAULT '' COMMENT '用户名',
  `addtime` datetime DEFAULT NULL COMMENT '写入日期',
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='登陆日志';

-- ----------------------------
-- Records of bgk_userloginlog
-- ----------------------------

-- ----------------------------
-- Table structure for bgk_ziduan
-- ----------------------------
DROP TABLE IF EXISTS `bgk_ziduan`;
CREATE TABLE `bgk_ziduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `content` text,
  `tip` varchar(255) DEFAULT NULL,
  `maxlimit` int(11) DEFAULT NULL,
  `inuse` varchar(255) DEFAULT NULL,
  `xitong` tinyint(1) DEFAULT '0',
  `guding` tinyint(1) DEFAULT '0',
  `biaodan` tinyint(1) DEFAULT NULL,
  `bitian` tinyint(1) DEFAULT NULL,
  `bd_teshu` tinyint(1) DEFAULT NULL,
  `liebiao` tinyint(1) DEFAULT NULL,
  `lb_teshu` tinyint(1) DEFAULT '0',
  `sousuo` tinyint(1) DEFAULT NULL COMMENT '1 =，2 like，3 datetime',
  `ss_style` tinyint(1) DEFAULT NULL,
  `dao` tinyint(1) DEFAULT '1',
  `ord` int(11) DEFAULT '50',
  `adduser` varchar(255) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `isdel` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bgk_ziduan
-- ----------------------------
INSERT INTO `bgk_ziduan` VALUES ('1', 'kehu', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '1', null, '1', '2', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('2', 'kehu', '是否成交', 'chengjiao', 'yes', '', '', null, '是', '1', '1', '1', '0', null, '1', null, '1', '1', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('3', 'kehu', '客户分类', 'type', 'select', 'A 重点客户|B 普通客户|C 低质量客户|D 开发中', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '1', '1', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('4', 'kehu', '联系人', 'linkman', 'text', '', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '2', '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('5', 'kehu', '手机号码', 'mobile', 'text', '', '', null, '是', '1', '0', '1', '1', '1', '1', null, '1', '2', '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('6', 'kehu', '电子邮箱', 'email', 'text', '', '', null, '是', '1', '0', '1', '0', null, '0', null, '1', '2', '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('7', 'kehu', '所在地区', 'area', 'area', null, null, null, '是', '1', '0', '1', '0', null, '1', null, '1', '2', '1', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('8', 'kehu', '详细地址', 'address', 'text', '', '', null, '是', '1', '0', '1', '0', null, '0', null, null, '2', '1', '6', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('9', 'kehu', '备注', 'content', 'textarea', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('10', 'kehu', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', '', null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('11', 'kehu', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('12', 'kehu', '创建者', 'adduser', 'users', '', '', null, '是', '1', '0', '0', '1', null, '0', null, '1', '0', '0', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('13', 'kehu', '业务员', 'nowuser', 'users', '', '', null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('14', 'linkman', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, null, null, '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('15', 'linkman', '联系人', 'linkman', 'text', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('16', 'linkman', '性别', 'sex', 'select', '先生|女士', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('17', 'linkman', '职位', 'job', 'select', '老板|董事长|总经理|项目负责人|业务员|技术员|未知', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('18', 'linkman', '手机号', 'mobile', 'text', null, null, null, '是', '1', '0', '1', '1', '1', '1', null, null, null, '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('19', 'linkman', '邮箱', 'email', 'text', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('20', 'linkman', 'QQ', 'qq', 'text', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '6', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('21', 'linkman', '生日', 'birthday', 'datetime', 'yyyy-MM-dd', '', null, '是', '1', '0', '1', '0', null, '1', null, null, '3', '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('22', 'linkman', '备注', 'content', 'textarea', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '8', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('23', 'linkman', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, null, '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('24', 'linkman', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, null, '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('25', 'linkman', '创建者', 'adduser', 'users', '', '', null, '是', '1', '0', '0', '1', null, '1', null, '0', '0', '0', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('26', 'linkman', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('27', 'gendan', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, '1', null, '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('28', 'gendan', '跟单联系人', 'linkman', 'linkman', '', '', null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('29', 'gendan', '跟单方式', 'type', 'select', '电话跟进|上门拜访|QQ交谈|Email邮件', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('30', 'gendan', '跟单进度', 'state', 'select', '结束跟单|初次沟通|有意向|考虑购买', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('31', 'gendan', '下次联系', 'nexttime', 'datetime', 'yyyy-MM-dd HH:mm', null, null, '是', '1', '0', '1', '1', '1', '1', null, null, '3', '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('32', 'gendan', '备注', 'content', 'textarea', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('33', 'gendan', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('34', 'gendan', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('35', 'gendan', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '0', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('36', 'gendan', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('37', 'dingdan', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, '1', '2', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('38', 'dingdan', '联系人', 'linkman', 'linkman', '', '', null, '是', '1', '1', '1', '0', null, '1', null, null, '2', '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('39', 'dingdan', '订单编号', 'number', 'text', '', '', null, '是', '1', '0', '1', '1', '1', '1', null, '1', '2', '1', '10', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('40', 'dingdan', '下单日期', 'stime', 'datetime', 'yyyy-MM-dd', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('41', 'dingdan', '交单日期', 'etime', 'datetime', 'yyyy-MM-dd', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('42', 'dingdan', '总金额', 'money', 'money', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('43', 'dingdan', '已收款', 'ysmoney', 'money', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('44', 'dingdan', '欠款', 'qkmoney', 'money', null, null, null, '是', '1', '0', '1', '1', '1', '1', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('45', 'dingdan', '备注', 'content', 'textarea', '', '', null, '是', '1', '0', '1', '0', null, '1', null, '0', null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('46', 'dingdan', '审核', 'shenhe', 'text', null, null, null, '是', '1', '0', '0', '0', null, '1', null, null, '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('47', 'dingdan', '审核备注', 'shenhebeizhu', 'textarea', null, null, null, '是', '1', '0', '0', '0', null, '1', null, null, '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('48', 'dingdan', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('49', 'dingdan', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('50', 'dingdan', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('51', 'dingdan', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('52', 'hetong', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, '1', '2', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('53', 'hetong', '联系人', 'linkman', 'linkman', '', '', null, '是', '1', '1', '1', '0', null, '1', null, null, '2', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('54', 'hetong', '合同分类', 'type', 'select', '买卖|租赁|工程|技术|委托', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '1', '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('55', 'hetong', '合同编号', 'number', 'text', '', '', null, '是', '1', '0', '1', '1', '1', '1', null, '1', '1', '1', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('56', 'hetong', '开始日期', 'stime', 'datetime', 'yyyy-MM-dd', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '3', '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('57', 'hetong', '结束日期', 'etime', 'datetime', 'yyyy-MM-dd', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', '3', '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('58', 'hetong', '合同金额', 'money', 'money', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('59', 'hetong', '已收款', 'ysmoney', 'money', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '6', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('60', 'hetong', '欠款', 'qkmoney', 'money', null, null, null, '是', '1', '0', '1', '1', '1', '1', null, null, '0', '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('61', 'hetong', '备注', 'content', 'textarea', '', '', null, '是', '1', '0', '1', '0', null, '1', null, '0', null, '1', '8', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('62', 'hetong', '附件', 'fujian', 'upload', '', '', null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('63', 'hetong', '审核', 'shenhe', 'text', null, null, null, '是', '1', '0', '0', '1', null, '1', null, null, '1', '1', '9', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('64', 'hetong', '审核备注', 'shenhebeizhu', 'text', null, null, null, '是', '1', '0', '0', '1', null, '1', null, null, '1', '1', '10', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('65', 'hetong', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('66', 'hetong', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('67', 'hetong', '创建者', 'adduser', 'users', '', '', null, '是', '1', '0', '0', '1', null, '0', null, '0', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('68', 'hetong', '操作员', 'nowuser', 'users', '', '', null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('69', 'shouhou', '客户名称', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, '1', null, '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('70', 'shouhou', '联系人', 'linkman', 'linkman', '', '', null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('71', 'shouhou', '问题分类', 'type', 'select', '质量问题|操作问题|其它问题', '', null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('72', 'shouhou', '反馈问题', 'title', 'text', '', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('73', 'shouhou', '问题描述', 'content', 'textarea', '', null, null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('74', 'shouhou', '反馈日期', 'stime', 'datetime', 'yyyy-MM-dd', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', '3', '1', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('75', 'shouhou', '是否处理', 'issolve', 'yes', null, null, null, '是', '1', '0', '1', '0', null, '1', null, '1', null, '1', '6', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('76', 'shouhou', '处理日期', 'etime', 'datetime', 'yyyy-MM-dd', null, null, '是', '1', '0', '1', '0', null, '1', null, '1', '3', '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('77', 'shouhou', '处理结果', 'solvecontent', 'textarea', null, null, null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '8', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('78', 'shouhou', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('79', 'shouhou', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('80', 'shouhou', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('81', 'shouhou', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('82', 'caiwu', '关联客户', 'name', 'text', '', '', null, '是', '1', '1', '1', '1', '1', '0', null, '1', '2', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('83', 'caiwu', '关联项目', 'model', 'text', '', '', null, '是', '1', '0', '1', '0', '1', '0', null, '0', null, '0', '1', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('84', 'caiwu', '关联id', 'xid', 'text', '', '', null, '是', '1', '0', '1', '0', '1', '0', null, '0', null, '0', '2', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('85', 'caiwu', '收入/支出', 'outin', 'yes', null, null, null, '是', '1', '0', '1', '1', '1', '1', '1', '1', '1', '1', '3', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('86', 'caiwu', '收支类别', 'type', 'text', '', '', null, '是', '1', '0', '1', '0', '0', '1', null, '0', null, '1', '4', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('87', 'caiwu', '收入类别', 'type1', 'select', '订单预付款|合同款|维护费|产品续费|其它', '', null, '是', '1', '0', '1', '0', '0', '1', '1', '1', '1', '0', '5', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('88', 'caiwu', '支出类别', 'type0', 'select', '交通费|通讯费|餐饮住宿|赠送礼品|采购|其它', '', null, '是', '1', '0', '1', '0', '0', '1', '1', '1', '1', '0', '6', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('89', 'caiwu', '收支金额', 'money', 'money', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '7', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('90', 'caiwu', '备注', 'content', 'textarea', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, null, '1', '9', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('91', 'caiwu', '收支方式', 'szfs', 'select', '现金|对公账户|支付宝|微信|其它', '', null, '是', '1', '0', '1', '0', '0', '1', '1', '1', '1', '0', '8', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('92', 'caiwu', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('93', 'caiwu', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('94', 'caiwu', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('95', 'caiwu', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('96', 'chanpin', '产品大类', 'class1', 'text', '', '', null, '是', '1', '0', '1', '1', '1', '1', null, null, '1', '1', '0', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('97', 'chanpin', '产品小类', 'class2', 'text', '', '', null, '是', '1', '0', '1', '1', '1', '1', null, null, '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('98', 'chanpin', '产品名称', 'name', 'text', '', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('99', 'chanpin', '缩略图', 'pic', 'upload', '', '', null, '是', '1', '0', '1', '1', '1', '1', '1', null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('100', 'chanpin', '型号', 'xinghao', 'text', null, null, null, '是', '1', '0', '1', '0', null, '1', null, '1', '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('101', 'chanpin', '规格', 'guige', 'text', null, null, null, '是', '1', '0', '1', '0', null, '1', null, '1', '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('102', 'chanpin', '单位', 'danwei', 'text', null, null, null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('103', 'chanpin', '库存数量', 'kucun', 'text', null, null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('104', 'chanpin', '库存预警', 'kucunyujing', 'text', null, null, null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('105', 'chanpin', '成本价', 'chengben', 'text', '', null, null, '是', '1', '0', '1', '0', null, '1', null, null, '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('106', 'chanpin', '售价', 'shoujia', 'text', '', null, null, '是', '1', '0', '1', '1', null, '1', null, null, '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('107', 'chanpin', '备注', 'content', 'textarea', '', null, null, '是', '1', '0', '1', '0', null, '1', null, null, '2', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('108', 'chanpin', '录入时间', 'addtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('109', 'chanpin', '更新时间', 'updtime', 'datetime', 'yyyy-MM-dd HH:mm:ss', null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('110', 'chanpin', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('111', 'chanpin', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '99999', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('112', 'files', '模型', 'model', 'text', null, null, null, '是', '1', '0', '1', '1', '1', '0', null, null, null, '1', '100', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('113', 'files', '关联id', 'xid', 'text', null, null, null, '是', '1', '0', '1', '1', '1', '0', null, null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('114', 'files', '文件分类', 'class', 'select', '我的文件|工作存档', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('115', 'files', '文件路径', 'filepath', 'upload', null, null, null, '是', '1', '0', '1', '1', null, '1', '1', null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('116', 'files', '文件名称', 'title', 'text', null, null, null, '是', '1', '0', '1', '1', null, '1', null, '1', '20', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('117', 'files', '文件备注', 'content', 'textarea', null, null, null, '是', '1', '0', '1', '0', null, '1', null, null, null, '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('118', 'files', '是否共享', 'isshare', 'yes', null, null, null, '是', '1', '0', '1', '1', null, '1', null, '1', '1', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('119', 'files', '录入时间', 'addtime', 'datetime', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('120', 'files', '更新时间', 'updtime', 'datetime', null, null, null, '是', '1', '0', '0', '1', null, '0', null, '1', '3', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('121', 'files', '创建者', 'adduser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '0', null, null, '0', '1', '50', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('122', 'files', '业务员', 'nowuser', 'users', null, null, null, '是', '1', '0', '0', '1', null, '1', null, '1', '0', '1', '100', null, null, '0');
INSERT INTO `bgk_ziduan` VALUES ('123', 'gonggao', '公告分类', 'class', 'select', '公司公告|规章制度', null, null, '是', '1', '0', '1', '1', null, '1', null, '1', null, '1', '50', null, null, '0');
