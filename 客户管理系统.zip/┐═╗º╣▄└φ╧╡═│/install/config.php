<?php
$db = array(
'default' =>array(
'hostname'=>'#hostname#',//服务器地址
'username'=>'#username#',//数据库账号
'database'=>'#database#',//数据库名称
'password'=>'#password#',//数据库密码
'hostport'=>'#hostport#',//数据库端口
'dbprefix'=>'#dbprefix#',//数据表前缀
'dbdriver'=>'mysqli',
'pconnect'=>TRUE,
'db_debug'=>TRUE,
'cache_on'=>FALSE,
'cachedir'=>'./data/cache/',
'char_set'=>'utf8',
'dbcollat'=>'utf8_general_ci',
'swap_pre'=>'',
'autoinit'=>TRUE,
'stricton'=>FALSE
)
);
