   //table转ul函数
   $.fn.settable = function () {
    var el=this;
    this.start=function(){
        $(el).find(".m-list").remove();
        $(el).map(function () {
            var list = '';
            var name = [];
            if ($(this).find("th").not(".no-m").length == 0) {
                name = false;
            } else {
                $(this).find("th").not(".no-m").map(function () {
                    name.push($(this).text()); //直接获取文本，以去除a链接
                });
            }
            $(this).find("tbody tr").not(".no-m").map(function () {
                var ul = '<ul class="m-list">';
                $(this).find("td").not(".no-m").map(function (index, item) {
                    if(name) {
                        ul += '<li><span class="m_left">' + name[index] + "</span>" + $(this).html() + '</li>';
                    }else{
                        ul += '<li>' +"&nbsp;" + $(this).html() + '</li>';
                    }
                });
                ul += '</ul>';
                list += ul;
            });
            $(this).find("table").hide();
            $(this).append(list);
        })
    }
    var _this=this;
   $(window).resize(function(){
        if($(window).width()<767){
           _this.start();
           }else{
            $(el).find("table").show();
            $(el).find(".m-list").hide();
        }
    });
    if($(window).width()<767){
        _this.start();
    }
};

