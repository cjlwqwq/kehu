﻿// 布局脚本
/*====================================
 *基于JQuery 1.11.2主框架
====================================*/
//绑定需要浮动的表头
$(function(){
	
    $('.c_timetype').click(function(){
	$("#l_timetype").toggle('slow');
    });
	
    $(".ltable tr:nth-child(odd)").addClass("odd_bg"); //隔行变色
	$(".rule-single-checkbox").ruleSingleCheckbox();
	$(".rule-multi-checkbox").ruleMultiCheckbox();
	$(".rule-multi-radio").ruleMultiRadio();
	$(".rule-single-select").ruleSingleSelect();
	$(".rule-multi-porp").ruleMultiPorp();
	$(".rule-date-input").ruleDateInput();

	
});


//页面加载完成时执行
/*$(function () {
    initContentTab(); //初始化TAB
    $(".content-tab").ruleLayoutTab();
    $(".tab-content").ruleLayoutContent();
    //$(".table-container").ruleLayouttable();
    $(".page-footer").ruleLayoutFooter();
    //窗口尺寸改变时
    $(window).resize(function () {
        //延迟执行,防止多次触发
        setTimeout(function () {
            $(".content-tab").ruleLayoutTab();
            $(".tab-content").ruleLayoutContent();
            //$(".table-container").ruleLayouttable();
            $(".page-footer").ruleLayoutFooter();
        }, 200);
    });
});*/


//内容页TAB表头响应式
$.fn.ruleLayoutTab = function () {
    var fun = function (parentObj) {
        parentObj.removeClass("mini"); //计算前先清除一下样式
        tabWidth = parentObj.width();
        liWidth = 0;
        parentObj.find("ul li").each(function () {
            liWidth += $(this).outerWidth();
        });
        if (liWidth > tabWidth) {
            parentObj.addClass("mini");
        } else {
            parentObj.removeClass("mini");
        }
    };
    return $(this).each(function () {
        fun($(this));
    });
}

//内容页TAB内容响应式
$.fn.ruleLayoutContent = function () {
    var fun = function (parentObj) {
        parentObj.removeClass("mini"); //计算前先清除一下样式
        var contentWidth = $("body").width() - parentObj.find("dl dt").eq(0).outerWidth();
        var dlMaxWidth = 0;
        parentObj.find("dl dd").children().each(function () {
            if ($(this).outerWidth() > dlMaxWidth) {
                dlMaxWidth = $(this).outerWidth();
            }
        });
        parentObj.find("dl dd table").each(function () {
            if (parseFloat($(this).css("min-width")) > dlMaxWidth) {
                dlMaxWidth = parseFloat($(this).css("min-width"));
            }
        });
        if (dlMaxWidth > contentWidth) {
            parentObj.addClass("mini");
        } else {
            parentObj.removeClass("mini");
        }
    };
    return $(this).each(function () {
        fun($(this));
    });
}

//表格处理事件
$.fn.ruleLayouttable = function () {
    var fun = function (parentObj) {
        var tableWidth = parentObj.children("table").outerWidth();
        var minWidth = parseFloat(parentObj.children("table").css("min-width"));
        if (minWidth > tableWidth) {
            parentObj.children("table").width(minWidth);
        } else {
            parentObj.children("table").css("width", "");
        }
    };
    return $(this).each(function () {
        fun($(this));
    });
}

//页面底部按钮事件
$.fn.ruleLayoutFooter = function() {
	var fun = function(parentObj){
		var winHeight = $(window).height();
		var docHeight = $(document).height();
		if(docHeight > winHeight){
			parentObj.find(".btn-wrap").css("position", "fixed");
		}else{
			parentObj.find(".btn-wrap").css("position", "static");
		}
	};
	return $(this).each(function() {
		fun($(this));						 
	});
}

//初始化Tab事件
function initContentTab() {
    var parentObj = $(".content-tab");
    var tabObj = $('<div class="tab-title"><span>' + parentObj.find("ul li a.selected").text()
        + '</span><i class="fa fa-chevron-down"></i></div>');
    parentObj.children().children("ul").before(tabObj);
    parentObj.find("ul li a").click(function () {
        var tabNum = $(this).parent().index("li")
        //设置点击后的切换样式
        $(this).parent().parent().find("li a").removeClass("selected");
        $(this).addClass("selected");
        tabObj.children("span").text($(this).text());
        //根据参数决定显示内容
        $(".tab-content").hide();
        $(".tab-content").eq(tabNum).show();
        $(".page-footer").ruleLayoutFooter();
    });
}

//初始化Tree目录结构
function initCategoryHtml(parentObj, layNum){
    $(parentObj).find('li.layer-'+layNum).each(function(i){
        var liObj = $(this);
        var nextNum = layNum + 1;
        if(liObj.next('.layer-' + nextNum).length>0){
            initCategoryHtml(parentObj, nextNum);
            var newObj = $('<ul></ul>').appendTo(liObj);
            moveCategoryHtml(liObj, newObj, nextNum);
        }
    });
}
function moveCategoryHtml(liObj, newObj, nextNum){
    if(liObj.next('.layer-' + nextNum).length>0){
        liObj.next('.layer-' + nextNum).appendTo(newObj);
        moveCategoryHtml(liObj, newObj, nextNum);
    }
}
//初始化Tree目录事件
$.fn.initCategoryTree = function(isOpen) {
    var fCategoryTree = function(parentObj){
        //遍历所有的UL
        parentObj.find("ul").each(function (i) {
            //遍历UL第一层LI
            $(this).children("li").each(function () {
                var liObj = $(this);
                //判断是否有子菜单和设置距左距离
				var parentIconLenght = liObj.parent().parent().children(".tbody").children(".index").children(".icon").length; //父节点的左距离
                var indexObj = liObj.children(".tbody").children(".index"); //需要树型的目录列
                //设置左距离
                if(parentIconLenght == 0){
                    parentIconLenght = 1;
                }
                for (var n = 0; n <= parentIconLenght; n++) { //注意<=
                    $('<i class="icon"></i>').prependTo(indexObj); //插入到index前面
                }
                //设置按钮和图标
                indexObj.children(".icon").last().addClass("iconfont icon-folder"); //设置最后一个图标
                //如果有下级菜单
                if (liObj.children("ul").length>0) {
                    //如果要求全部展开
                    if(isOpen){
                        indexObj.children(".icon").eq(-2).addClass("expandable iconfont icon-open"); //设置图标展开状态
                    }else{
                        indexObj.children(".icon").eq(-2).addClass("expandable fa fa-plus"); //设置图标闭合状态
                        liObj.children("ul").hide(); //隐藏下级的UL
                    }
					//绑定单击事件
					indexObj.children(".expandable").click(function () {
                        //如果菜单已展开则闭合
                        if($(this).hasClass("icon-open")){
                            //设置自身的右图标为+号
                            $(this).removeClass("icon-open");
                            $(this).addClass("icon-close");
                            //隐藏自身父节点的UL子菜单
                            $(this).parent().parent().parent().children("ul").slideUp(300);
                        }else{
                            //设置自身的右图标为-号
							$(this).removeClass("icon-close");
							$(this).addClass("icon-open");
							//显示自身父节点的UL子菜单
							$(this).parent().parent().parent().children("ul").slideDown(300);
                        }
                    });
                }else{
                    indexObj.children(".icon").eq(-2).addClass("iconfont icon-csac");
                }
            });
            //显示第一个UL
            if (i == 0) {
                $(this).show();
                //展开第一个菜单
                if ($(this).children("li").first().children("ul").length>0) {
					$(this).children("li").first().children(".tbody").children(".index").children(".expandable").removeClass("icon-close");
					$(this).children("li").first().children(".tbody").children(".index").children(".expandable").addClass("icon-open");
					$(this).children("li").first().children("ul").show();
				}
            }
        });
    };
	return $(this).each(function() {
		fCategoryTree($(this));						 
	});
}


//全选取消按钮函数
function checkall(chkobj) {
    if ($(chkobj).text() == "全选") {
        $(chkobj).children("span").text("取消");
        $(".checkall input:enabled").prop("checked", true);
    } else {
        $(chkobj).children("span").text("全选");
        $(".checkall input:enabled").prop("checked", false);
    }
}

//===========================工具类函数============================
//只允许输入数字
function checkNumber(e) {
    var keynum = window.event ? e.keyCode : e.which;
    if ((48 <= keynum && keynum <= 57) || (96 <= keynum && keynum <= 105) || keynum == 8) {
        return true;
    } else {
        return false;
    }
}
//只允许输入小数
function checkForFloat(obj, e) {
    var isOK = false;
    var key = window.event ? e.keyCode : e.which;
    if ((key > 95 && key < 106) || //小键盘上的0到9  
        (key > 47 && key < 60) ||  //大键盘上的0到9  
        (key == 110 && obj.value.indexOf(".") < 0) || //小键盘上的.而且以前没有输入.  
        (key == 190 && obj.value.indexOf(".") < 0) || //大键盘上的.而且以前没有输入.  
         key == 8 || key == 9 || key == 46 || key == 37 || key == 39) {
        isOK = true;
    } else {
        if (window.event) { //IE
            e.returnValue = false;   //event.returnValue=false 效果相同.    
        } else { //Firefox 
            e.preventDefault();
        }
    }  
    return isOK;  
}
//检查短信字数
function checktxt(obj, txtId) {
    var txtCount = $(obj).val().length;
    if (txtCount < 1) {
        return false;
    }
    var smsLength = Math.ceil(txtCount / 62);
    $("#" + txtId).html("您已输入<b>" + txtCount + "</b>个字符，将以<b>" + smsLength + "</b>条短信扣取费用。");
}
//四舍五入函数
function ForDight(Dight, How) {
    Dight = Math.round(Dight * Math.pow(10, How)) / Math.pow(10, How);
    return Dight;
}
//写Cookie
function addCookie(objName, objValue, objHours) {
    var str = objName + "=" + escape(objValue);
    if (objHours>0) {//为0时不设定过期时间，浏览器关闭时cookie自动消失
        var date = new Date();
        var ms = objHours * 3600 * 1000;
        date.setTime(date.getTime() + ms);
        str += "; expires=" + date.toGMTString();
    }
    document.cookie = str;
}

//读Cookie
function getCookie(objName) {//获取指定名称的cookie的值
    var arrStr = document.cookie.split("; ");
    for (var i = 0; i < arrStr.length; i++) {
        var temp = arrStr[i].split("=");
        if (temp[0] == objName) return unescape(temp[1]);
    }
    return "";
}


//========================基于Validform插件========================
//初始化验证表单
$.fn.initValidform = function () {
    var checkValidform = function (formObj) {
        $(formObj).Validform({
            tiptype: function (msg, o, cssctl) {
                /*msg：提示信息;
                o:{obj:*,type:*,curform:*}
                obj指向的是当前验证的表单元素（或表单对象）；
                type指示提示的状态，值为1、2、3、4， 1：正在检测/提交数据，2：通过验证，3：验证失败，4：提示ignore状态；
                curform为当前form对象;
                cssctl:内置的提示信息样式控制函数，该函数需传入两个参数：显示提示信息的对象 和 当前提示的状态（既形参o中的type）；*/
                //全部验证通过提交表单时o.obj为该表单对象;
                if (!o.obj.is("form")) {
                    //定位到相应的Tab页面
                    if (o.obj.is(o.curform.find(".Validform_error:first"))) {
                        var tabobj = o.obj.parents(".tab-content"); //显示当前的选项
                        var tabindex = $(".tab-content").index(tabobj); //显示当前选项索引
                        if (!$(".content-tab ul li").eq(tabindex).children("a").hasClass("selected")) {
                            $(".content-tab ul li a").removeClass("selected");
                            $(".content-tab ul li").eq(tabindex).children("a").addClass("selected");
                            $(".tab-content").hide();
                            tabobj.show();
                        }
                    }
                    //页面上不存在提示信息的标签时，自动创建;
                    if (o.obj.parents(".int_check").find(".Validform_checktip").length == 0) {
                        o.obj.parents(".int_check").append("<span class='Validform_checktip' />");
                        o.obj.parents(".int_check").next().find(".Validform_checktip").remove();
                    }
                    var objtip = o.obj.parents(".int_check").find(".Validform_checktip");
                    cssctl(objtip, o.type);
                    objtip.text(msg);
                }
            },
            showAllError: true
        });
    };
    return $(this).each(function () {
        checkValidform($(this));
    });
}
//======================以上基于Validform插件======================

//智能浮动层函数
$.fn.smartFloat = function() {
	var position = function(element) {
		var obj = element.children("div");
		var top = obj.position().top;
		var pos = obj.css("position");
		$(window).scroll(function() {
			var scrolls = $(this).scrollTop();
			if (scrolls > top) {
				obj.width(element.width());
				element.height(obj.outerHeight());
				if (window.XMLHttpRequest) {
					obj.css({
						position: "fixed",
						top: 0
					});	
				} else {
					obj.css({
						top: scrolls
					});	
				}
			}else {
				obj.css({
					position: pos,
					top: top
				});	
			}
		});
	};
	return $(this).each(function() {
		position($(this));						 
	});
};

//多项选择
$.fn.ruleSingleCheckbox = function () {
    var singleCheckbox = function (parentObj) {
        //查找多项选择
        var checkObj = parentObj.children('input').eq(0);
        //防止重复初始化，删除a标签
        parentObj.children('a').remove();
        //隐藏原生多项选择
        parentObj.children().hide();
        //添加元素及样式
        var newObj = $('<a href="javascript:;">'
		+ '<i class="off">否</i>'
		+ '<i class="on">是</i>'
		+ '</a>').prependTo(parentObj);
        parentObj.addClass("single-checkbox");
        //判断是否选中
        if (checkObj.val() == '是') {
            newObj.addClass("selected");
        }
        //检查控件是否启用
        /*if (checkObj.prop("disabled") == true) {
            newObj.css("cursor", "default");
            return;
        }*/
        //绑定事件
        newObj.click(function () {
            if ($(this).hasClass("selected")) {
                $(this).removeClass("selected");
				checkObj.val("否")
            } else {
                $(this).addClass("selected");
				checkObj.val("是")
            }
            checkObj.trigger("click"); //触发对应的checkbox的click事件
        });
        //绑定反监听事件
        checkObj.on('click', function () {
            if ($(this).val() == '是' && !newObj.hasClass("selected")) {
                newObj.addClass("selected");
            } else if ($(this).val() == '否' && newObj.hasClass("selected")) {
                newObj.removeClass("selected");
            }
        });
    };
    return $(this).each(function () {
        singleCheckbox($(this));
    });
};

//多项多项选择
$.fn.ruleMultiCheckbox = function() {
	var multiCheckbox = function(parentObj){
		parentObj.addClass("multi-checkbox"); //添加样式
        parentObj.children('.boxwrap').remove(); //防止重复初始化
		parentObj.children().hide(); //隐藏内容
		var divObj = $('<div class="boxwrap"></div>').prependTo(parentObj); //前插入一个DIV
		parentObj.find(":checkbox").each(function(){
			var indexNum = parentObj.find(":checkbox").index(this); //当前索引
			var newObj = $('<a href="javascript:;">' + parentObj.find('label').eq(indexNum).text() + '</a>').appendTo(divObj); //查找对应Label创建选项
			if($(this).prop("checked") == true){
				newObj.addClass("selected"); //默认选中
			}
			//检查控件是否启用
			if($(this).prop("disabled") == true){
				newObj.css("cursor","default");
				return;
			}
			//绑定事件
			$(newObj).click(function(){
				if($(this).hasClass("selected")){
					$(this).removeClass("selected");
					//parentObj.find(':checkbox').eq(indexNum).prop("checked",false);
				}else{
					$(this).addClass("selected");
					//parentObj.find(':checkbox').eq(indexNum).prop("checked",true);
				}
				parentObj.find(':checkbox').eq(indexNum).trigger("click"); //触发对应的checkbox的click事件
				//alert(parentObj.find(':checkbox').eq(indexNum).prop("checked"));
			});
		});
	};
	return $(this).each(function() {
		multiCheckbox($(this));						 
	});
}

//多项选项PROP
$.fn.ruleMultiPorp = function() {
	var multiPorp = function(parentObj){
		parentObj.addClass("multi-porp"); //添加样式
        parentObj.children('ul').remove(); //防止重复初始化
		parentObj.children().hide(); //隐藏内容
		var divObj = $('<ul></ul>').prependTo(parentObj); //前插入一个DIV
		parentObj.find(":checkbox").each(function(){
			var indexNum = parentObj.find(":checkbox").index(this); //当前索引
			var liObj = $('<li></li>').appendTo(divObj)
			var newObj = $('<a href="javascript:;">' + parentObj.find('label').eq(indexNum).text() + '</a><i class="fa-check-square-o-mark"></i>').appendTo(liObj); //查找对应Label创建选项
			if($(this).prop("checked") == true){
				liObj.addClass("selected"); //默认选中
			}
			//检查控件是否启用
			if($(this).prop("disabled") == true){
				newObj.css("cursor","default");
				return;
			}
			//绑定事件
			$(newObj).click(function(){
				if($(this).parent().hasClass("selected")){
					$(this).parent().removeClass("selected");
				}else{
					$(this).parent().addClass("selected");
				}
				parentObj.find(':checkbox').eq(indexNum).trigger("click"); //触发对应的checkbox的click事件
				//alert(parentObj.find(':checkbox').eq(indexNum).prop("checked"));
			});
		});
	};
	return $(this).each(function() {
		multiPorp($(this));						 
	});
}

//多项单选
$.fn.ruleMultiRadio = function() {
	var multiRadio = function(parentObj){
		parentObj.addClass("multi-radio"); //添加样式
        parentObj.children('.boxwrap').remove(); //防止重复初始化
		parentObj.children().hide(); //隐藏内容
		var divObj = $('<div class="boxwrap"></div>').prependTo(parentObj); //前插入一个DIV
		parentObj.find('input[type="radio"]').each(function(){
			var indexNum = parentObj.find('input[type="radio"]').index(this); //当前索引
			var newObj = $('<a href="javascript:;">' + parentObj.find('label').eq(indexNum).text() + '</a>').appendTo(divObj); //查找对应Label创建选项
			if($(this).prop("checked") == true){
				newObj.addClass("selected"); //默认选中
			}
			//检查控件是否启用
			if($(this).prop("disabled") == true){
				newObj.css("cursor","default");
				return;
			}
			//绑定事件
			$(newObj).click(function(){
				$(this).siblings().removeClass("selected");
				$(this).addClass("selected");
				parentObj.find('input[type="radio"]').prop("checked",false);
				parentObj.find('input[type="radio"]').eq(indexNum).prop("checked",true);
				parentObj.find('input[type="radio"]').eq(indexNum).trigger("click"); //触发对应的radio的click事件
				//alert(parentObj.find('input[type="radio"]').eq(indexNum).prop("checked"));
			});
		});
	};
	return $(this).each(function() {
		multiRadio($(this));						 
	});
}

//单选下拉框
$.fn.ruleSingleSelect = function () {
    var singleSelect = function (parentObj) {
        if (parentObj.find("select").length == 0) {
            parentObj.remove();
            return false;
        }
        parentObj.addClass("single-select"); //添加样式
        parentObj.children('.boxwrap').remove(); //防止重复初始化
        parentObj.children().hide(); //隐藏内容
        var divObj = $('<div class="boxwrap"></div>').prependTo(parentObj); //前插入一个DIV
        //创建元素
        var titObj = $('<a class="select-tit" href="javascript:;"><span></span><i class="fa fa-chevron-down"></i></a>').appendTo(divObj);
        var itemObj = $('<div class="select-items"><ul></ul></div>').appendTo(divObj);
        var selectObj = parentObj.find("select").eq(0); //取得select对象
        //遍历option选项
        selectObj.find("option").each(function (i) {
            var indexNum = selectObj.find("option").index(this); //当前索引
            var liObj = $('<li>' + $(this).text() + '</li>').appendTo(itemObj.find("ul")); //创建LI
            if ($(this).prop("selected") == true) {
                liObj.addClass("selected");
                titObj.find("span").text($(this).text());
            }
            //检查控件是否启用
            if ($(this).prop("disabled") == true) {
                liObj.css("cursor", "default");
                return;
            }
            //绑定事件
            liObj.click(function () {
                $(this).siblings().removeClass("selected");
                $(this).addClass("selected"); //添加选中样式
                selectObj.find("option").prop("selected", false);
                selectObj.find("option").eq(indexNum).prop("selected", true); //赋值给对应的option
                titObj.find("span").text($(this).text()); //赋值选中值
                itemObj.hide(); //隐藏下拉框
                selectObj.trigger("change"); //触发select的onchange事件
                //alert(selectObj.find("option:selected").text());
            });
        });
        //设置样式
        //titObj.css({ "width": titObj.innerWidth(), "overflow": "hidden" });
        //itemObj.children("ul").css({ "max-height": $(document).height() - titObj.offset().top - 62 });

        //检查控件是否启用
        if (selectObj.prop("disabled") == true) {
            titObj.css("cursor", "default");
            return;
        }
        //绑定单击事件
        titObj.click(function (e) {
            e.stopPropagation();
            if (itemObj.is(":hidden")) {
                //隐藏其它的下位框菜单
                $(".single-select .select-items").hide();
                $(".single-select .arrow").hide();
                //位于其它无素的上面
                itemObj.css("z-index", "1000");
                //显示下拉框
                itemObj.show();
                
                //5.0新增判断下拉框上或下呈现
                if(parentObj.parents('.tab-content').length>0){
                    var tabObj = parentObj.parents('.tab-content');
                    //容器高度-下拉框TOP坐标值-容器TOP坐标值
                    var itemBttomVal = tabObj.innerHeight() - itemObj.offset().top + tabObj.offset().top - 12;
                    if(itemBttomVal < itemObj.height()){
                        var itemTopVal = tabObj.innerHeight() - itemBttomVal - 61;
                        if(itemBttomVal > itemTopVal){
                            itemObj.children('ul').height(itemBttomVal);
                        }else{
                            if(itemTopVal < itemObj.height()){
                                itemObj.children('ul').height(itemTopVal);
                            }
                            if(!parentObj.hasClass('up')){
                                parentObj.addClass("up"); //添加样式
                            }
                        }
                    }
                }
                
            } else {
                //位于其它无素的上面
                itemObj.css("z-index", "");
                //隐藏下拉框
                itemObj.hide();
            }
        });
        //绑定页面点击事件
        $(document).click(function (e) {
            //selectObj.trigger("blur"); //触发select的onblure事件
            itemObj.hide(); //隐藏下拉框
        });
		//绑定页面点击事件2
        $(document).on('change','select',function (e) {
            $(this).trigger("blur"); //触发select的onblure事件
            //itemObj.hide(); //隐藏下拉框
        });
		
		
    };
    return $(this).each(function () {
        singleSelect($(this));
    });
}

//日期控件
$.fn.ruleDateInput = function() {
	var dateInput = function(parentObj){
		parentObj.wrap('<div class="date-input"></div>');
		parentObj.before('<i class="fa fa-calendar"></i>');
	};
	return $(this).each(function() {
		dateInput($(this));						 
	});
}



//增加下拉选项验证


var select_error=$(".int_check").find("span.Validform_wrong").length;

if(select_error>=1){
$(".select-tit").addClass("Validform_error")
}else{
$(".select-tit").removeClass("Validform_error")
}





//layer公用调用






var souval=$("input[name='keyword']").val();
if(!souval==""){
var content = $(".table-container").html();
var s = souval;
var reg = new RegExp("(" + s + ")", "g");  
var str = content;  
var newstr = str.replace(reg, "<font style='color:#F00;font-weight:bold;' color=#F00>$1</font>");
$(".table-container").html(newstr);
}


	
function Views(mune,cid,name){

	if($(window).width()<767){
	area_width=$(window).width();
	}else{
	area_width=$(window).width()*0.82;
	}	
	
	$("body").parent().css("overflow-y","hidden");
	
	layer.open({
	type: 2, 
	skin: 'kehu-view-head',
	id: cid,
	title: '<i class="fa fa-info-circle"></i> '+name,
	content: '/index.php/kehu/view/?mune='+mune+'&id='+cid,
	offset: 'rt',
	resize: false,
	area: [area_width+'px', ($(window).height())+'px' ],
	shadeClose: true,
	maxWidth: '80%',
	anim: 4,
	end: function(){$("body").parent().css("overflow-y","auto");}
	});
  
}



function chengjiao_change(cid,chengjiao){
  if(chengjiao=="是"){
	if ($(".cid"+cid+":has(span)").length==0){    
	  $(".cid"+cid).prepend('<span class="btn1 chengjiao"> 成交 </span>');
	  layer.msg('客户状态修改成功');
	}
  }else{
	if ($(".cid"+cid+":has(span)").length>0){    
	  $(".cid"+cid+" span").remove();
	  layer.msg('客户状态修改成功');
	}
  }
}

/*$("span.yes").each(function(){
switch($(this).text()){
case "1" :
$(this).text("是");
break;
case "0" :
$(this).text("否");
break;
case "3" :
$(this).text("三");
break;
}
});*/
