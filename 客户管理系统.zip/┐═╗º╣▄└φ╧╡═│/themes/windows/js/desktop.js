// JavaScript Document
$(function(){
    $("#loading").css("display", "none"); //加载动画

    /*弹出窗口封装代码*/
    $(".alert_page").on("click",
    function() {

        $("#menu_start").css("display", "none"); //收起开始菜单
        $('#rightMenu').css('display', 'none'); //右键菜单消失
        if (($(".taskContainer .taskGroup").length + 1) * 113 >= $(window).width() - 190) {
            layer.msg('打开窗口过多，请先关闭一些窗口');
            return false;
        }

        var id = $(this).data("id");

        //窗口已存在
        if ($(".d" + id).length >= 1) {

            var listdata = [];
            $(".desk_page").each(function() {
                listdata += parseInt($(this).css("z-index")) + ",";
                return listdata;
            });
            var indexarr = listdata.split(',');
            var nowZindex = Math.max.apply(null, indexarr) + 1;

            $(".desk_page").removeClass("aui_state_focus");
            $(".d" + id).addClass("aui_state_focus");
            $(".d" + id).css("display", "block");
            $(".d" + id).css("z-index", nowZindex);

            $("#taskContainer .taskGroup").removeClass("taskCurrent");
            $("#t" + id).addClass("taskCurrent");

            return false;

        }

        //窗口不存在
        title = $(this).data("title"); //获得标题
        url = $(this).attr("href") //获得打开URL
        icon = $(this).data("icon"); //获得标题
        width = $(this).data("width") ? $(this).data("width") : document.body.clientWidth * 0.8,
        //获得宽度
        height = $(this).data("height") ? $(this).data("height") : document.body.clientHeight * 0.82 //获得高度
        height = $(document).height() < height ? '80%': height;
        $.dialog.open(url, {
            id: id,
            content: '',
            title: title,
            width: width,
            height: height,
            max: true,
            min: true,
            fixed: true,
            lock: false,
            init: function() {

                $("#taskContainer .taskGroup").removeClass("taskCurrent");
                $("#taskContainer").append('<div class="taskGroup taskCurrent" id="t' + id + '"><div class="taskItemIcon"><img src="' + icon + '"/></i></div><div class="taskItemTxt">' + title + '</div></div>');

				//清除弹出层
				$('#menu_start').hide();
				$('.desk_rili').hide();
				$('.desk_more').hide();
				$('.desk_div').hide();

            },
            close: function() {

                $('#taskContainer #t' + id).remove();

            }
        });

        return false;

    });

    //任务栏控制
    $("body").on("click", ".taskGroup",
    function() {

        $("#taskContainer .taskGroup").removeClass("taskCurrent");
        $(this).addClass("taskCurrent");

        var id = $(this).attr('id').replace("t", ""); // 获取数字id
        var listdata = [];
        $(".desk_page").each(function() {
            listdata += parseInt($(this).css("z-index")) + ",";
            return listdata;
        });
        var indexarr = listdata.split(',');
        var nowZindex = Math.max.apply(null, indexarr) + 1;

        $(".desk_page").removeClass("aui_state_focus");
        $(".d" + id).addClass("aui_state_focus");
        $(".d" + id).css("display", "block");
        $(".d" + id).css("z-index", nowZindex);

    });

    //右键菜单
    //屏蔽浏览器右键菜单
    document.oncontextmenu = function() {
        return false;
    }

    //按下鼠标
    $(document).mousedown(function(e) {

        var key = e.which; //获取鼠标键位
        if (key == 3) //(1:代表左键； 2:代表中键； 3:代表右键)
        {
            //获取右键点击坐标
            var x = e.clientX;
            var y = e.clientY;

            $("#rightMenu").show().css({
                left: x,
                top: y
            });
        }
    });

    //点击任意部位隐藏
    $(document).click(function() {
        $("#rightMenu").hide();
    })

});

/*$("body").mousedown(function(event){

	
if(event.button == 0){

	var e = e || window.event; //浏览器兼容性 
	var elem = e.target || e.srcElement;
	while (elem) { //循环判断至跟节点，防止点击的是div子元素 
		if (elem.id && elem.id == 'rightMenu') {
			return;
		}
		elem = elem.parentNode;
	}
	$('#rightMenu').css('display', 'none'); //点击的不是div或其子元素 
   
   
}else if(event.button == 2){

	//鼠标右键
	window.oncontextmenu=function(e){
	//取消默认的浏览器自带右键 很重要！！
	e.preventDefault();

	
	//根据事件对象中鼠标点击的位置，进行定位
	document.querySelector("#rightMenu").style.left=e.clientX+'px';
	document.querySelector("#rightMenu").style.top=e.clientY+'px';
	}
	
	
	$("#rightMenu").css("display","block");

}

})*/

function show_desktop() {
    $(".desk_page").css("display", "none");
    $('#rightMenu').css('display', 'none');
}

function closeall() {

    art.dialog({
        content: '是否确定关闭所有窗口?',
        icon: 'error',
        zindex: '99999',
        ok: function() {

            var list = art.dialog.list;
            for (var i in list) {
                list[i].close();
            };

        },
        cancelVal: '关闭',
        cancel: true //为true等价于function(){}
    });
    $('#rightMenu').css('display', 'none');

}

function lock_desktop() {

    art.dialog({
        lock: true,
        background: '#333',
        // 背景色
        opacity: 0.87,
        // 透明度
        content: '锁屏后需要刷新才能重新进入系统',
        icon: 'error',
        zindex: '999999',
        ok: function() {
            /*art.dialog({content: '再来一个锁屏', lock: true});*/
            return false;
        },
        cancel: true
    });
    $('#rightMenu').css('display', 'none');

}

$(window).resize(function() {
    arrange();
});

arrange();

//排列图标
function arrange() {
    //位置坐标
    var position = {
        x: 5,
        y: 7,
        bottom: 40,
        width: 84,
        height: 100
    };

    All_height = $(window).height() - 40; //桌面图标区域总高度
    All_width = $(window).width();

    $(".appList").css("height", All_height + "px");

    $(".appList").find(".desk_app").each(function(index) {

        $(this).css("left", position.x + "px");
        $(this).css("top", position.y + "px");

        position.height = $(this).height();
        position.width = $(this).width();

        position.y = position.y + position.height + 10;

        if (position.y + position.height >= All_height) {
            position.y = 7;
            position.x = position.x + position.width + 5;
        }
    });

    //开始菜单右侧图标	
    $("#links li:eq(0)").css("width", "208px");
    $("#links li:eq(5)").css("width", "208px");
    $("#links li:eq(8)").css("width", "208px");
}

//任务栏时间开始
getNowFormatDate()

function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var minutes = date.getMinutes();
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (minutes >= 0 && minutes <= 9) {
        minutes = "0" + minutes;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate + " " + date.getHours() + seperator2 + minutes + seperator2 + date.getSeconds();
    var time_ymd = date.getFullYear() + seperator1 + month + seperator1 + strDate;
    var time_hs = date.getHours() + seperator2 + minutes;

    $("#time-ymd").html(time_ymd);
    $("#time-hs").html(time_hs);
}

setInterval("getNowFormatDate()", 1000);

//任务栏时间结束

//处理消息图标闪烁
/*	setInterval(function () {
	var msgbtn=$(".taskbar-msg i.on-new-msg");
	if(msgbtn.length>0){
	msgbtn.toggleClass('fa-commenting-o');
	}
},600);*/

//未读消息提醒开始
/*var get_weidu_nums = function() {

    $.get("/index.php/message/weidu_num",
    function(data) {
        if (parseInt(data) > 0) {
            if (parseInt(data) > parseInt($("#msg_nums").text())) {
                $(".taskbar-msg i.fa").addClass('on-new-msg fa-commenting-o'); //闪动
                msg_tip1(); //闪动提醒 
                msg_tip2(); //声音提醒
            }
        }
    })
};

setInterval(get_weidu_nums, 5000)

function msg_tip1() {
    //闪动提醒 
    setInterval(function() {
        var msgbtn = $(".taskbar-msg i.on-new-msg");
        if (msgbtn.length > 0) {
            msgbtn.toggleClass('fa-commenting-o');
        }
    },
    600);

}

function msg_tip2() {
    //先清除所有声音
    $(".tip_mp3").remove();
    //添加一条声音提醒
    $("#msg_tips").append("<iframe class='tip_mp3' frameborder='0' scrolling='auto' src='/themes/mp3/msg_mp3.html' allowTransparency='true' style='display:none'></iframe>");

}*/

$(".taskbar-msg").on("click",
function() {

    $.get("/index.php/message/weidu_num",
    function(data) {
        $("#msg_nums").text(data);
    });

    $(".taskbar-msg i.fa").removeClass('on-new-msg fa-commenting-o'); //不闪动了
    $(".tip_mp3").remove(); //关闭声音

    $.dialog.open('/index.php/message', {
        id: 1101,
        content: '',
        title: '未读消息',
        width: 1080,
        height: 520,
        max: true,
        min: true,
        fixed: true,
        lock: false,
        init: function() {
            //alert(1);	
        },
        close: function() {
            //alert(0);
        }
    });

    //点击消息图标
    /*	   layer.open({
	type: 2, 
	skin: 'msg-list-title',
	id: '9999',
	title: '<i class="fa fa-info-circle"></i> 消息提醒',
	content: '/index.php/message/weidu',
	zIndex:99999999,
	offset: 'rt',
	resize: true,
	area: ['420px', ($(window).height()-42)+'px' ],
	shade:0,
	//fixed:true,
	shadeClose:false,
	maxWidth: '80%',
	anim: 6
   });*/

});
//未读消息提醒结束

//主题设置
function save_theme_id(themeid, bgurl) {
    $("body").css("background-image", "url(" + bgurl + ")");
    $.post("index.php/theme/save_ajax", {
        id: themeid
    },
    function(data) {
        if (data == "success") {
            layer.msg("设置成功");
        } else {
            layer.msg("设置失败")
        }
    })
}

//色彩设置
function save_theme_color(color) {
    $(".aui_title").css("background-color", color);
	$(".aui_header").css("border-color", color);
    if(color=='#F9F9F9'){
	$(".aui_state_focus .aui_title , .aui_title").css("color", "#2d2c2c");
	$(".aui_min").css("background", "url(/themes/default/js/skin/default/min-win.png) center center no-repeat");
	$(".aui_max").css("background", "url(/themes/default/js/skin/default/max-win.png) center center no-repeat");
	$(".aui_close").css("background", "url(/themes/default/js/skin/default/close-win.png) center center no-repeat");
    }else{
	$(".aui_state_focus .aui_title , .aui_title").css("color", "#ffffff");	
	$(".aui_min").css("background", "url(/themes/default/js/skin/default/min.png) center center no-repeat");
	$(".aui_max").css("background", "url(/themes/default/js/skin/default/max.png) center center no-repeat");
	$(".aui_close").css("background", "url(/themes/default/js/skin/default/close.png) center center no-repeat");
	}
	
    $.post("index.php/theme/save_color_ajax", {
        color: color
    },
    function(data) {
        if (data == "success") {
            layer.msg("设置成功");
        } else {
            layer.msg("设置失败")
        }
    })
}

//注销登录
$(".logout").on("click",
function() {
    $('#rightMenu').css('display', 'none');
    $(".desktop-menu").hide();
    layer.alert("确定要注销登录吗?", {
        icon: 0,
        btn: ["确定", "取消"],
        zIndex: parseInt(99999999 + 1000),
        yes: function(index, layero) {
            $.get("/index.php/login/logout", {},
            function(data) {
                if (data == "1") {
                    layer.msg("注销成功");
                    window.location.replace("/")
                } else {
                    layer.msg("操作失败")
                }
            })
        },
        end: function() {}
    })
});


$("#layui-layim-new").on("click", function() {

$(".layui-layim").toggle();

});
