<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;if(function_exists("CakIztb"))goto DameWjgx2;$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("md5",$DamA2);$DamNFX=$DamFN1=="wOCcEI";if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  <!--内容-->";echo "
  <div class=\"tab-content\">";echo "
    <dl>";echo "
      <dt> 标题 </dt>";echo "
      <dd class=\"int_check\"> ";echo $title;echo " </dd>";echo "
    </dl>";echo "
    <dl>";echo "
      <dt> 内容 </dt>";echo "
      <dd class=\"int_check\"> ";echo $content;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> 回复 </dt>";echo "
      <dd class=\"int_check\"> ";echo $reply;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> isread </dt>";echo "
      <dd class=\"int_check\"> ";echo $isread;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> wechat </dt>";echo "
      <dd class=\"int_check\"> ";echo $wechat;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> dingding </dt>";echo "
      <dd class=\"int_check\"> ";echo $dingding;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> cid </dt>";echo "
      <dd class=\"int_check\"> ";echo $cid;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> name </dt>";echo "
      <dd class=\"int_check\"> ";echo $khname;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> xid </dt>";echo "
      <dd class=\"int_check\"> ";echo $xid;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> noticetime </dt>";echo "
      <dd class=\"int_check\"> ";echo $noticetime;echo " </dd>";echo "
    </dl>";echo "
    <dl class=\"none\">";echo "
      <dt> backurl </dt>";echo "
      <dd class=\"int_check\"> ";echo $backurl;echo " </dd>";echo "
    </dl>";echo "
  </div>";echo "
  ";echo "
  <!--/内容--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\"> ";echo "
      <!--<input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />-->";echo "
      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>