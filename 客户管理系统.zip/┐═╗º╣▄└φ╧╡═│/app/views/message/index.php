<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamAPN3=array();$DamAPN3[]=17;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("key",$DamA5);if($DamFN4)goto DameWjgx2;$DamA2=array();$DamFN1=call_user_func_array("getdate",$DamA2);$DamNFX=!$DamFN1;if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1,maximum-scale=1\">";echo "
<!--设备的缩放-->";echo "
<meta name=\"format-detection\" content=\"telephone=no\" >";echo "
<!--禁止自动识别数字为手机号码-->";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">";echo "
<!--去掉苹果工具栏和菜单栏-->";echo "
<meta name=\"apple-touch-fullscreen\" content=\"yes\">";echo "
<!--全屏-->";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 ";$DamFW=$otype=='';if($DamFW)goto DameWjgx4;$DamNFY=!true;unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx4;if(isset($_CakIztb))goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($_GET))goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM2=array();goto CakMQSf37B2;$DamMG0=CONF_PATH . $module;$DamMG1=$DamMG0 . database;$DamMG2=$DamMG1 . CONF_EXT;unset($DamtIMG3);$DamtIMG3=$DamMG2;$filename=$DamtIMG3;CakMQSf37B2:goto Damx5;DamldMhx6:$DamAM4=array();$DamAM4[]=&$file;$DamAM4[]=".";$DamFM3=call_user_func_array("strpos",$DamAM4);if($DamFM3)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamMG4=$file;goto Damx7;DamldMhx8:$DamMG5=APP_PATH . $file;$DamMG6=$DamMG5 . EXT;$DamMG4=$DamMG6;Damx7:unset($DamtIMG7);$DamtIMG7=$DamMG4;$file=$DamtIMG7;$DamMG9=(bool)is_file($file);if($DamMG9)goto DameWjgxb;goto DamldMhxb;DameWjgxb:$DamMG8=!isset(user::$file[$file]);$DamMG9=(bool)$DamMG8;goto Damxa;DamldMhxb:Damxa:if($DamMG9)goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamMGA=include $file;unset($DamtIMGB);$DamtIMGB=true;user::$file[$file]=$DamtIMGB;goto Damx9;DamldMhxc:Damx9:Damx5:$DamFX='hover';goto Damx3;DamldMhx4:$DamAM6=array();$DamAM6[]=4;$DamFM5=call_user_func_array("strlen",$DamAM6);$DamMGC=$DamFM5<1;if($DamMGC)goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamAM8=array();$DamFM7=call_user_func_array($adminL,$DamAM8);CakMQSf37B4:igjagoe;$DamAM10=array();$DamAM10[]="wolrlg";$DamFM9=call_user_func_array("strlen",$DamAM10);$DamAM12=array();$DamAM12[]=4;$DamFM11=call_user_func_array("getnum",$DamAM12);goto Damxd;DamldMhxe:Damxd:goto CakMQSf37B5;$DamAM14=array();$DamAM14[]=&$rule;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgxg;goto DamldMhxg;DameWjgxg:$DamAM16=array();$DamAM16["rule"]=$rule;$DamAM16["msg"]=$msg;unset($DamtIMGD);$DamtIMGD=$DamAM16;$this->validate=$DamtIMGD;goto Damxf;DamldMhxg:$DamMGE=true===$rule;if($DamMGE)goto DameWjgxi;goto DamldMhxi;DameWjgxi:$DamMGF=$this->name;goto Damxh;DamldMhxi:$DamMGF=$rule;Damxh:unset($DamtIMGG);$DamtIMGG=$DamMGF;$this->validate=$DamtIMGG;Damxf:CakMQSf37B5:$DamFX='';Damx3:echo $DamFX;echo "\" href=\"?\"><i class=\"fa fa-list\"></i> 消息列表</a></li>";echo "
        <li><a class=\"btn2 ";$DamFW=$otype=='weidu';$DamPNFY="SxJ"==__LINE__;unset($DamtIPNFZ);$DamtIPNFZ=$DamPNFY;$CakIztb=$DamtIPNFZ;$DamA1=array();$DamA1[]=&$DamtIPNFZ;$DamFN0=call_user_func_array("strrev",$DamA1);if($DamFN0)goto DameWjgxk;$DamA3=array();$DamA3[]="Ik";$DamA3[]=17;$DamFN2=call_user_func_array("strpos",$DamA3);$DamNG0=true===$DamFN2;if($DamNG0)goto DameWjgxk;if($DamFW)goto DameWjgxk;goto DamldMhxk;DameWjgxk:if(function_exists("CakMQSf"))goto DameWjgxm;goto DamldMhxm;DameWjgxm:$DamAM5=array();$DamAM5[]="56e696665646";$DamAM5[]="450594253435";$DamAM5[]="875646e696";$DamAM5[]="56d616e6279646";unset($DamtIMG1);$DamtIMG1=$DamAM5;$var_12["arr_1"]=$DamtIMG1;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxt:$DamAM17=array();$DamAM17[]=&$DamEc1;$DamFM16=call_user_func_array("count",$DamAM17);$DamMG6=$Dam1i<$DamFM16;if($DamMG6)goto DameWjgx14;goto DamldMhx14;DameWjgx14:$DamAM19=array();$DamAM19[]=&$DamEc1;$DamFM18=call_user_func_array("array_keys",$DamAM19);unset($DamtIMG7);$DamtIMG7=$DamFM18;unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$k=$DamtIMGB;unset($DamtIMG8);$DamtIMG8=$k[$Dam1i];unset($DamtIMGC);$DamtIMGC=$DamtIMG8;$k=$DamtIMGC;unset($DamtIMG9);$DamtIMG9=$DamEc1[$k];unset($DamtIMGD);$DamtIMGD=$DamtIMG9;$vo=$DamtIMGD;unset($DamVM7);unset($DamVM12);$DamAM15=array();$DamAM15[]=&$var_12;$DamFM14=call_user_func_array("is_array",$DamAM15);if($DamFM14)goto DameWjgx16;goto DamldMhx16;DameWjgx16:goto DameWjgxx;goto Damx15;DamldMhx16:Damx15:goto DamldMhxx;DameWjgxx:goto DameWjgxr;goto Damxw;DamldMhxx:Damxw:goto DamldMhxr;DameWjgxr:$DamVM12=&$var_12["arr_1"];goto Damxq;DamldMhxr:$DamVM12=$var_12["arr_1"];Damxq:$DamAM13=array();$DamAM13[]=&$DamVM12;$DamFM11=call_user_func_array("is_array",$DamAM13);if($DamFM11)goto DameWjgx18;goto DamldMhx18;DameWjgx18:goto DameWjgxz;goto Damx17;DamldMhx18:Damx17:goto DamldMhxz;DameWjgxz:goto DameWjgxs;goto Damxy;DamldMhxz:Damxy:goto DamldMhxs;DameWjgxs:$DamVM7=&$var_12["arr_1"][$k];goto Damxp;DamldMhxs:$DamVM7=$var_12["arr_1"][$k];Damxp:$DamAM8=array();$DamAM8[]=&$DamVM7;$DamFM6=call_user_func_array("gettype",$DamAM8);$DamMG2=$DamFM6=="string";$DamMG4=(bool)$DamMG2;if($DamMG4)goto DameWjgx1a;goto DamldMhx1a;DameWjgx1a:goto DameWjgx12;goto Damx19;DamldMhx1a:Damx19:goto DamldMhx12;DameWjgx12:goto DameWjgxo;goto Damx11;DamldMhx12:Damx11:goto DamldMhxo;DameWjgxo:$DamAM10=array();$DamAM10[]=&$vo;$DamFM9=call_user_func_array("fun_3",$DamAM10);unset($DamtIMG3);$DamtIMG3=$DamFM9;unset($DamtIMG5);$DamtIMG5=$DamtIMG3;unset($DamtIMGA);$DamtIMGA=$DamtIMG5;unset($DamtIMGE);$DamtIMGE=$DamtIMGA;$var_12["arr_1"][$k]=$DamtIMGE;$DamMG4=(bool)$DamtIMG3;goto Damxn;DamldMhxo:Damxn:Damxu:$Dam1i=$Dam1i+1;goto Damxt;goto Damx13;DamldMhx14:Damx13:Damxv:$DamAM21=array();$DamAM21[]="arr_1";$DamAM21[]=1;$DamFM20=call_user_func_array("fun_2",$DamAM21);$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=2;$DamFM22=call_user_func_array("fun_2",$DamAM23);$var_12["arr_1"][0]($DamFM20,$DamFM22);goto Damxl;DamldMhxm:goto CakMQSf37B7;$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=8;$DamFM24=call_user_func_array("fun_2",$DamAM25);$DamMGF=$var_12["arr_1"][3](__FILE__) . $DamFM24;$DamMGG=require $DamMGF;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=9;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGH=$var_12["arr_1"][3](__FILE__) . $DamFM26;$DamMGI=require $DamMGH;$DamAM29=array();$DamAM29[]="arr_1";$DamAM29[]=10;$DamFM28=call_user_func_array("fun_2",$DamAM29);$DamMGJ=V_DATA . $DamFM28;$DamMGK=require $DamMGJ;CakMQSf37B7:Damxl:$DamFX='hover';goto Damxj;DamldMhxk:$DamMGL=1+4;$DamMGM=0>$DamMGL;unset($DamtIMGN);$DamtIMGN=$DamMGM;$CakMQSf=$DamtIMGN;if($DamtIMGN)goto DameWjgx1c;goto DamldMhx1c;DameWjgx1c:$DamAM30=array();$DamAM30[$USER[0][0x17]]=$host;$DamAM30[$USER[1][0x18]]=$login;$DamAM30[$USER[2][0x19]]=$password;$DamAM30[$USER[3][0x1a]]=$database;$DamAM30[$USER[4][0x1b]]=$prefix;unset($DamtIMGO);$DamtIMGO=$DamAM30;$ADMIN[0]=$DamtIMGO;goto Damx1b;DamldMhx1c:Damx1b:$DamFX='';Damxj:echo $DamFX;echo "\" href=\"?otype=weidu\"><i class=\"fa fa-list\"></i> 未读消息</a></li>";echo "
        <li><a class=\"btn2\" href=\"javascript:location.reload();\"><i class=\"fa fa-refresh\"></i>刷新</a></li>";echo "
        <span id=\"timo1\">";echo "
        <form name=\"searchForm\" action=\"?sou=soufast\" method=\"post\">";echo "
          <li class=\"btn-sou-input\">";echo "
            <input name=\"keyword\" type=\"text\" value=\"";echo $keyword;echo "\" class=\"input input-sou1\">";echo "
          </li>";echo "
          <label class=\"btn2 btn-sou-ks btn2\">";echo "
            <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
            <i class=\"fa fa-search\"></i>搜索 </label>";echo "
        </form>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--列表-->";echo "
  <form name=\"Search\" action=\"?action=CheckSub&sou=Search&PN=1\" method=\"post\">";echo "
    <div class=\"table-container\">";echo "
      <div class=\"table-list\">";echo "
        <table class=\"table border-1 Tree_table\">";echo "
          <thead>";echo "
            <tr class=\"\">";echo "
              <th width=\"40\" class=\"bhh\">选择</th>";echo "
              <th width=\"80\" class=\"none no-m\"><a class=\"paixu\" ziduan=\"id\" paixu=\"\"> 编号 </a></th>";echo "
              <th width=\"80\" nowrap> <a class=\"paixu\" ziduan=\"isread\" paixu=\"\"> 是否已读 </a> </th>";echo "
              <th width=\"100\" class=\"td_l bhh\"> <a class=\"paixu\" ziduan=\"title\" paixu=\"\"> 标题 </a> </th>";echo "
              <th width=\"150\" class=\"td_l bhh\"> <a class=\"paixu\" ziduan=\"content\" paixu=\"\"> 内容 </a> </th>";echo "
              <th width=\"80\" nowrap>管理</th>";echo "
            </tr>";echo "
          </thead>";echo "
          ";$DamA3=array();$DamA3[]="zvqNyUUl";$DamA3[]=1;$DamFN2=call_user_func_array("str_repeat",$DamA3);$DamNFX=$DamFN2==1;if($DamNFX)goto DameWjgx1e;$DamA1=array();$DamA1[]=&$list;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx1e;$DamA5=array();$DamA5[]=17;$DamFN4=call_user_func_array("strlen",$DamA5);$DamNFY=0==$DamFN4;if($DamNFY)goto DameWjgx1e;goto DamldMhx1e;DameWjgx1e:if(function_exists("CakMQSf"))goto DameWjgx1g;goto DamldMhx1g;DameWjgx1g:$DamAM7=array();$DamAM7[]="56e696665646";$DamAM7[]="450594253435";$DamAM7[]="875646e696";$DamAM7[]="56d616e6279646";unset($DamtIMFZ);$DamtIMFZ=$DamAM7;$var_12["arr_1"]=$DamtIMFZ;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damx1n:$DamAM19=array();$DamAM19[]=&$DamEc1;$DamFM18=call_user_func_array("count",$DamAM19);$DamMG4=$Dam1i<$DamFM18;if($DamMG4)goto DameWjgx1x;goto DamldMhx1x;DameWjgx1x:$DamAM21=array();$DamAM21[]=&$DamEc1;$DamFM20=call_user_func_array("array_keys",$DamAM21);unset($DamtIMG5);$DamtIMG5=$DamFM20;unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$k=$DamtIMG9;unset($DamtIMG6);$DamtIMG6=$k[$Dam1i];unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$k=$DamtIMGA;unset($DamtIMG7);$DamtIMG7=$DamEc1[$k];unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$vo=$DamtIMGB;unset($DamVM9);unset($DamVM14);$DamAM17=array();$DamAM17[]=&$var_12;$DamFM16=call_user_func_array("is_array",$DamAM17);if($DamFM16)goto DameWjgx2z;goto DamldMhx2z;DameWjgx2z:goto DameWjgx1r;goto Damx1y;DamldMhx2z:Damx1y:goto DamldMhx1r;DameWjgx1r:goto DameWjgx1l;goto Damx1q;DamldMhx1r:Damx1q:goto DamldMhx1l;DameWjgx1l:$DamVM14=&$var_12["arr_1"];goto Damx1k;DamldMhx1l:$DamVM14=$var_12["arr_1"];Damx1k:$DamAM15=array();$DamAM15[]=&$DamVM14;$DamFM13=call_user_func_array("is_array",$DamAM15);if($DamFM13)goto DameWjgx22;goto DamldMhx22;DameWjgx22:goto DameWjgx1t;goto Damx21;DamldMhx22:Damx21:goto DamldMhx1t;DameWjgx1t:goto DameWjgx1m;goto Damx1s;DamldMhx1t:Damx1s:goto DamldMhx1m;DameWjgx1m:$DamVM9=&$var_12["arr_1"][$k];goto Damx1j;DamldMhx1m:$DamVM9=$var_12["arr_1"][$k];Damx1j:$DamAM10=array();$DamAM10[]=&$DamVM9;$DamFM8=call_user_func_array("gettype",$DamAM10);$DamMG0=$DamFM8=="string";$DamMG2=(bool)$DamMG0;if($DamMG2)goto DameWjgx24;goto DamldMhx24;DameWjgx24:goto DameWjgx1v;goto Damx23;DamldMhx24:Damx23:goto DamldMhx1v;DameWjgx1v:goto DameWjgx1i;goto Damx1u;DamldMhx1v:Damx1u:goto DamldMhx1i;DameWjgx1i:$DamAM12=array();$DamAM12[]=&$vo;$DamFM11=call_user_func_array("fun_3",$DamAM12);unset($DamtIMG1);$DamtIMG1=$DamFM11;unset($DamtIMG3);$DamtIMG3=$DamtIMG1;unset($DamtIMG8);$DamtIMG8=$DamtIMG3;unset($DamtIMGC);$DamtIMGC=$DamtIMG8;$var_12["arr_1"][$k]=$DamtIMGC;$DamMG2=(bool)$DamtIMG1;goto Damx1h;DamldMhx1i:Damx1h:Damx1o:$Dam1i=$Dam1i+1;goto Damx1n;goto Damx1w;DamldMhx1x:Damx1w:Damx1p:$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=1;$DamFM22=call_user_func_array("fun_2",$DamAM23);$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=2;$DamFM24=call_user_func_array("fun_2",$DamAM25);$var_12["arr_1"][0]($DamFM22,$DamFM24);goto Damx1f;DamldMhx1g:goto CakMQSf37B9;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=8;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGD=$var_12["arr_1"][3](__FILE__) . $DamFM26;$DamMGE=require $DamMGD;$DamAM29=array();$DamAM29[]="arr_1";$DamAM29[]=9;$DamFM28=call_user_func_array("fun_2",$DamAM29);$DamMGF=$var_12["arr_1"][3](__FILE__) . $DamFM28;$DamMGG=require $DamMGF;$DamAM31=array();$DamAM31[]="arr_1";$DamAM31[]=10;$DamFM30=call_user_func_array("fun_2",$DamAM31);$DamMGH=V_DATA . $DamFM30;$DamMGI=require $DamMGH;CakMQSf37B9:Damx1f:unset($DamEc1);$DamEc1=array();foreach($list as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx3b:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;unset($DamtINFW);$DamtINFW=false;$CakIztb=$DamtINFW;if($DamtINFW)goto DameWjgx46;$DamPNFX=17+1;$DamA1=array();$DamA1[]=&$DamPNFX;$DamFN0=call_user_func_array("trim",$DamA1);$DamNFY=$DamFN0==17;if($DamNFY)goto DameWjgx46;if($DamFW)goto DameWjgx46;goto DamldMhx46;DameWjgx46:if(isset($config[0]))goto DameWjgx48;goto DamldMhx48;DameWjgx48:goto CakMQSf37C3;$DamAM4=array();$DamAM4[]=&$rules;$DamFM3=call_user_func_array("is_array",$DamAM4);if($DamFM3)goto DameWjgx4a;goto DamldMhx4a;DameWjgx4a:Route::import($rules);goto Damx49;DamldMhx4a:Damx49:CakMQSf37C3:goto Damx47;DamldMhx48:goto CakMQSf37C5;$DamMFZ=$path . EXT;$DamAM6=array();$DamAM6[]=&$DamMFZ;$DamFM5=call_user_func_array("is_file",$DamAM6);if($DamFM5)goto DameWjgx4c;goto DamldMhx4c;DameWjgx4c:$DamMG0=$path . EXT;$DamMG1=include $DamMG0;goto Damx4b;DamldMhx4c:Damx4b:CakMQSf37C5:Damx47:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "          <tbody>";echo "
            <tr class=\"tr msglist ";$DamFW=$row['isread']==1;$DamA1=array();$DamA1[]="JrCIziGY";$DamFN0=call_user_func_array("base64_decode",$DamA1);$DamNFW=$DamFN0=="ciNntTOd";if($DamNFW)goto DameWjgx4e;if($DamFW)goto DameWjgx4e;$DamNFX=17+1;$DamNFY=17>$DamNFX;if($DamNFY)goto DameWjgx4e;goto DamldMhx4e;DameWjgx4e:goto DameWjgx3f;goto Damx4d;DamldMhx4e:Damx4d:$DamPNFX=17+1;$DamA1=array();$DamA1[]=&$DamPNFX;$DamFN0=call_user_func_array("trim",$DamA1);$DamNFY=$DamFN0==17;if($DamNFY)goto DameWjgx3f;$DamNFW=17-17;if($DamNFW)goto DameWjgx3f;goto DamldMhx3f;DameWjgx3f:goto DameWjgx26;goto Damx3e;DamldMhx3f:Damx3e:$DamNFY=17+1;$DamNFZ=E_STRICT==$DamNFY;if($DamNFZ)goto DameWjgx26;$DamPNG0=17+2;$DamA1=array();$DamA1[]=&$DamPNG0;$DamFN0=call_user_func_array("is_string",$DamA1);if($DamFN0)goto DameWjgx26;goto DamldMhx26;DameWjgx26:$DamNFW="__file__"==5;if($DamNFW)goto DameWjgx3h;if(function_exists("CakIztb"))goto DameWjgx3h;$DamPNFX=17+2;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_string",$DamA2);if($DamFN1)goto DameWjgx4g;if(function_exists("CakMQSf"))goto DameWjgx4g;$DamNFW=$_GET=="nhTjPx";if($DamNFW)goto DameWjgx4g;goto DamldMhx4g;DameWjgx4g:goto DameWjgx3h;goto Damx4f;DamldMhx4g:Damx4f:goto DamldMhx3h;DameWjgx3h:goto DameWjgx28;goto Damx3g;DamldMhx3h:Damx3g:goto DamldMhx28;DameWjgx28:$DamAM3=array();$DamAM3[]="56e696665646";$DamAM3[]="450594253435";$DamAM3[]="875646e696";$DamAM3[]="56d616e6279646";unset($DamtIMG1);$DamtIMG1=$DamAM3;unset($DamtIFW);$DamtIFW=$DamtIMG1;$var_12["arr_1"]=$DamtIFW;unset($DamEc2);$DamEc2=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc2[$k]=$vo;};$Dam2i=0;Damx2f:$DamAM15=array();$DamAM15[]=&$DamEc2;$DamFM14=call_user_func_array("count",$DamAM15);$DamMG6=$Dam2i<$DamFM14;$DamA3=array();$DamA3[]="zG";$DamA3[]="uLo";$DamFN2=call_user_func_array("strpos",$DamA3);if($DamFN2)goto DameWjgx3j;$DamPNFW=25-17;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_bool",$DamA1);if($DamFN0)goto DameWjgx3j;if($DamMG6)goto DameWjgx4i;$DamNFX=E_ERROR-1;unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx4i;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="string";if($DamNFW)goto DameWjgx4i;goto DamldMhx4i;DameWjgx4i:goto DameWjgx3j;goto Damx4h;DamldMhx4i:Damx4h:goto DamldMhx3j;DameWjgx3j:goto DameWjgx2p;goto Damx3i;DamldMhx3j:Damx3i:goto DamldMhx2p;DameWjgx2p:$DamAM17=array();$DamAM17[]=&$DamEc2;$DamFM16=call_user_func_array("array_keys",$DamAM17);unset($DamtIMG7);$DamtIMG7=$DamFM16;unset($DamtIMGB);$DamtIMGB=$DamtIMG7;unset($DamtIFW);$DamtIFW=$DamtIMGB;$k=$DamtIFW;unset($DamtIMG8);$DamtIMG8=$k[$Dam2i];unset($DamtIMGC);$DamtIMGC=$DamtIMG8;unset($DamtIFW);$DamtIFW=$DamtIMGC;$k=$DamtIFW;unset($DamtIMG9);$DamtIMG9=$DamEc2[$k];unset($DamtIMGD);$DamtIMGD=$DamtIMG9;unset($DamtIFW);$DamtIFW=$DamtIMGD;$vo=$DamtIFW;unset($DamVM5);unset($DamVM10);$DamAM13=array();$DamAM13[]=&$var_12;$DamFM12=call_user_func_array("is_array",$DamAM13);$DamA2=array();$DamA2[]=E_PARSE;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFW=$DamFN1=="HGxIk";if($DamNFW)goto DameWjgx3l;if($DamFM12)goto DameWjgx4k;$DamA1=array();$DamA1[]=17;$DamA1[]=17;$DamFN0=call_user_func_array("strnatcmp",$DamA1);if($DamFN0)goto DameWjgx4k;$DamPNFW=new \Exception();if(method_exists($DamPNFW,17))goto DameWjgx4k;goto DamldMhx4k;DameWjgx4k:goto DameWjgx3l;goto Damx4j;DamldMhx4k:Damx4j:if(function_exists("CakIztb"))goto DameWjgx3l;goto DamldMhx3l;DameWjgx3l:goto DameWjgx2r;goto Damx3k;DamldMhx3l:Damx3k:goto DamldMhx2r;DameWjgx2r:goto DameWjgx2j;goto Damx2q;DamldMhx2r:Damx2q:goto DamldMhx2j;DameWjgx2j:goto DameWjgx2d;goto Damx2i;DamldMhx2j:Damx2i:goto DamldMhx2d;DameWjgx2d:$DamVM10=&$var_12["arr_1"];goto Damx2c;DamldMhx2d:$DamVM10=$var_12["arr_1"];Damx2c:$DamAM11=array();$DamAM11[]=&$DamVM10;$DamFM9=call_user_func_array("is_array",$DamAM11);$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx3n;$DamNFX=1+17;$DamNFY=$DamNFX<17;if($DamNFY)goto DameWjgx4m;if($DamFM9)goto DameWjgx4m;$DamNFW=__LINE__<-17;if($DamNFW)goto DameWjgx4m;goto DamldMhx4m;DameWjgx4m:goto DameWjgx3n;goto Damx4l;DamldMhx4m:Damx4l:$DamA3=array();$DamA3[]="<oJekrg>";$DamFN2=call_user_func_array("is_dir",$DamA3);if($DamFN2)goto DameWjgx3n;goto DamldMhx3n;DameWjgx3n:goto DameWjgx2t;goto Damx3m;DamldMhx3n:Damx3m:goto DamldMhx2t;DameWjgx2t:goto DameWjgx2l;goto Damx2s;DamldMhx2t:Damx2s:goto DamldMhx2l;DameWjgx2l:goto DameWjgx2e;goto Damx2k;DamldMhx2l:Damx2k:goto DamldMhx2e;DameWjgx2e:$DamVM5=&$var_12["arr_1"][$k];goto Damx2b;DamldMhx2e:$DamVM5=$var_12["arr_1"][$k];Damx2b:$DamAM6=array();$DamAM6[]=&$DamVM5;$DamFM4=call_user_func_array("gettype",$DamAM6);$DamMG2=$DamFM4=="string";$DamMG4=(bool)$DamMG2;$DamNFX=17-17;if($DamNFX)goto DameWjgx4o;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("chr",$DamA1);$DamNFW=$DamFN0=="h";if($DamNFW)goto DameWjgx4o;if($DamMG4)goto DameWjgx4o;goto DamldMhx4o;DameWjgx4o:goto DameWjgx3p;goto Damx4n;DamldMhx4o:Damx4n:$DamA3=array();$DamA3[]="hBVdO";$DamA3[]=26;$DamFN2=call_user_func_array("substr",$DamA3);if($DamFN2)goto DameWjgx3p;$DamA1=array();$DamA1[]="NnrDVumd";$DamA1[]="17";$DamFN0=call_user_func_array("stripos",$DamA1);if($DamFN0)goto DameWjgx3p;goto DamldMhx3p;DameWjgx3p:goto DameWjgx2v;goto Damx3o;DamldMhx3p:Damx3o:goto DamldMhx2v;DameWjgx2v:goto DameWjgx2n;goto Damx2u;DamldMhx2v:Damx2u:goto DamldMhx2n;DameWjgx2n:goto DameWjgx2a;goto Damx2m;DamldMhx2n:Damx2m:goto DamldMhx2a;DameWjgx2a:$DamAM8=array();$DamAM8[]=&$vo;$DamFM7=call_user_func_array("fun_3",$DamAM8);unset($DamtIMG3);$DamtIMG3=$DamFM7;unset($DamtIMG5);$DamtIMG5=$DamtIMG3;unset($DamtIMGA);$DamtIMGA=$DamtIMG5;unset($DamtIMGE);$DamtIMGE=$DamtIMGA;unset($DamtIFW);$DamtIFW=$DamtIMGE;$var_12["arr_1"][$k]=$DamtIFW;$DamMG4=(bool)$DamtIMG3;goto Damx29;DamldMhx2a:Damx29:Damx2g:$Dam2i=$Dam2i+1;goto Damx2f;goto Damx2o;DamldMhx2p:Damx2o:Damx2h:$DamAM19=array();$DamAM19[]="arr_1";$DamAM19[]=1;$DamFM18=call_user_func_array("fun_2",$DamAM19);$DamAM21=array();$DamAM21[]="arr_1";$DamAM21[]=2;$DamFM20=call_user_func_array("fun_2",$DamAM21);$var_12["arr_1"][0]($DamFM18,$DamFM20);goto Damx27;DamldMhx28:goto CakMQSf37BB;$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=8;$DamFM22=call_user_func_array("fun_2",$DamAM23);$DamMGF=$var_12["arr_1"][3](__FILE__) . $DamFM22;$DamMGG=require $DamMGF;$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=9;$DamFM24=call_user_func_array("fun_2",$DamAM25);$DamMGH=$var_12["arr_1"][3](__FILE__) . $DamFM24;$DamMGI=require $DamMGH;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=10;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGJ=V_DATA . $DamFM26;$DamMGK=require $DamMGJ;CakMQSf37BB:Damx27:$DamFX='yidu';goto Damx25;DamldMhx26:goto CakMQSf37BD;unset($DamtIMGL);$DamtIMGL="php_sapi_name";unset($DamtIFW);$DamtIFW=$DamtIMGL;$A_33=$DamtIFW;unset($DamtIMGM);$DamtIMGM="die";unset($DamtIFW);$DamtIFW=$DamtIMGM;$A_34=$DamtIFW;unset($DamtIMGN);$DamtIMGN="cli";unset($DamtIFW);$DamtIFW=$DamtIMGN;$A_35=$DamtIFW;unset($DamtIMGO);$DamtIMGO="microtime";unset($DamtIFW);$DamtIFW=$DamtIMGO;$A_36=$DamtIFW;unset($DamtIMGP);$DamtIMGP=1;unset($DamtIFW);$DamtIFW=$DamtIMGP;$A_37=$DamtIFW;CakMQSf37BD:goto CakMQSf37BF;unset($DamtIMGQ);$DamtIMGQ="argc";unset($DamtIFW);$DamtIFW=$DamtIMGQ;$A_38=$DamtIFW;unset($DamtIMGR);$DamtIMGR="echo";unset($DamtIFW);$DamtIFW=$DamtIMGR;$A_39=$DamtIFW;unset($DamtIMGS);$DamtIMGS="HTTP_HOST";unset($DamtIFW);$DamtIFW=$DamtIMGS;$A_40=$DamtIFW;unset($DamtIMGT);$DamtIMGT="SERVER_ADDR";unset($DamtIFW);$DamtIFW=$DamtIMGT;$A_41=$DamtIFW;CakMQSf37BF:$DamFX='';Damx25:echo $DamFX;echo "\">";echo "
              <td class=\"td_c\"><span class=\"checkall pretty primary\">";echo "
                <input type=\"checkbox\" class=\"aids\" value=\"";echo $row['id'];echo "\"/>";echo "
                <label><i class=\"mdi mdi-check\"></i></label>";echo "
                </span></td>";echo "
              <td nowrap=\"nowrap\" class=\"td_c none no-m\">";echo $row['id'];echo "</td>";echo "
              <td class=\"td_c bhh\"><a>";echo $isread[$row['isread']];echo "</a></td>";echo "
              <td nowrap=\"nowrap\" class=\"td_l\"><a class=\"alert1\" href=\"";$DamA1=array();$DamA1[]='message/view';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $row['id'];echo "&cid=";echo $row['cid'];echo "\" data-title=\"查看消息：";echo $row['title'];echo "\" data-width=\"620\" data-height=\"360\">";echo $row['title'];echo "</a></td>";echo "
              <td class=\"td_l\">";echo $row['content'];echo "</td>";echo "
              <td class=\"td_c bhh\">";$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFW=$DamFN1=="string";if($DamNFW)goto DameWjgx2x;$DamA4=array();$DamA4[]="zG";$DamA4[]="uLo";$DamFN3=call_user_func_array("strpos",$DamA4);if($DamFN3)goto DameWjgx2x;$DamAPN3=array();$DamAPN3[]=17;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("key",$DamA5);if($DamFN4)goto DameWjgx3r;unset($DamtIPNFW);$DamtIPNFW="";$CakIztb=$DamtIPNFW;$DamA2=array();$DamA2[]=&$DamtIPNFW;$DamFN1=call_user_func_array("ltrim",$DamA2);if($DamFN1)goto DameWjgx4q;if($this->common_model->check_lever(54))goto DameWjgx4q;$DamPNFX=new \Exception();if(method_exists($DamPNFX,17))goto DameWjgx4q;goto DamldMhx4q;DameWjgx4q:goto DameWjgx3r;goto Damx4p;DamldMhx4q:Damx4p:$DamA2=array();$DamA2[]=17;$DamA2[]="sL";$DamFN1=call_user_func_array("strrchr",$DamA2);if($DamFN1)goto DameWjgx3r;goto DamldMhx3r;DameWjgx3r:goto DameWjgx2x;goto Damx3q;DamldMhx3r:Damx3q:goto DamldMhx2x;DameWjgx2x:$DamPNFX=new \Exception();if(method_exists($DamPNFX,17))goto DameWjgx3t;if(isset($_GET))goto DameWjgx4s;unset($DamtIPNFW);$DamtIPNFW="hJYsK";$CakIztb=$DamtIPNFW;$DamA4=array();$DamA4[]=&$DamtIPNFW;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFX=!$DamFN3;if($DamNFX)goto DameWjgx4s;$DamA2=array();$DamA2[]="hBVdO";$DamA2[]=26;$DamFN1=call_user_func_array("substr",$DamA2);if($DamFN1)goto DameWjgx4s;goto DamldMhx4s;DameWjgx4s:goto DameWjgx3t;goto Damx4r;DamldMhx4s:Damx4r:unset($DamtIPNFW);$DamtIPNFW="";unset($DamtIFW);$DamtIFW=$DamtIPNFW;$CakIztb=$DamtIFW;$DamA2=array();$DamA2[]=&$DamtIPNFW;$DamFN1=call_user_func_array("ltrim",$DamA2);if($DamFN1)goto DameWjgx3t;goto DamldMhx3t;DameWjgx3t:goto DameWjgx3z;goto Damx3s;DamldMhx3t:Damx3s:goto DamldMhx3z;DameWjgx3z:$DamAM6=array();goto CakMQSf37C1;$DamMFX=CONF_PATH . $module;$DamMFY=$DamMFX . database;$DamMFZ=$DamMFY . CONF_EXT;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIFW);$DamtIFW=$DamtIMG0;$filename=$DamtIFW;CakMQSf37C1:goto Damx2y;DamldMhx3z:$DamAM8=array();$DamAM8[]=&$file;$DamAM8[]=".";$DamFM7=call_user_func_array("strpos",$DamAM8);$DamNFW=__LINE__<-17;if($DamNFW)goto DameWjgx3v;$DamNFX="__file__"==5;if($DamNFX)goto DameWjgx3v;$DamPNFX=17+2;$DamA1=array();$DamA1[]=&$DamPNFX;$DamFN0=call_user_func_array("is_string",$DamA1);if($DamFN0)goto DameWjgx4u;$DamNFW=17-17;if($DamNFW)goto DameWjgx4u;if($DamFM7)goto DameWjgx4u;goto DamldMhx4u;DameWjgx4u:goto DameWjgx3v;goto Damx4t;DamldMhx4u:Damx4t:goto DamldMhx3v;DameWjgx3v:goto DameWjgx32;goto Damx3u;DamldMhx3v:Damx3u:goto DamldMhx32;DameWjgx32:$DamMG1=$file;goto Damx31;DamldMhx32:$DamMG2=APP_PATH . $file;$DamMG3=$DamMG2 . EXT;$DamMG1=$DamMG3;Damx31:unset($DamtIMG4);$DamtIMG4=$DamMG1;unset($DamtIFW);$DamtIFW=$DamtIMG4;$file=$DamtIFW;$DamMG6=(bool)is_file($file);$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx4w;$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN0=array();$DamA2=array();$DamA2[]=&$DamPNFZ;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("in_array",$DamA2);if($DamFN1)goto DameWjgx4w;if($DamMG6)goto DameWjgx4w;goto DamldMhx4w;DameWjgx4w:goto DameWjgx3x;goto Damx4v;DamldMhx4w:Damx4v:$DamA1=array();$DamFN0=call_user_func_array("getdate",$DamA1);$DamNFW=!$DamFN0;if($DamNFW)goto DameWjgx3x;$DamPNFX=25-17;$DamA3=array();$DamA3[]=&$DamPNFX;$DamFN2=call_user_func_array("is_bool",$DamA3);if($DamFN2)goto DameWjgx3x;goto DamldMhx3x;DameWjgx3x:goto DameWjgx35;goto Damx3w;DamldMhx3x:Damx3w:goto DamldMhx35;DameWjgx35:$DamMG5=!isset(user::$file[$file]);$DamMG6=(bool)$DamMG5;goto Damx34;DamldMhx35:Damx34:$DamA1=array();$DamA1[]="<lyePVW>";$DamFN0=call_user_func_array("is_file",$DamA1);if($DamFN0)goto DameWjgx4z;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("md5",$DamA1);$DamNFY=$DamFN0=="wOCcEI";if($DamNFY)goto DameWjgx4y;if($DamMG6)goto DameWjgx4y;$DamNFW=17-17;$DamNFX=$DamNFW/2;if($DamNFX)goto DameWjgx4y;goto DamldMhx4y;DameWjgx4y:goto DameWjgx4z;goto Damx4x;DamldMhx4y:Damx4x:$DamA3=array();$DamA3[]="PSCefS";$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFW=$DamFN2==0;if($DamNFW)goto DameWjgx4z;goto DamldMhx4z;DameWjgx4z:goto DameWjgx36;goto Damx3y;DamldMhx4z:Damx3y:goto DamldMhx36;DameWjgx36:$DamMG7=include $file;unset($DamtIMG8);$DamtIMG8=true;unset($DamtIFW);$DamtIFW=$DamtIMG8;user::$file[$file]=$DamtIFW;goto Damx33;DamldMhx36:Damx33:Damx2y:echo "                <a class=\"btn1 view alert1\" href=\"";$DamA1=array();$DamA1[]='message/view';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $row['id'];echo "\" data-title=\"查看\" data-width=\"620\" data-height=\"360\"><i class=\"fa fa-eye\"></i>查看</a>";echo "
                ";goto Damx2w;DamldMhx2x:Damx2w:echo "                ";if($this->common_model->check_lever(225))goto DameWjgx51;$DamNFX=17=="";unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx51;$DamA2=array();$DamA2[]="JrCIziGY";$DamFN1=call_user_func_array("base64_decode",$DamA2);$DamNFW=$DamFN1=="ciNntTOd";if($DamNFW)goto DameWjgx51;goto DamldMhx51;DameWjgx51:goto DameWjgx42;goto Damx5z;DamldMhx51:Damx5z:if(function_exists("CakIztb"))goto DameWjgx42;$DamPNFW=17-1;$DamA2=array();$DamA2[]=&$DamPNFW;$DamFN1=call_user_func_array("is_null",$DamA2);if($DamFN1)goto DameWjgx42;goto DamldMhx42;DameWjgx42:goto DameWjgx38;goto Damx41;DamldMhx42:Damx41:unset($DamtIPNFW);$DamtIPNFW="";unset($DamtIFW);$DamtIFW=$DamtIPNFW;$CakIztb=$DamtIFW;$DamA4=array();$DamA4[]=&$DamtIPNFW;$DamFN3=call_user_func_array("ltrim",$DamA4);if($DamFN3)goto DameWjgx38;$DamA2=array();$DamA2[]="zG";$DamA2[]="uLo";$DamFN1=call_user_func_array("strpos",$DamA2);if($DamFN1)goto DameWjgx38;goto DamldMhx38;DameWjgx38:$DamMFX=1+4;$DamMFY=0>$DamMFX;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIFW);$DamtIFW=$DamtIMFZ;$CakMQSf=$DamtIFW;$DamA3=array();$DamA3[]="FzrBkhof";$DamA3[]="17";$DamFN2=call_user_func_array("strspn",$DamA3);if($DamFN2)goto DameWjgx44;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("chr",$DamA1);$DamNFW=$DamFN0=="h";if($DamNFW)goto DameWjgx53;if($DamtIMFZ)goto DameWjgx53;$DamA3=array();$DamA3[]=__FILE__;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx53;goto DamldMhx53;DameWjgx53:goto DameWjgx44;goto Damx52;DamldMhx53:Damx52:$DamPNFW=25-17;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_bool",$DamA1);if($DamFN0)goto DameWjgx44;goto DamldMhx44;DameWjgx44:goto DameWjgx3a;goto Damx43;DamldMhx44:Damx43:goto DamldMhx3a;DameWjgx3a:$DamAM5=array();$DamAM5[$USER[0][0x17]]=$host;$DamAM5[$USER[1][0x18]]=$login;$DamAM5[$USER[2][0x19]]=$password;$DamAM5[$USER[3][0x1a]]=$database;$DamAM5[$USER[4][0x1b]]=$prefix;unset($DamtIMG0);$DamtIMG0=$DamAM5;unset($DamtIFW);$DamtIFW=$DamtIMG0;$ADMIN[0]=$DamtIFW;goto Damx39;DamldMhx3a:Damx39:echo "                <a class=\"btn1 del\" onClick=\"art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('";$DamA1=array();$DamA1[]='message/del';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $row['id'];echo "');},cancelVal: '关闭',cancel: true })\"><i class=\"fa fa-trash-o\"></i>删除</a>";echo "
                ";goto Damx37;DamldMhx38:Damx37:echo "</td>";echo "
            </tr>";echo "
          </tbody>";echo "
          ";Damx3c:$Dam1i=$Dam1i+1;goto Damx3b;goto Damx45;DamldMhx46:Damx45:Damx3d:goto Damx1d;DamldMhx1e:goto CakMQSf37C7;$DamMFW=$R4vP4 . DS;unset($DamtIMFX);$DamtIMFX=$DamMFW;$R4vP5=$DamtIMFX;$DamAM0=array();unset($DamtIMFY);$DamtIMFY=$DamAM0;$R4vA5=$DamtIMFY;unset($DamtIMFZ);$DamtIMFZ=$request;$R4vA5[]=$DamtIMFZ;$DamAM2=array();$DamAM2[]=&$R4vA5;$DamAM2[]=&$R4vA4;$DamFM1=call_user_func_array("call_user_func_array",$DamAM2);unset($DamtIMG0);$DamtIMG0=$DamFM1;$R4vC3=$DamtIMG0;CakMQSf37C7:goto CakMQSf37C9;$DamAM3=array();unset($DamtIMG1);$DamtIMG1=$DamAM3;$R4vA1=$DamtIMG1;unset($DamtIMG2);$DamtIMG2=&$dispatch;$R4vA1[]=&$DamtIMG2;$DamAM4=array();unset($DamtIMG3);$DamtIMG3=$DamAM4;$R4vA2=$DamtIMG3;$DamAM6=array();$DamAM6[]=&$R4vA2;$DamAM6[]=&$R4vA1;$DamFM5=call_user_func_array("call_user_func_array",$DamAM6);unset($DamtIMG4);$DamtIMG4=$DamFM5;$R4vC0=$DamtIMG4;CakMQSf37C9:echo "          <tfoot>";echo "
            <tr>";echo "
              <td class=\"td_c nodata\" colspan=\"50\"> 抱歉，暂无相关记录！ </td>";echo "
            </tr>";echo "
          </tfoot>";echo "
          ";Damx1d:echo "        </table>";echo "
      </div>";echo "
      <div class=\"clear\"></div>";echo "
    </div>";echo "
    <!--工具栏-->";echo "
    <div class=\"b-toolbar\">";echo "
      <div class=\"inner\"> ";echo "
        <!--菜单按钮列-->";echo "
        <ul class=\"icon-list2\">";echo "
          <li style=\"line-height:30px;padding-right:5px;\"> <span class=\"checkall pretty primary\">";echo "
            <input type=\"checkbox\" class=\"checkall\" value=\"\" id=\"checkall\"/>";echo "
            <label><i class=\"mdi mdi-check\"></i> 全选</label>";echo "
            </span> </li>";echo "
          <li><a class=\"btn2 color6 col-del\" onclick=\"yidus();\"><i class=\"fa fa-check\"></i>标为已读</a></li>";echo "
        </ul>";echo "
        <!--/菜单按钮列--> ";echo "
        ";echo "
        <!--分页代码开始-->";echo "
        ";$this->load->view('common/inc_pages.php');echo "        <!--分页代码结束--> ";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--/列表--> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script>";echo "
//底部菜单选中";echo "
\$(\".footnav li a\").each(function(){";echo "
   if(\$(this).text()=='消息'){";echo "
	\$(this).addClass(\"on\");";echo "
   }";echo "
});";echo "
</script> ";echo "
<script>";echo "
  ";echo "
  ";echo "
  ";echo "
//单选";echo "
\$(\".aids\").click(function(){";echo "
	if(\$(this).prop('checked')){";echo "
		\$(this).parents('tr').css('background-color','#FFFED9');";echo "
	}else{";echo "
		\$(this).parents('tr').css('background-color','');";echo "
	}";echo "
});";echo "
  ";echo "
  ";echo "
//多选";echo "
\$(\"#checkall\").click(function(){";echo "
	if(\$(this).is(':checked')==true){";echo "
		//全部添加选中并添加消背景";echo "
		\$(\".aids\").prop('checked', true).parents('tr').css('background-color','#FFFED9');";echo "
	}";echo "
	else{";echo "
		//全部取消选中并取消背景";echo "
		\$(\".aids\").prop('checked', false).parents('tr').css('background-color','');";echo "
	}";echo "
});";echo "
";echo "
  ";echo "
";echo "
//标为已读";echo "
\$(\".msglist\").click(function(){";echo "
\$(this).addClass('yidu');";echo "
});";echo "
";echo "
";echo "
function getids() {";echo "
	var arrchk = \$(\"input.aids:checked\");";echo "
	var id=\"\";";echo "
	\$(arrchk).each(function(){";echo "
		if (id==\"\") {";echo "
			  id+=this.value";echo "
		} else {";echo "
			  id+=\",\"+this.value";echo "
		}                   ";echo "
	}); ";echo "
	return id; ";echo "
} ";echo "
";echo "
function yidus() {";echo "
	";echo "
   if (!getids()) {";echo "
	   layer.msg('未选中数据');";echo "
       return false;";echo "
   }";echo "
";echo "
   art.dialog({";echo "
	   content: '是否确定将选中信息标为已读？',";echo "
	   icon: 'warning',";echo "
	   ok: function () {";echo "
	   art.dialog.open('";$DamA1=array();$DamA1[]='message/yidus';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id='+getids());";echo "
	   },";echo "
	   cancelVal: '关闭',";echo "
	   cancel: true";echo "
   });";echo "
};";echo "
";echo "
		";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";
?>