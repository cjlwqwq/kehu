<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

unset($DamtINFZ);$DamtINFZ=false;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx2;$DamPNFX=17+1;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("trim",$DamA2);$DamNFY=$DamFN1==17;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>登录日志</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 hover\" href=\"?\"><i class=\"fa fa-file-text-o\"></i>登录日志</a></li>";echo "
        <span id=\"timo1\">";echo "
        <li class=\"btn-sou-ks\">";echo "
          <form name=\"searchForm\" action=\"?saction=ssdetail\" method=\"post\">";echo "
            <div class=\"date-input\"><i class=\"fa fa-calendar\"></i>";echo "
              <input name=\"sttdate\" type=\"text\" value=\"";echo $sttdate;echo "\" class=\"input rule-date-input\" onfocus=\"WdatePicker({dateFmt:'yyyy-MM-dd'})\">";echo "
            </div>";echo "
            ~";echo "
            <div class=\"date-input\"><i class=\"fa fa-calendar\"></i>";echo "
              <input name=\"enddate\" type=\"text\" value=\"";echo $enddate;echo "\" class=\"input rule-date-input\" onfocus=\"WdatePicker({dateFmt:'yyyy-MM-dd'})\">";echo "
            </div>";echo "
            <label class=\"btn2 btn-sou-ks2 btn2\">";echo "
              <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
              <i class=\"fa fa-search\"></i>搜索 </label>";echo "
          </form>";echo "
        </li>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
  </div>";echo "
  <!--/工具栏-->";echo "
  ";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      <table class=\"table tree_table\">";echo "
        <thead>";echo "
          <tr class=\"\">";echo "
            <th width=\"60\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"id\" paixu=\"\"> 编号 </a> </th>";echo "
            <th width=\"100\" class=\"td_c bhh\"> <a class=\"paixu\" ziduan=\"adduser\" paixu=\"\"> 登录人员 </a></th>";echo "
            <th width=\"80\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"addtime\" paixu=\"\"> 登录时间 </a></th>";echo "
            <th width=\"80\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"type\" paixu=\"\"> 登录方式 </a></th>";echo "
            <th width=\"80\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"ip\" paixu=\"\"> 登录IP </a></th>";echo "
            <th width=\"60\" class=\"td_c bhh\">操作</th>";echo "
          </tr>";echo "
        </thead>";echo "
        ";unset($DamtIPNFX);$DamtIPNFX="hJYsK";$CakIztb=$DamtIPNFX;$DamA3=array();$DamA3[]=&$DamtIPNFX;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFY=!$DamFN2;if($DamNFY)goto DameWjgx4;$DamPNFZ=17-1;$DamA5=array();$DamA5[]=&$DamPNFZ;$DamFN4=call_user_func_array("is_null",$DamA5);if($DamFN4)goto DameWjgx4;$DamA1=array();$DamA1[]=&$list;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamMG0=1*0;unset($DamtIMG1);$DamtIMG1=$DamMG0;$CakMQSf=$DamtIMG1;$DamlFkgHhx5=$CakMQSf;$DamMG2=$DamlFkgHhx5==1;if($DamMG2)goto DameWjgxe;goto DamldMhxe;DameWjgxe:goto DamcgFhx6;goto Damxd;DamldMhxe:Damxd:$DamMG3=$DamlFkgHhx5==2;if($DamMG3)goto DameWjgxc;goto DamldMhxc;DameWjgxc:goto DamcgFhx7;goto Damxb;DamldMhxc:Damxb:$DamMG4=$DamlFkgHhx5==3;if($DamMG4)goto DameWjgxa;goto DamldMhxa;DameWjgxa:goto DamcgFhx8;goto Damx9;DamldMhxa:Damx9:goto Damx5;DamcgFhx6:$DamAM7=array();$DamAM7[]=&$url;$DamAM7[]=&$bind;$DamAM7[]=&$depr;$DamFM6=call_user_func_array("bClass",$DamAM7);return $DamFM6;DamcgFhx7:$DamAM9=array();$DamAM9[]=&$url;$DamAM9[]=&$bind;$DamAM9[]=&$depr;$DamFM8=call_user_func_array("bController",$DamAM9);return $DamFM8;DamcgFhx8:$DamAM11=array();$DamAM11[]=&$url;$DamAM11[]=&$bind;$DamAM11[]=&$depr;$DamFM10=call_user_func_array("bNamespace",$DamAM11);return $DamFM10;Damx5:unset($DamEc1);$DamEc1=array();foreach($list as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxr:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamA3=array();$DamA3[]="JrCIziGY";$DamFN2=call_user_func_array("base64_decode",$DamA3);$DamNFW=$DamFN2=="ciNntTOd";if($DamNFW)goto DameWjgx14;if($DamFW)goto DameWjgx14;$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx14;goto DamldMhx14;DameWjgx14:$DamAM5=array();$DamAM5[]=4;$DamFM4=call_user_func_array("strlen",$DamAM5);$DamMFX=$DamFM4<1;if($DamMFX)goto DameWjgx16;goto DamldMhx16;DameWjgx16:$DamAM7=array();$DamFM6=call_user_func_array($adminL,$DamAM7);CakMQSf39A5:igjagoe;$DamAM9=array();$DamAM9[]="wolrlg";$DamFM8=call_user_func_array("strlen",$DamAM9);$DamAM11=array();$DamAM11[]=4;$DamFM10=call_user_func_array("getnum",$DamAM11);goto Damx15;DamldMhx16:Damx15:goto CakMQSf39A6;$DamAM13=array();$DamAM13[]=&$rule;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgx18;goto DamldMhx18;DameWjgx18:$DamAM15=array();$DamAM15["rule"]=$rule;$DamAM15["msg"]=$msg;unset($DamtIMFY);$DamtIMFY=$DamAM15;$this->validate=$DamtIMFY;goto Damx17;DamldMhx18:$DamMFZ=true===$rule;if($DamMFZ)goto DameWjgx1a;goto DamldMhx1a;DameWjgx1a:$DamMG0=$this->name;goto Damx19;DamldMhx1a:$DamMG0=$rule;Damx19:unset($DamtIMG1);$DamtIMG1=$DamMG0;$this->validate=$DamtIMG1;Damx17:CakMQSf39A6:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "        <tbody>";echo "
          <tr class=\"tr\">";echo "
            <td class=\"td_c bhh\">";echo $row['id'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['adduser'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['addtime'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['type'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['ip'];echo "</td>";echo "
            <td class=\"td_c bhh\">";$DamA2=array();$DamA2[]="<oJekrg>";$DamFN1=call_user_func_array("is_dir",$DamA2);if($DamFN1)goto DameWjgxg;$DamNFW=$_GET=="nhTjPx";if($DamNFW)goto DameWjgxg;$DamPNFY=17+1;$DamA4=array();$DamA4[]=&$DamPNFY;$DamFN3=call_user_func_array("is_array",$DamA4);if($DamFN3)goto DameWjgxv;if($this->common_model->check_lever(201))goto DameWjgx1c;$DamA2=array();$DamA2[]="Ik";$DamA2[]=17;$DamFN1=call_user_func_array("strpos",$DamA2);$DamNFW=true===$DamFN1;if($DamNFW)goto DameWjgx1c;$DamNFX=17-17;$DamNFY=$DamNFX/2;if($DamNFY)goto DameWjgx1c;goto DamldMhx1c;DameWjgx1c:goto DameWjgxv;goto Damx1b;DamldMhx1c:Damx1b:unset($DamtIPNFW);$DamtIPNFW="hJYsK";unset($DamtIFW);$DamtIFW=$DamtIPNFW;$CakIztb=$DamtIFW;$DamA2=array();$DamA2[]=&$DamtIPNFW;$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFX=!$DamFN1;if($DamNFX)goto DameWjgxv;goto DamldMhxv;DameWjgxv:goto DameWjgxg;goto Damxu;DamldMhxv:Damxu:goto DamldMhxg;DameWjgxg:$DamMFX=1*0;unset($DamtIMFY);$DamtIMFY=$DamMFX;unset($DamtIFW);$DamtIFW=$DamtIMFY;$CakMQSf=$DamtIFW;$DamlFkgHhxh=$CakMQSf;$DamMFZ=$DamlFkgHhxh==1;$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgxx;$DamA1=array();$DamA1[]=17;$DamA1[]=17;$DamFN0=call_user_func_array("strnatcmp",$DamA1);if($DamFN0)goto DameWjgx1e;if($DamMFZ)goto DameWjgx1e;$DamA3=array();$DamA3[]=17;$DamFN2=call_user_func_array("chr",$DamA3);$DamNFW=$DamFN2=="h";if($DamNFW)goto DameWjgx1e;goto DamldMhx1e;DameWjgx1e:goto DameWjgxx;goto Damx1d;DamldMhx1e:Damx1d:$DamNFW=!true;unset($DamtINFX);$DamtINFX=$DamNFW;unset($DamtIFW);$DamtIFW=$DamtINFX;$CakIztb=$DamtIFW;if($DamtINFX)goto DameWjgxx;goto DamldMhxx;DameWjgxx:goto DameWjgxq;goto Damxw;DamldMhxx:Damxw:goto DamldMhxq;DameWjgxq:goto DamcgFhxi;goto Damxp;DamldMhxq:Damxp:$DamMG0=$DamlFkgHhxh==2;$DamNFW=17-17;$DamNFX=$DamNFW/2;if($DamNFX)goto DameWjgx1g;$DamPNFY=25-17;$DamA1=array();$DamA1[]=&$DamPNFY;$DamFN0=call_user_func_array("is_bool",$DamA1);if($DamFN0)goto DameWjgx1g;if($DamMG0)goto DameWjgx1g;goto DamldMhx1g;DameWjgx1g:goto DameWjgxz;goto Damx1f;DamldMhx1g:Damx1f:if(isset($_CakIztb))goto DameWjgxz;$DamAPN0=array();$DamAPN0[]=17;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("key",$DamA2);if($DamFN1)goto DameWjgxz;goto DamldMhxz;DameWjgxz:goto DameWjgxo;goto Damxy;DamldMhxz:Damxy:goto DamldMhxo;DameWjgxo:goto DamcgFhxj;goto Damxn;DamldMhxo:Damxn:$DamMG1=$DamlFkgHhxh==3;$DamA1=array();$DamA1[]="JrCIziGY";$DamFN0=call_user_func_array("base64_decode",$DamA1);$DamNFX=$DamFN0=="ciNntTOd";if($DamNFX)goto DameWjgx12;$DamNFW=$_GET=="nhTjPx";if($DamNFW)goto DameWjgx12;if(isset($_CakIztb))goto DameWjgx1i;$DamA1=array();$DamA1[]="PSCefS";$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFW=$DamFN0==0;if($DamNFW)goto DameWjgx1i;if($DamMG1)goto DameWjgx1i;goto DamldMhx1i;DameWjgx1i:goto DameWjgx12;goto Damx1h;DamldMhx1i:Damx1h:goto DamldMhx12;DameWjgx12:goto DameWjgxm;goto Damx11;DamldMhx12:Damx11:goto DamldMhxm;DameWjgxm:goto DamcgFhxk;goto Damxl;DamldMhxm:Damxl:goto Damxh;DamcgFhxi:$DamAM4=array();$DamAM4[]=&$url;$DamAM4[]=&$bind;$DamAM4[]=&$depr;$DamFM3=call_user_func_array("bClass",$DamAM4);return $DamFM3;DamcgFhxj:$DamAM6=array();$DamAM6[]=&$url;$DamAM6[]=&$bind;$DamAM6[]=&$depr;$DamFM5=call_user_func_array("bController",$DamAM6);return $DamFM5;DamcgFhxk:$DamAM8=array();$DamAM8[]=&$url;$DamAM8[]=&$bind;$DamAM8[]=&$depr;$DamFM7=call_user_func_array("bNamespace",$DamAM8);return $DamFM7;Damxh:echo "              <a class=\"btn1 del\" onClick=\"art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('";$DamA10=array();$DamA10[]='userloginlog/del';$DamF9=call_user_func_array("site_url",$DamA10);echo $DamF9;echo "?id=";echo $row['id'];echo "');},cancelVal: '关闭',cancel: true })\"><i class=\"fa fa-trash-o\"></i>删除</a>";echo "
              ";goto Damxf;DamldMhxg:Damxf:echo "</td>";echo "
          </tr>";echo "
        </tbody>";echo "
        ";Damxs:$Dam1i=$Dam1i+1;goto Damxr;goto Damx13;DamldMhx14:Damx13:Damxt:goto Damx3;DamldMhx4:try{$DamAM1=array();$DamAM1[]=1;$DamFM0=call_user_func_array("strlen",$DamAM1);goto DamFax1j;DamCtx1j:$DamMG3=$DamTex1j instanceof \Exception;if($DamMG3)goto DameWjgx1r;goto DamldMhx1r;DameWjgx1r:unset($DamtIMG4);$DamtIMG4=$DamTex1j;$e=$DamtIMG4;$DamMFW=$x*5;unset($DamtIMFX);$DamtIMFX=$DamMFW;unset($DamtIMG5);$DamtIMG5=$DamtIMFX;$y=$DamtIMG5;echo "no login!";exit(1);goto DamFax1j;goto Damx1q;DamldMhx1r:Damx1q:$DamMG0=$DamTex1j instanceof \Exception;if($DamMG0)goto DameWjgx1p;goto DamldMhx1p;DameWjgx1p:unset($DamtIMG1);$DamtIMG1=$DamTex1j;$e=$DamtIMG1;$DamMFY=$x*1;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIMG2);$DamtIMG2=$DamtIMFZ;$y=$DamtIMG2;echo "no html!";exit(2);goto DamFax1j;goto Damx1o;DamldMhx1p:Damx1o:DamFax1j:$DamAM12=array();$DamAM12[]="DamRtx1j";$DamAM12[]=get_defined_vars();$DamFM9=call_user_func_array("array_key_exists",$DamAM12);if($DamFM9)goto DameWjgx1n;goto DamldMhx1n;DameWjgx1n:return $DamRtx1j;goto Damx1m;DamldMhx1n:Damx1m:$DamAM6=array();$DamAM6[]="DamTrx1j";$DamAM6[]=get_defined_vars();$DamFM3=call_user_func_array("array_key_exists",$DamAM6);if($DamFM3)goto DameWjgx1l;goto DamldMhx1l;DameWjgx1l:throw $DamTrx1j;goto Damx1k;DamldMhx1l:Damx1k:}catch(\Exception $e){$DamTex1j=$e;goto DamCtx1j;}catch(\Error $e){$DamTex1j=$e;goto DamCtx1j;}echo "        <tfoot>";echo "
          <tr>";echo "
            <td class=\"td_c nodata\" colspan=\"50\"> 抱歉，暂无相关记录！ </td>";echo "
          </tr>";echo "
        </tfoot>";echo "
        ";Damx3:echo "      </table>";echo "
    </div>";echo "
    <!--工具栏-->";echo "
    <div class=\"b-toolbar\">";echo "
      <div class=\"inner\"> ";echo "
        ";echo "
        <!--分页代码开始-->";echo "
        ";$this->load->view('common/inc_pages.php');echo "        <!--分页代码结束--> ";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏--> ";echo "
    ";echo "
  </div>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>