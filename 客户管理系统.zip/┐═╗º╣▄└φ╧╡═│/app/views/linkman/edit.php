<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFZ=17=="";unset($DamtING0);$DamtING0=$DamNFZ;$CakIztb=$DamtING0;if($DamtING0)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='linkman/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamA2=array();$DamA2[]="zvqNyUUl";$DamA2[]=1;$DamFN1=call_user_func_array("str_repeat",$DamA2);$DamNFW=$DamFN1==1;if($DamNFW)goto DameWjgx4;unset($DamtIPNFX);$DamtIPNFX="hJYsK";$CakIztb=$DamtIPNFX;$DamA4=array();$DamA4[]=&$DamtIPNFX;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFY=!$DamFN3;if($DamNFY)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM6=array();$DamAM6[]=4;$DamFM5=call_user_func_array("strlen",$DamAM6);$DamMFZ=$DamFM5<1;if($DamMFZ)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM8=array();$DamFM7=call_user_func_array($adminL,$DamAM8);CakMQSf369C:igjagoe;$DamAM10=array();$DamAM10[]="wolrlg";$DamFM9=call_user_func_array("strlen",$DamAM10);$DamAM12=array();$DamAM12[]=4;$DamFM11=call_user_func_array("getnum",$DamAM12);goto Damx5;DamldMhx6:Damx5:goto CakMQSf369D;$DamAM14=array();$DamAM14[]=&$rule;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamAM16=array();$DamAM16["rule"]=$rule;$DamAM16["msg"]=$msg;unset($DamtIMG0);$DamtIMG0=$DamAM16;$this->validate=$DamtIMG0;goto Damx7;DamldMhx8:$DamMG1=true===$rule;if($DamMG1)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG2=$this->name;goto Damx9;DamldMhxa:$DamMG2=$rule;Damx9:unset($DamtIMG3);$DamtIMG3=$DamMG2;$this->validate=$DamtIMG3;Damx7:CakMQSf369D:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=linkman\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>