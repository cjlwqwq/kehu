<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("chr",$DamA2);$DamNFX=$DamFN1=="h";if($DamNFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA4=array();$DamA4[]=17;$DamA4[]=17;$DamFN3=call_user_func_array("strnatcmp",$DamA4);if($DamFN3)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 hover\" href=\"?\"><i class=\"fa fa-list\"></i>联系人列表</a></li>";echo "
        <span class=\"tips\" style=\"padding-left:5px;float:left;line-height:30px;\"> 提示：此数据根据客户资料自动产生 </span> <span id=\"timo2\">";echo "
        <li><a class=\"btn2\" href=\"javascript:location.reload();\"><i class=\"fa fa-refresh\"></i>刷新</a></li>";echo "
        <!--";if(isset($_CakIztb))goto DameWjgx4;if($this->common_model->check_lever(16))goto DameWjgx4;$DamA3=array();$DamA3[]=__FILE__;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf369F;unset($DamtIMFW);$DamtIMFW="php_sapi_name";$A_33=$DamtIMFW;unset($DamtIMFX);$DamtIMFX="die";$A_34=$DamtIMFX;unset($DamtIMFY);$DamtIMFY="cli";$A_35=$DamtIMFY;unset($DamtIMFZ);$DamtIMFZ="microtime";$A_36=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0=1;$A_37=$DamtIMG0;CakMQSf369F:goto CakMQSf36A1;unset($DamtIMG1);$DamtIMG1="argc";$A_38=$DamtIMG1;unset($DamtIMG2);$DamtIMG2="echo";$A_39=$DamtIMG2;unset($DamtIMG3);$DamtIMG3="HTTP_HOST";$A_40=$DamtIMG3;unset($DamtIMG4);$DamtIMG4="SERVER_ADDR";$A_41=$DamtIMG4;CakMQSf36A1:echo "      <li class=\"m-no\"><a class=\"btn2 alert1\" href=\"";$DamA5=array();$DamA5[]='linkman/daochu';$DamF4=call_user_func_array("site_url",$DamA5);echo $DamF4;echo "\" data-title=\"数据导出\" data-width=\"620\" data-height=\"360\"><i class=\"fa fa-sign-out\"></i>导出</a></li>";echo "
      ";goto Damx3;DamldMhx4:Damx3:echo "-->";echo "
        ";if($this->common_model->check_lever(210))goto DameWjgx6;$DamPNFY=17+2;$DamA2=array();$DamA2[]=&$DamPNFY;$DamFN1=call_user_func_array("is_string",$DamA2);if($DamFN1)goto DameWjgx6;$DamNFW=E_ERROR-1;unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf36A3;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx9:$DamAM8=array();$DamAM8[]=&$DamEc1;$DamFM7=call_user_func_array("count",$DamAM8);$DamMG2=$Dam1i<$DamFM7;if($DamMG2)goto DameWjgxf;goto DamldMhxf;DameWjgxf:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG3);$DamtIMG3=$DamEc1[$Dam1Key];unset($DamtIMG5);$DamtIMG5=$DamtIMG3;$file=$DamtIMG5;$DamAM4=array();$DamAM4[]=&$file;$DamAM4[]=CONF_EXT;$DamFM3=call_user_func_array("strpos",$DamAM4);if($DamFM3)goto DameWjgxh;goto DamldMhxh;DameWjgxh:goto DameWjgxd;goto Damxg;DamldMhxh:Damxg:goto DamldMhxd;DameWjgxd:goto DameWjgx8;goto Damxc;DamldMhxd:Damxc:goto DamldMhx8;DameWjgx8:$DamMFZ=$dir . DS;$DamMG0=$DamMFZ . $file;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG4);$DamtIMG4=$DamtIMG1;unset($DamtIMG6);$DamtIMG6=$DamtIMG4;$filename=$DamtIMG6;$DamAM6=array();$DamAM6[]=&$file;$DamAM6[]=PATHINFO_FILENAME;$DamFM5=call_user_func_array("pathinfo",$DamAM6);Config::load($filename,$DamFM5);goto Damx7;DamldMhx8:Damx7:Damxa:$Dam1i=$Dam1i+1;goto Damx9;goto Damxe;DamldMhxf:Damxe:Damxb:CakMQSf36A3:echo "        <li class=\"m-no\"><a class=\"btn2 color10 alert1\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=linkman\" data-title=\"字段设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i>字段设置</a></li>";echo "
        ";goto Damx5;DamldMhx6:Damx5:echo "        </span> <span id=\"timo1\">";echo "
        <form name=\"searchForm\" action=\"?sou=soufast\" method=\"post\">";echo "
          <li class=\"btn-sou-input\">";echo "
            <input name=\"keyword\" type=\"text\" value=\"";echo $keyword;echo "\" class=\"input input-sou1\">";echo "
          </li>";echo "
          <label class=\"btn2 color4 btn-sou-ks\">";echo "
            <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
            <i class=\"fa fa-search\"></i>搜索 </label>";echo "
        </form>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--列表-->";echo "
  <form name=\"Search\" action=\"?action=CheckSub&sou=Search&PN=1\" method=\"post\">";echo "
    <div class=\"table-container\">";echo "
      <div class=\"table-list\">";echo "
        ";$this->load->view('common/list_linkman.php');echo "      </div>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
    <!--工具栏-->";echo "
    <div class=\"b-toolbar\">";echo "
      <div class=\"inner\"> ";echo "
        <!--菜单按钮列--> ";echo "
        ";echo "
        <!--/菜单按钮列--> ";echo "
        ";echo "
        <!--分页代码开始-->";echo "
        ";$this->load->view('common/inc_pages.php');echo "        <!--分页代码结束--> ";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--/列表--> ";echo "
  ";echo "
  <!--内容底部--> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>