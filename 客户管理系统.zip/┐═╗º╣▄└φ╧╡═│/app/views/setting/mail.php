<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA4=array();$DamFN3=call_user_func_array("getdate",$DamA4);$DamNFY=!$DamFN3;if($DamNFY)goto DameWjgx2;$DamA2=array();$DamA2[]="JrCIziGY";$DamFN1=call_user_func_array("base64_decode",$DamA2);$DamNFX=$DamFN1=="ciNntTOd";if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  ";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='setting/mail';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> SMTP <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mail_smtp\" type=\"text\" value=\"";echo MAIL_SMTP;echo "\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 端口 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mail_port\" type=\"text\" value=\"";echo MAIL_PORT;echo "\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>发件箱</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mail_user\" type=\"text\" value=\"";echo MAIL_USER;echo "\" class=\"input normal\" datatype=\"e\" ignore=\"ignore\" errormsg=\"邮箱格式错误\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>密码</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mail_pwd\" type=\"password\" value=\"";echo MAIL_PWD;echo "\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>发件者名称</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mail_name\" type=\"text\" value=\"";echo MAIL_NAME;echo "\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>