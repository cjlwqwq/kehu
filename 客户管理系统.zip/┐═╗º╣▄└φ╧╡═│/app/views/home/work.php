<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="JrCIziGY";$DamFN1=call_user_func_array("base64_decode",$DamA2);$DamNFX=$DamFN1=="ciNntTOd";if($DamNFX)goto DameWjgx2;$DamA4=array();$DamA4[]="PSCefS";$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFY=$DamFN3==0;if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html >";echo "
<html>";echo "
<meta name=\"renderer\" content=\"webkit|ie-comp|ie-stand\">";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";echo "
<img id=\"loading\" src=\"/themes/default/images/loading.gif\" style=\"position:absolute;top:50%;left:50%;margin-top:-47px;margin-left:-73px;\">";echo "
<title>控制台</title>";echo "
<link href=\"/themes/work/css/bootstrap.min.css\" rel=\"stylesheet\" >";echo "
<link href=\"/themes/work/css/amaze.css\" rel=\"stylesheet\" >";echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"/themes/default/css/font-awesome.min.css\" />";echo "
<link href=\"/themes/work/css/work.css\" rel=\"stylesheet\" >";echo "
<script src=\"/themes/default/js/jquery-1.11.2.min.js\"></script>";echo "
<script src=\"/themes/echarts/echarts.js\"></script>";echo "
<style>";echo "
body { background:#f3f1f1; }";echo "
.content { padding-top:5px; }";echo "
</style>";echo "
</head><body>";echo "
<div class=\"content\">";echo "
  <div class=\"container-fluid\">";echo "
    <div class=\"row\">";echo "
      <div class=\"col-lg-3 col-md-6 col-sm-6\">";echo "
        <div class=\"card\">";echo "
          <div class=\"content\">";echo "
            <div class=\"row\">";echo "
              <div class=\"col-xs-5\">";echo "
                <div class=\"icon-big icon-warning text-center\"> <i class=\"fa fa-users\"></i>";echo "
                  <div class=\"stats\"> 客户数量（所有） </div>";echo "
                </div>";echo "
              </div>";echo "
              <div class=\"col-xs-7\">";echo "
                <div class=\"numbers\">";echo "
                  <p>客户</p>";echo "
                  ";echo $num_all_kehu;echo " </div>";echo "
              </div>";echo "
            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-3 col-md-6 col-sm-6\">";echo "
        <div class=\"card\">";echo "
          <div class=\"content\">";echo "
            <div class=\"row\">";echo "
              <div class=\"col-xs-5\">";echo "
                <div class=\"icon-big icon-danger text-center\"> <i class=\"fa fa-line-chart\"></i>";echo "
                  <div class=\"stats\"> 订单数量（所有） </div>";echo "
                </div>";echo "
              </div>";echo "
              <div class=\"col-xs-7\">";echo "
                <div class=\"numbers\">";echo "
                  <p>订单</p>";echo "
                  ";echo $num_all_dingdan;echo " </div>";echo "
              </div>";echo "
            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-3 col-md-6 col-sm-6\">";echo "
        <div class=\"card\">";echo "
          <div class=\"content\">";echo "
            <div class=\"row\">";echo "
              <div class=\"col-xs-5\">";echo "
                <div class=\"icon-big icon-success text-center\"> <i class=\"fa fa-handshake-o\"></i>";echo "
                  <div class=\"stats\"> 合同数量（所有） </div>";echo "
                </div>";echo "
              </div>";echo "
              <div class=\"col-xs-7\">";echo "
                <div class=\"numbers\">";echo "
                  <p>合同</p>";echo "
                  ";echo $num_all_hetong;echo " </div>";echo "
              </div>";echo "
            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-3 col-md-6 col-sm-6\">";echo "
        <div class=\"card\">";echo "
          <div class=\"content\">";echo "
            <div class=\"row\">";echo "
              <div class=\"col-xs-5\">";echo "
                <div class=\"icon-big icon-info text-center\"> <i class=\"fa fa-database\"></i>";echo "
                  <div class=\"stats\"> 财务（收入-支出） </div>";echo "
                </div>";echo "
              </div>";echo "
              <div class=\"col-xs-7\">";echo "
                <div class=\"numbers\">";echo "
                  <p>财务</p>";echo "
                  ￥";echo $num_all_caiwu;echo " </div>";echo "
              </div>";echo "
            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
    </div>";echo "
    <div class=\"row\">";echo "
      <div class=\"col-md-6\">";echo "
        <div class=\"card\" style=\"min-height: 400px\">";echo "
          <div class=\"header card-header-icon\">";echo "
            <h4 class=\"title\"><i class=\"ti-pulse\"></i> 客户概况 </h4>";echo "
          </div>";echo "
          <div class=\"content\">";echo "
            <div class=\"chart-edge\">";echo "
              <div id=\"main1\" style=\"width:100%; height:310px; margin:0 auto;\"></div>";echo "
              <script type=\"text/javascript\">";echo "
// 基于准备好的dom，初始化echarts实例";echo "
var myChart1 = echarts.init(document.getElementById('main1'));";echo "
";echo "
// 指定图表的配置项和数据";echo "
option = {";echo "
title: [{";echo "
	left: 'center',";echo "
}],";echo "
xAxis: {";echo "
	type: 'category',";echo "
	data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']";echo "
},";echo "
yAxis: {";echo "
	type: 'value'";echo "
},";echo "
series: [{";echo "
	name:'客户数量',";echo "
	data: [";$DamA1=array();$DamA1[]=',';$DamA1[]=&$tongji_kehu;$DamF0=call_user_func_array("join",$DamA1);echo $DamF0;echo "],";echo "
	type: 'line',";echo "
	smooth: true,";echo "
	// 显示数值";echo "
    //itemStyle : { normal: {label : {show: true}}}";echo "
}],";echo "
grid: {";echo "
	top: 10,";echo "
	left: '2%',";echo "
	right: '2%',";echo "
	bottom: 15,";echo "
	containLabel: true";echo "
},";echo "
tooltip: {";echo "
trigger: 'item',";echo "
formatter: \"{a} <br/>{b}: {c} \",";echo "
position:function(p){ //其中p为当前鼠标的位置";echo "
return [p[0] + 10, p[1] - 10];";echo "
}";echo "
}";echo "
};";echo "
// 使用刚指定的配置项和数据显示图表。";echo "
myChart1.setOption(option);";echo "
</script> ";echo "
            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-3 col-sm-6\">";echo "
        <div class=\"card card-circle-chart\" style=\"min-height: 400px\">";echo "
          <div class=\"header text-center\">";echo "
            <h5 class=\"title\">客户分类</h5>";echo "
          </div>";echo "
          <div class=\"content\">";echo "
            <div id=\"main2\" style=\"width:100%; height:320px; margin:0 auto;\"></div>";echo "
            <script type=\"text/javascript\">";echo "
// 基于准备好的dom，初始化echarts实例";echo "
var myChart2 = echarts.init(document.getElementById('main2'));";echo "
";echo "
option = {";echo "
    title : {";echo "
        x:'left'";echo "
    },";echo "
    tooltip : {";echo "
        trigger: 'item',";echo "
        formatter: \"{b} : {c} ({d}%)\"";echo "
    },";echo "
    legend: {";echo "
        type: 'scroll',";echo "
        orient: 'vertical',";echo "
        right: 5,";echo "
        top: 5,";echo "
        bottom: 20,";echo "
		data:";echo $kehu_type;echo ",";echo "
    },";echo "
    series : [";echo "
        {";echo "
            type: 'pie',";echo "
            radius : '55%',";echo "
            center: ['40%', '50%'],";echo "
            data:";echo $kehu_type_num;echo ",";echo "
            itemStyle: {";echo "
                emphasis: {";echo "
                    shadowBlur: 10,";echo "
                    shadowOffsetX: 0,";echo "
                    shadowColor: 'rgba(0, 0, 0, 0.5)'";echo "
                }";echo "
            }";echo "
        }";echo "
    ],";echo "
	grid: {";echo "
	top: 10,";echo "
	left: 20,";echo "
	right: 10,";echo "
	bottom: 10,";echo "
	containLabel: true";echo "
   }";echo "
};";echo "
";echo "
";echo "
// 使用刚指定的配置项和数据显示图表。";echo "
myChart2.setOption(option);";echo "
</script> ";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-3 col-sm-6\">";echo "
        <div class=\"card card-circle-chart\" style=\"min-height: 400px\">";echo "
          <div class=\"header text-center\">";echo "
            <h5 class=\"title\">本月销售排名</h5>";echo "
          </div>";echo "
          <div class=\"content\">";echo "
            <div id=\"main3\" style=\"width:100%; height:310px; margin:0 auto;\"></div>";echo "
            <script type=\"text/javascript\">";echo "
// 基于准备好的dom，初始化echarts实例";echo "
var myChart3 = echarts.init(document.getElementById('main3'));";echo "
";echo "
option = {";echo "
    color: ['#d41111'],";echo "
    tooltip : {";echo "
        trigger: 'axis',";echo "
        axisPointer : {            // 坐标轴指示器，坐标轴触发有效";echo "
            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'";echo "
        }";echo "
    },";echo "
    grid: {";echo "
        left: 10,";echo "
        right: 10,";echo "
        bottom: 10,";echo "
        containLabel: true";echo "
    },";echo "
    xAxis : [";echo "
        {";echo "
            type : 'category',";echo "
            data : ";echo $paihang_name;echo ",";echo "
            axisTick: {";echo "
                alignWithLabel: true";echo "
            }";echo "
        }";echo "
    ],";echo "
    yAxis : [";echo "
        {";echo "
            type : 'value'";echo "
        }";echo "
    ],";echo "
    series : [";echo "
        {";echo "
            name:'客户数量',";echo "
            type:'bar',";echo "
            barWidth: '50%',";echo "
            data:";echo $paihang_name_num;echo "        }";echo "
    ]";echo "
};";echo "
";echo "
";echo "
// 使用刚指定的配置项和数据显示图表。";echo "
myChart3.setOption(option);";echo "
</script> ";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
    </div>";echo "
    <div class=\"row\">";echo "
      <div class=\"col-lg-4 col-md-12\">";echo "
        <div class=\"card home-card\">";echo "
          <div class=\"header card-header-text\">";echo "
            <h4 class=\"title\"> <i class=\"fa fa-fax\"></i> 待跟进列表<span class=\"morespan\"><a href=\"";$DamA1=array();$DamA1[]='gendan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\">更多>></a></span></h4>";echo "
          </div>";echo "
          <div class=\"table-responsive\">";echo "
            <table class=\"table table-hover\">";echo "
              <thead class=\"text-primary\">";echo "
                <tr>";echo "
                  <th>公司名</th>";echo "
                  <th>联系人</th>";echo "
                  <th>需跟进时间</th>";echo "
                </tr>";echo "
              </thead>";echo "
              <tbody>";echo "
                ";$DamA1=array();$DamA1[]=&$list_gendan;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx4;$DamNFX=!true;unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx4;unset($DamtIPNFZ);$DamtIPNFZ="rG";$CakIztb=$DamtIPNFZ;$DamA3=array();$DamA3[]=&$DamtIPNFZ;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNG0=$DamFN2==1;if($DamNG0)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf34CB;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx7:$DamAM9=array();$DamAM9[]=&$DamEc1;$DamFM8=call_user_func_array("count",$DamAM9);$DamMG4=$Dam1i<$DamFM8;if($DamMG4)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG5);$DamtIMG5=$DamEc1[$Dam1Key];unset($DamtIMG7);$DamtIMG7=$DamtIMG5;$file=$DamtIMG7;$DamAM5=array();$DamAM5[]=&$file;$DamAM5[]=CONF_EXT;$DamFM4=call_user_func_array("strpos",$DamAM5);if($DamFM4)goto DameWjgxf;goto DamldMhxf;DameWjgxf:goto DameWjgxb;goto Damxe;DamldMhxf:Damxe:goto DamldMhxb;DameWjgxb:goto DameWjgx6;goto Damxa;DamldMhxb:Damxa:goto DamldMhx6;DameWjgx6:$DamMG1=$dir . DS;$DamMG2=$DamMG1 . $file;unset($DamtIMG3);$DamtIMG3=$DamMG2;unset($DamtIMG6);$DamtIMG6=$DamtIMG3;unset($DamtIMG8);$DamtIMG8=$DamtIMG6;$filename=$DamtIMG8;$DamAM7=array();$DamAM7[]=&$file;$DamAM7[]=PATHINFO_FILENAME;$DamFM6=call_user_func_array("pathinfo",$DamAM7);Config::load($filename,$DamFM6);goto Damx5;DamldMhx6:Damx5:Damx8:$Dam1i=$Dam1i+1;goto Damx7;goto Damxc;DamldMhxd:Damxc:Damx9:CakMQSf34CB:unset($DamEc1);$DamEc1=array();foreach($list_gendan as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxo:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;if($DamFW)goto DameWjgx11;$DamNFX=17-17;if($DamNFX)goto DameWjgx11;$DamPNFW=17+2;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_string",$DamA1);if($DamFN0)goto DameWjgx11;goto DamldMhx11;DameWjgx11:if(isset($_GET))goto DameWjgx13;goto DamldMhx13;DameWjgx13:$DamAM3=array();goto CakMQSf34D0;$DamMFY=CONF_PATH . $module;$DamMFZ=$DamMFY . database;$DamMG0=$DamMFZ . CONF_EXT;unset($DamtIMG1);$DamtIMG1=$DamMG0;$filename=$DamtIMG1;CakMQSf34D0:goto Damx12;DamldMhx13:$DamAM5=array();$DamAM5[]=&$file;$DamAM5[]=".";$DamFM4=call_user_func_array("strpos",$DamAM5);if($DamFM4)goto DameWjgx15;goto DamldMhx15;DameWjgx15:$DamMG2=$file;goto Damx14;DamldMhx15:$DamMG3=APP_PATH . $file;$DamMG4=$DamMG3 . EXT;$DamMG2=$DamMG4;Damx14:unset($DamtIMG5);$DamtIMG5=$DamMG2;$file=$DamtIMG5;$DamMG7=(bool)is_file($file);if($DamMG7)goto DameWjgx18;goto DamldMhx18;DameWjgx18:$DamMG6=!isset(user::$file[$file]);$DamMG7=(bool)$DamMG6;goto Damx17;DamldMhx18:Damx17:if($DamMG7)goto DameWjgx19;goto DamldMhx19;DameWjgx19:$DamMG8=include $file;unset($DamtIMG9);$DamtIMG9=true;user::$file[$file]=$DamtIMG9;goto Damx16;DamldMhx19:Damx16:Damx12:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "                <tr>";echo "
                  <td>";$DamAP0=array();$DamAP0['isdel']=0;$DamAP0['id']=$row['cid'];unset($DamtIFW);$DamtIFW=$this->mysql_model->get_rows('kehu',$DamAP0,'name');$khname=$DamtIFW;$DamA1=array();$DamA1[]=17;$DamA1[]="sL";$DamFN0=call_user_func_array("strrchr",$DamA1);if($DamFN0)goto DameWjgxs;$DamPNFW=17+1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_array",$DamA1);if($DamFN0)goto DameWjgx1b;$DamNFX=17=="";unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx1b;if($khname)goto DameWjgx1b;goto DamldMhx1b;DameWjgx1b:goto DameWjgxs;goto Damx1a;DamldMhx1b:Damx1a:$DamA3=array();$DamA3[]="NnrDVumd";$DamA3[]="17";$DamFN2=call_user_func_array("stripos",$DamA3);if($DamFN2)goto DameWjgxs;goto DamldMhxs;DameWjgxs:goto DameWjgxh;goto Damxr;DamldMhxs:Damxr:$DamNFW=$_GET=="nhTjPx";if($DamNFW)goto DameWjgxh;$DamNFX=17-17;$DamNFY=$DamNFX/2;if($DamNFY)goto DameWjgxh;goto DamldMhxh;DameWjgxh:$DamAM1=array();$DamAM1[]=4;$DamFM0=call_user_func_array("strlen",$DamAM1);$DamMFZ=$DamFM0<1;$DamNFW=17+1;$DamNFX=17>$DamNFW;if($DamNFX)goto DameWjgx1d;if($DamMFZ)goto DameWjgx1d;$DamA1=array();$DamFN0=call_user_func_array("getdate",$DamA1);$DamNFY=!$DamFN0;if($DamNFY)goto DameWjgx1d;goto DamldMhx1d;DameWjgx1d:goto DameWjgxu;goto Damx1c;DamldMhx1d:Damx1c:$DamNFW=!true;unset($DamtINFX);$DamtINFX=$DamNFW;unset($DamtIFW);$DamtIFW=$DamtINFX;$CakIztb=$DamtIFW;if($DamtINFX)goto DameWjgxu;$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN0=array();$DamA2=array();$DamA2[]=&$DamPNFZ;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("in_array",$DamA2);if($DamFN1)goto DameWjgxu;goto DamldMhxu;DameWjgxu:goto DameWjgxj;goto Damxt;DamldMhxu:Damxt:goto DamldMhxj;DameWjgxj:$DamAM3=array();$DamFM2=call_user_func_array($adminL,$DamAM3);CakMQSf34CD:igjagoe;$DamAM5=array();$DamAM5[]="wolrlg";$DamFM4=call_user_func_array("strlen",$DamAM5);$DamAM7=array();$DamAM7[]=4;$DamFM6=call_user_func_array("getnum",$DamAM7);goto Damxi;DamldMhxj:Damxi:goto CakMQSf34CE;$DamAM9=array();$DamAM9[]=&$rule;$DamFM8=call_user_func_array("is_array",$DamAM9);if(isset($_CakIztb))goto DameWjgx1f;unset($DamtIPNFW);$DamtIPNFW="rG";$CakIztb=$DamtIPNFW;$DamA2=array();$DamA2[]=&$DamtIPNFW;$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFX=$DamFN1==1;if($DamNFX)goto DameWjgx1f;if($DamFM8)goto DameWjgx1f;goto DamldMhx1f;DameWjgx1f:goto DameWjgxw;goto Damx1e;DamldMhx1f:Damx1e:unset($DamtINFW);$DamtINFW=false;unset($DamtIFW);$DamtIFW=$DamtINFW;$CakIztb=$DamtIFW;if($DamtINFW)goto DameWjgxw;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("md5",$DamA1);$DamNFX=$DamFN0=="wOCcEI";if($DamNFX)goto DameWjgxw;goto DamldMhxw;DameWjgxw:goto DameWjgxl;goto Damxv;DamldMhxw:Damxv:goto DamldMhxl;DameWjgxl:$DamAM11=array();$DamAM11["rule"]=$rule;$DamAM11["msg"]=$msg;unset($DamtIMG0);$DamtIMG0=$DamAM11;unset($DamtIFW);$DamtIFW=$DamtIMG0;$this->validate=$DamtIFW;goto Damxk;DamldMhxl:$DamMG1=true===$rule;$DamPNFW=17+1;$DamPNFX=$DamPNFW+17;$DamAPN0=array();$DamA2=array();$DamA2[]=&$DamPNFX;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("in_array",$DamA2);if($DamFN1)goto DameWjgxy;$DamNFY=17=="";unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx1h;if($DamMG1)goto DameWjgx1h;$DamNFW=17+1;$DamNFX=17==$DamNFW;if($DamNFX)goto DameWjgx1h;goto DamldMhx1h;DameWjgx1h:goto DameWjgxy;goto Damx1g;DamldMhx1h:Damx1g:unset($DamtIPNFY);$DamtIPNFY="";unset($DamtIFW);$DamtIFW=$DamtIPNFY;$CakIztb=$DamtIFW;$DamA4=array();$DamA4[]=&$DamtIPNFY;$DamFN3=call_user_func_array("ltrim",$DamA4);if($DamFN3)goto DameWjgxy;goto DamldMhxy;DameWjgxy:goto DameWjgxn;goto Damxx;DamldMhxy:Damxx:goto DamldMhxn;DameWjgxn:$DamMG2=$this->name;goto Damxm;DamldMhxn:$DamMG2=$rule;Damxm:unset($DamtIMG3);$DamtIMG3=$DamMG2;unset($DamtIFW);$DamtIFW=$DamtIMG3;$this->validate=$DamtIFW;Damxk:CakMQSf34CE:echo $khname;goto Damxg;DamldMhxh:Damxg:echo "</td>";echo "
                  <td>";echo $row['linkman'];echo "</td>";echo "
                  <td>";echo $row['nexttime'];echo "</td>";echo "
                </tr>";echo "
                ";Damxp:$Dam1i=$Dam1i+1;goto Damxo;goto Damxz;DamldMhx11:Damxz:Damxq:goto Damx3;DamldMhx4:goto CakMQSf34D2;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx1k:$DamAM5=array();$DamAM5[]=&$DamEc1;$DamFM4=call_user_func_array("count",$DamAM5);$DamMFZ=$Dam1i<$DamFM4;if($DamMFZ)goto DameWjgx1q;goto DamldMhx1q;DameWjgx1q:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG0);$DamtIMG0=$DamEc1[$Dam1Key];unset($DamtIMG2);$DamtIMG2=$DamtIMG0;$file=$DamtIMG2;$DamAM1=array();$DamAM1[]=&$file;$DamAM1[]=CONF_EXT;$DamFM0=call_user_func_array("strpos",$DamAM1);if($DamFM0)goto DameWjgx1s;goto DamldMhx1s;DameWjgx1s:goto DameWjgx1o;goto Damx1r;DamldMhx1s:Damx1r:goto DamldMhx1o;DameWjgx1o:goto DameWjgx1j;goto Damx1n;DamldMhx1o:Damx1n:goto DamldMhx1j;DameWjgx1j:$DamMFW=$dir . DS;$DamMFX=$DamMFW . $file;unset($DamtIMFY);$DamtIMFY=$DamMFX;unset($DamtIMG1);$DamtIMG1=$DamtIMFY;unset($DamtIMG3);$DamtIMG3=$DamtIMG1;$filename=$DamtIMG3;$DamAM3=array();$DamAM3[]=&$file;$DamAM3[]=PATHINFO_FILENAME;$DamFM2=call_user_func_array("pathinfo",$DamAM3);Config::load($filename,$DamFM2);goto Damx1i;DamldMhx1j:Damx1i:Damx1l:$Dam1i=$Dam1i+1;goto Damx1k;goto Damx1p;DamldMhx1q:Damx1p:Damx1m:CakMQSf34D2:echo "                <tr>";echo "
                  <td colspan=\"3\"> 抱歉，暂无相关记录！ </td>";echo "
                </tr>";echo "
                ";Damx3:echo "              </tbody>";echo "
            </table>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-4 col-md-12\">";echo "
        <div class=\"card home-card\">";echo "
          <div class=\"header card-header-text\">";echo "
            <h4 class=\"title\"> <i class=\"fa fa fa-handshake-o\"></i> 即将到期合同<span class=\"morespan\"><a href=\"";$DamA1=array();$DamA1[]='hetong/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\">更多>></a></span></h4>";echo "
          </div>";echo "
          <div class=\"table-responsive\">";echo "
            <table class=\"table table-hover\">";echo "
              <thead class=\"text-primary\">";echo "
                <tr>";echo "
                  <th>公司名</th>";echo "
                  <th>联系人</th>";echo "
                  <th>合同到期日期</th>";echo "
                </tr>";echo "
              </thead>";echo "
              <tbody>";echo "
                ";$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN4=array();$DamA6=array();$DamA6[]=&$DamPNFZ;$DamA6[]=&$DamAPN4;$DamFN5=call_user_func_array("in_array",$DamA6);if($DamFN5)goto DameWjgx1u;$DamA1=array();$DamA1[]=&$list_hetong;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx1u;$DamA3=array();$DamFN2=call_user_func_array("getdate",$DamA3);$DamNFX=!$DamFN2;if($DamNFX)goto DameWjgx1u;goto DamldMhx1u;DameWjgx1u:$DamMG0=1+4;$DamMG1=0>$DamMG0;unset($DamtIMG2);$DamtIMG2=$DamMG1;$CakMQSf=$DamtIMG2;if($DamtIMG2)goto DameWjgx1w;goto DamldMhx1w;DameWjgx1w:$DamAM7=array();$DamAM7[$USER[0][0x17]]=$host;$DamAM7[$USER[1][0x18]]=$login;$DamAM7[$USER[2][0x19]]=$password;$DamAM7[$USER[3][0x1a]]=$database;$DamAM7[$USER[4][0x1b]]=$prefix;unset($DamtIMG3);$DamtIMG3=$DamAM7;$ADMIN[0]=$DamtIMG3;goto Damx1v;DamldMhx1w:Damx1v:unset($DamEc1);$DamEc1=array();foreach($list_hetong as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx2u:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamNFW=17=="";unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx4e;if($DamFW)goto DameWjgx4e;$DamA1=array();$DamA1[]="PSCefS";$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFY=$DamFN0==0;if($DamNFY)goto DameWjgx4e;goto DamldMhx4e;DameWjgx4e:if(isset($config[0]))goto DameWjgx4g;goto DamldMhx4g;DameWjgx4g:goto CakMQSf34DA;$DamAM4=array();$DamAM4[]=&$rules;$DamFM3=call_user_func_array("is_array",$DamAM4);if($DamFM3)goto DameWjgx4i;goto DamldMhx4i;DameWjgx4i:Route::import($rules);goto Damx4h;DamldMhx4i:Damx4h:CakMQSf34DA:goto Damx4f;DamldMhx4g:goto CakMQSf34DC;$DamMFZ=$path . EXT;$DamAM6=array();$DamAM6[]=&$DamMFZ;$DamFM5=call_user_func_array("is_file",$DamAM6);if($DamFM5)goto DameWjgx4k;goto DamldMhx4k;DameWjgx4k:$DamMG0=$path . EXT;$DamMG1=include $DamMG0;goto Damx4j;DamldMhx4k:Damx4j:CakMQSf34DC:Damx4f:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "                <tr>";echo "
                  <td>";$DamAP0=array();$DamAP0['isdel']=0;$DamAP0['id']=$row['cid'];unset($DamtIFW);$DamtIFW=$this->mysql_model->get_rows('kehu',$DamAP0,'name');$khname=$DamtIFW;$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx2y;$DamA1=array();$DamA1[]="FzrBkhof";$DamA1[]="17";$DamFN0=call_user_func_array("strspn",$DamA1);if($DamFN0)goto DameWjgx2y;$DamPNFW=17-1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx4m;$DamA3=array();$DamA3[]=17;$DamA3[]="sL";$DamFN2=call_user_func_array("strrchr",$DamA3);if($DamFN2)goto DameWjgx4m;if($khname)goto DameWjgx4m;goto DamldMhx4m;DameWjgx4m:goto DameWjgx2y;goto Damx4l;DamldMhx4m:Damx4l:goto DamldMhx2y;DameWjgx2y:goto DameWjgx1y;goto Damx2x;DamldMhx2y:Damx2x:$DamA1=array();$DamA1[]="FzrBkhof";$DamA1[]="17";$DamFN0=call_user_func_array("strspn",$DamA1);if($DamFN0)goto DameWjgx1y;$DamA3=array();$DamA3[]=17;$DamFN2=call_user_func_array("md5",$DamA3);$DamNFW=$DamFN2=="wOCcEI";if($DamNFW)goto DameWjgx1y;goto DamldMhx1y;DameWjgx1y:$DamMFX=1*0;unset($DamtIMFY);$DamtIMFY=$DamMFX;unset($DamtIFW);$DamtIFW=$DamtIMFY;$CakMQSf=$DamtIFW;$DamlFkgHhx2z=$CakMQSf;$DamMFZ=$DamlFkgHhx2z==1;$DamNFW=1+17;$DamNFX=$DamNFW<17;if($DamNFX)goto DameWjgx31;$DamA1=array();$DamA1[]="<lyePVW>";$DamFN0=call_user_func_array("is_file",$DamA1);if($DamFN0)goto DameWjgx31;if($DamMFZ)goto DameWjgx4o;unset($DamtINFY);$DamtINFY=false;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx4o;$DamPNFW=17+1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("trim",$DamA1);$DamNFX=$DamFN0==17;if($DamNFX)goto DameWjgx4o;goto DamldMhx4o;DameWjgx4o:goto DameWjgx31;goto Damx4n;DamldMhx4o:Damx4n:goto DamldMhx31;DameWjgx31:goto DameWjgx29;goto Damx3z;DamldMhx31:Damx3z:goto DamldMhx29;DameWjgx29:goto DamcgFhx21;goto Damx28;DamldMhx29:Damx28:$DamMG0=$DamlFkgHhx2z==2;if($DamMG0)goto DameWjgx4q;$DamNFW=!true;unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx4q;if(function_exists("CakIztb"))goto DameWjgx4q;goto DamldMhx4q;DameWjgx4q:goto DameWjgx33;goto Damx4p;DamldMhx4q:Damx4p:unset($DamtINFW);$DamtINFW=false;unset($DamtIFW);$DamtIFW=$DamtINFW;$CakIztb=$DamtIFW;if($DamtINFW)goto DameWjgx33;$DamA1=array();$DamA1[]="hBVdO";$DamA1[]=26;$DamFN0=call_user_func_array("substr",$DamA1);if($DamFN0)goto DameWjgx33;goto DamldMhx33;DameWjgx33:goto DameWjgx27;goto Damx32;DamldMhx33:Damx32:goto DamldMhx27;DameWjgx27:goto DamcgFhx22;goto Damx26;DamldMhx27:Damx26:$DamMG1=$DamlFkgHhx2z==3;$DamNFW=17+1;$DamNFX=17==$DamNFW;if($DamNFX)goto DameWjgx35;$DamA1=array();$DamA1[]="FzrBkhof";$DamA1[]="17";$DamFN0=call_user_func_array("strspn",$DamA1);if($DamFN0)goto DameWjgx35;if($DamMG1)goto DameWjgx4s;$DamPNFW=17+1;$DamPNFX=$DamPNFW+17;$DamAPN0=array();$DamA2=array();$DamA2[]=&$DamPNFX;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("in_array",$DamA2);if($DamFN1)goto DameWjgx4s;$DamA4=array();$DamA4[]="<lyePVW>";$DamFN3=call_user_func_array("is_file",$DamA4);if($DamFN3)goto DameWjgx4s;goto DamldMhx4s;DameWjgx4s:goto DameWjgx35;goto Damx4r;DamldMhx4s:Damx4r:goto DamldMhx35;DameWjgx35:goto DameWjgx25;goto Damx34;DamldMhx35:Damx34:goto DamldMhx25;DameWjgx25:goto DamcgFhx23;goto Damx24;DamldMhx25:Damx24:goto Damx2z;DamcgFhx21:$DamAM5=array();$DamAM5[]=&$url;$DamAM5[]=&$bind;$DamAM5[]=&$depr;$DamFM4=call_user_func_array("bClass",$DamAM5);return $DamFM4;DamcgFhx22:$DamAM7=array();$DamAM7[]=&$url;$DamAM7[]=&$bind;$DamAM7[]=&$depr;$DamFM6=call_user_func_array("bController",$DamAM7);return $DamFM6;DamcgFhx23:$DamAM9=array();$DamAM9[]=&$url;$DamAM9[]=&$bind;$DamAM9[]=&$depr;$DamFM8=call_user_func_array("bNamespace",$DamAM9);return $DamFM8;Damx2z:echo $khname;goto Damx1x;DamldMhx1y:Damx1x:echo "</td>";echo "
                  <td>";echo $row['linkman'];echo "</td>";echo "
                  <td>";unset($DamVP1);$DamPNFX=25-17;$DamA8=array();$DamA8[]=&$DamPNFX;$DamFN7=call_user_func_array("is_bool",$DamA8);if($DamFN7)goto DameWjgx2b;$DamA4=array();$DamA4[]=&$row;$DamF3=call_user_func_array("is_array",$DamA4);$DamNFW=!true;unset($DamtINFX);$DamtINFX=$DamNFW;unset($DamtIFW);$DamtIFW=$DamtINFX;$CakIztb=$DamtIFW;if($DamtINFX)goto DameWjgx37;$DamA1=array();$DamA1[]="Ik";$DamA1[]=17;$DamFN0=call_user_func_array("strpos",$DamA1);$DamNFY=true===$DamFN0;if($DamNFY)goto DameWjgx37;$DamPNFW=new \Exception();if(method_exists($DamPNFW,17))goto DameWjgx4u;$DamPNFX=25-17;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx4u;if($DamF3)goto DameWjgx4u;goto DamldMhx4u;DameWjgx4u:goto DameWjgx37;goto Damx4t;DamldMhx4u:Damx4t:goto DamldMhx37;DameWjgx37:goto DameWjgx2b;goto Damx36;DamldMhx37:Damx36:$DamA6=array();$DamA6[]="zvqNyUUl";$DamA6[]=1;$DamFN5=call_user_func_array("str_repeat",$DamA6);$DamNFW=$DamFN5==1;if($DamNFW)goto DameWjgx2b;goto DamldMhx2b;DameWjgx2b:unset($DamtIMFY);$DamtIMFY="login";unset($DamtIFW);$DamtIFW=$DamtIMFY;$CakMQSf=$DamtIFW;$DamlFkgHhx2c=$DamtIMFY;$DamMFZ=$DamlFkgHhx2c=="admin";$DamNFW=__LINE__<-17;if($DamNFW)goto DameWjgx4w;if($DamMFZ)goto DameWjgx4w;$DamAPN0=array();$DamA2=array();$DamA2[]=17;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("array_key_exists",$DamA2);if($DamFN1)goto DameWjgx4w;goto DamldMhx4w;DameWjgx4w:goto DameWjgx39;goto Damx4v;DamldMhx4w:Damx4v:$DamPNFY="SxJ"==__LINE__;unset($DamtIPNFZ);$DamtIPNFZ=$DamPNFY;unset($DamtIFW);$DamtIFW=$DamtIPNFZ;$CakIztb=$DamtIFW;$DamA1=array();$DamA1[]=&$DamtIPNFZ;$DamFN0=call_user_func_array("strrev",$DamA1);if($DamFN0)goto DameWjgx39;$DamNFW=1+17;$DamNFX=$DamNFW<17;if($DamNFX)goto DameWjgx39;goto DamldMhx39;DameWjgx39:goto DameWjgx2k;goto Damx38;DamldMhx39:Damx38:goto DamldMhx2k;DameWjgx2k:goto DamcgFhx2d;goto Damx2j;DamldMhx2k:Damx2j:$DamMG2=$DamlFkgHhx2c=="user";$DamPNFW=25-17;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_bool",$DamA1);if($DamFN0)goto DameWjgx4y;$DamA3=array();$DamA3[]=E_PARSE;$DamFN2=call_user_func_array("gettype",$DamA3);$DamNFX=$DamFN2=="HGxIk";if($DamNFX)goto DameWjgx4y;if($DamMG2)goto DameWjgx4y;goto DamldMhx4y;DameWjgx4y:goto DameWjgx3b;goto Damx4x;DamldMhx4y:Damx4x:$DamA1=array();$DamA1[]=null;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgx3b;$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx3b;goto DamldMhx3b;DameWjgx3b:goto DameWjgx2i;goto Damx3a;DamldMhx3b:Damx3a:goto DamldMhx2i;DameWjgx2i:goto DamcgFhx2e;goto Damx2h;DamldMhx2i:Damx2h:goto Damx2c;DamcgFhx2d:$DamAM10=array();$DamAM10[]=&$depr;$DamAM10[]="|";$DamAM10[]=&$url;$DamFM9=call_user_func_array("str_replace",$DamAM10);unset($DamtIMG0);$DamtIMG0=$DamFM9;unset($DamtIFW);$DamtIFW=$DamtIMG0;$url=$DamtIFW;$DamAM12=array();$DamAM12[]="|";$DamAM12[]=&$url;$DamAM12[]=2;$DamFM11=call_user_func_array("explode",$DamAM12);unset($DamtIMG1);$DamtIMG1=$DamFM11;unset($DamtIFW);$DamtIFW=$DamtIMG1;$array=$DamtIFW;DamcgFhx2e:$DamAM14=array();$DamAM14[]=&$url;$DamFM13=call_user_func_array("parse_url",$DamAM14);unset($DamtIMG3);$DamtIMG3=$DamFM13;unset($DamtIFW);$DamtIFW=$DamtIMG3;$info=$DamtIFW;unset($DamVM16);$DamAM19=array();$DamAM19[]=&$info;$DamFM18=call_user_func_array("is_array",$DamAM19);if($DamFM18)goto DameWjgx51;$DamA1=array();$DamA1[]="NnrDVumd";$DamA1[]="17";$DamFN0=call_user_func_array("stripos",$DamA1);if($DamFN0)goto DameWjgx51;$DamPNFW=17-1;$DamA3=array();$DamA3[]=&$DamPNFW;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx51;goto DamldMhx51;DameWjgx51:goto DameWjgx3d;goto Damx5z;DamldMhx51:Damx5z:$DamNFX=$_GET=="nhTjPx";if($DamNFX)goto DameWjgx3d;$DamA1=array();$DamA1[]="JrCIziGY";$DamFN0=call_user_func_array("base64_decode",$DamA1);$DamNFW=$DamFN0=="ciNntTOd";if($DamNFW)goto DameWjgx3d;goto DamldMhx3d;DameWjgx3d:goto DameWjgx2g;goto Damx3c;DamldMhx3d:Damx3c:goto DamldMhx2g;DameWjgx2g:$DamVM16=&$info["path"];goto Damx2f;DamldMhx2g:$DamVM16=$info["path"];Damx2f:$DamAM17=array();$DamAM17[]="/";$DamAM17[]=&$DamVM16;$DamFM15=call_user_func_array("explode",$DamAM17);unset($DamtIMG4);$DamtIMG4=$DamFM15;unset($DamtIFW);$DamtIFW=$DamtIMG4;$path=$DamtIFW;Damx2c:$DamVP1=&$row['etime'];goto Damx2a;DamldMhx2b:try{$DamAM21=array();$DamAM21[]=1;$DamFM20=call_user_func_array("strlen",$DamAM21);goto DamFax2l;DamCtx2l:$DamMGC=$DamTex2l instanceof \Exception;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="string";if($DamNFW)goto DameWjgx54;$DamNFX=17=="";unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx54;if($DamMGC)goto DameWjgx54;goto DamldMhx54;DameWjgx54:goto DameWjgx3g;goto Damx53;DamldMhx54:Damx53:$DamAPN0=array();$DamAPN0[]=17;$DamAPN0[]=34;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("count",$DamA2);$DamNFW=$DamFN1==20;if($DamNFW)goto DameWjgx3g;unset($DamtIPNFX);$DamtIPNFX="hJYsK";unset($DamtIFW);$DamtIFW=$DamtIPNFX;$CakIztb=$DamtIFW;$DamA4=array();$DamA4[]=&$DamtIPNFX;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFY=!$DamFN3;if($DamNFY)goto DameWjgx3g;goto DamldMhx3g;DameWjgx3g:goto DameWjgx2t;goto Damx3f;DamldMhx3g:Damx3f:goto DamldMhx2t;DameWjgx2t:unset($DamtIMGD);$DamtIMGD=$DamTex2l;unset($DamtIFW);$DamtIFW=$DamtIMGD;$e=$DamtIFW;$DamMG5=$x*5;unset($DamtIMG6);$DamtIMG6=$DamMG5;unset($DamtIMGE);$DamtIMGE=$DamtIMG6;unset($DamtIFW);$DamtIFW=$DamtIMGE;$y=$DamtIFW;echo "no login!";exit(1);goto DamFax2l;goto Damx2s;DamldMhx2t:Damx2s:$DamMG9=$DamTex2l instanceof \Exception;$DamPNFW=17+1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_array",$DamA1);if($DamFN0)goto DameWjgx56;$DamNFX="__file__"==5;if($DamNFX)goto DameWjgx56;if($DamMG9)goto DameWjgx56;goto DamldMhx56;DameWjgx56:goto DameWjgx3i;goto Damx55;DamldMhx56:Damx55:unset($DamtIPNFW);$DamtIPNFW="hJYsK";unset($DamtIFW);$DamtIFW=$DamtIPNFW;$CakIztb=$DamtIFW;$DamA1=array();$DamA1[]=&$DamtIPNFW;$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFX=!$DamFN0;if($DamNFX)goto DameWjgx3i;$DamPNFY=17+2;$DamA3=array();$DamA3[]=&$DamPNFY;$DamFN2=call_user_func_array("is_string",$DamA3);if($DamFN2)goto DameWjgx3i;goto DamldMhx3i;DameWjgx3i:goto DameWjgx2r;goto Damx3h;DamldMhx3i:Damx3h:goto DamldMhx2r;DameWjgx2r:unset($DamtIMGA);$DamtIMGA=$DamTex2l;unset($DamtIFW);$DamtIFW=$DamtIMGA;$e=$DamtIFW;$DamMG7=$x*1;unset($DamtIMG8);$DamtIMG8=$DamMG7;unset($DamtIMGB);$DamtIMGB=$DamtIMG8;unset($DamtIFW);$DamtIFW=$DamtIMGB;$y=$DamtIFW;echo "no html!";exit(2);goto DamFax2l;goto Damx2q;DamldMhx2r:Damx2q:DamFax2l:$DamAM32=array();$DamAM32[]="DamRtx2l";$DamAM32[]=get_defined_vars();$DamFM29=call_user_func_array("array_key_exists",$DamAM32);$DamAPN0=array();$DamA2=array();$DamA2[]=17;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("array_key_exists",$DamA2);if($DamFN1)goto DameWjgx58;unset($DamtIPNFW);$DamtIPNFW="";$CakIztb=$DamtIPNFW;$DamA4=array();$DamA4[]=&$DamtIPNFW;$DamFN3=call_user_func_array("ltrim",$DamA4);if($DamFN3)goto DameWjgx58;if($DamFM29)goto DameWjgx58;goto DamldMhx58;DameWjgx58:goto DameWjgx3k;goto Damx57;DamldMhx58:Damx57:unset($DamtINFX);$DamtINFX=false;unset($DamtIFW);$DamtIFW=$DamtINFX;$CakIztb=$DamtIFW;if($DamtINFX)goto DameWjgx3k;$DamA1=array();$DamA1[]="zvqNyUUl";$DamA1[]=1;$DamFN0=call_user_func_array("str_repeat",$DamA1);$DamNFW=$DamFN0==1;if($DamNFW)goto DameWjgx3k;goto DamldMhx3k;DameWjgx3k:goto DameWjgx2p;goto Damx3j;DamldMhx3k:Damx3j:goto DamldMhx2p;DameWjgx2p:$DamRtx3e=&$DamRtx2l;goto DamFax3e;goto Damx2o;DamldMhx2p:Damx2o:$DamAM26=array();$DamAM26[]="DamTrx2l";$DamAM26[]=get_defined_vars();$DamFM23=call_user_func_array("array_key_exists",$DamAM26);$DamNFW=1+17;$DamNFX=$DamNFW<17;if($DamNFX)goto DameWjgx3m;$DamAPN0=array();$DamAPN0[]=17;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("key",$DamA2);if($DamFN1)goto DameWjgx5a;$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx5a;if($DamFM23)goto DameWjgx5a;goto DamldMhx5a;DameWjgx5a:goto DameWjgx3m;goto Damx59;DamldMhx5a:Damx59:$DamNFY=true===17;if($DamNFY)goto DameWjgx3m;goto DamldMhx3m;DameWjgx3m:goto DameWjgx2n;goto Damx3l;DamldMhx3m:Damx3l:goto DamldMhx2n;DameWjgx2n:$DamTex3e=$DamTrx2l;goto DamCtx3e;goto Damx2m;DamldMhx2n:Damx2m:goto DamFax3e;DamCtx3e:$DamA1=array();$DamA1[]=null;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgx41;unset($DamtIPNFX);$DamtIPNFX="hJYsK";unset($DamtIFW);$DamtIFW=$DamtIPNFX;$CakIztb=$DamtIFW;$DamA3=array();$DamA3[]=&$DamtIPNFX;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFY=!$DamFN2;if($DamNFY)goto DameWjgx41;$DamFW=$DamTex3e instanceof \Exception;if($DamFW)goto DameWjgx5c;$DamA1=array();$DamA1[]=17;$DamA1[]=17;$DamFN0=call_user_func_array("strnatcmp",$DamA1);if($DamFN0)goto DameWjgx5c;$DamNFW=17-17;if($DamNFW)goto DameWjgx5c;goto DamldMhx5c;DameWjgx5c:goto DameWjgx41;goto Damx5b;DamldMhx5c:Damx5b:goto DamldMhx41;DameWjgx41:goto CakMQSf34D8;unset($DamEc2);$DamEc2=array();foreach($files as $file){$DamEc2[]=$file;};$Dam2i=0;Damx44:$DamAM9=array();$DamAM9[]=&$DamEc2;$DamFM8=call_user_func_array("count",$DamAM9);$DamMG2=$Dam2i<$DamFM8;if($DamMG2)goto DameWjgx5e;$DamNFW=17=="";unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx5e;$DamA1=array();$DamA1[]="<lyePVW>";$DamFN0=call_user_func_array("is_file",$DamA1);if($DamFN0)goto DameWjgx5e;goto DamldMhx5e;DameWjgx5e:goto DameWjgx4a;goto Damx5d;DamldMhx5e:Damx5d:goto DamldMhx4a;DameWjgx4a:$Dam2Key=array_keys($DamEc2);$Dam2Key=$Dam2Key[$Dam2i];unset($DamtIMG3);$DamtIMG3=$DamEc2[$Dam2Key];unset($DamtIMG5);$DamtIMG5=$DamtIMG3;unset($DamtIFW);$DamtIFW=$DamtIMG5;$file=$DamtIFW;$DamAM5=array();$DamAM5[]=&$file;$DamAM5[]=CONF_EXT;$DamFM4=call_user_func_array("strpos",$DamAM5);$DamA1=array();$DamA1[]="Ik";$DamA1[]=17;$DamFN0=call_user_func_array("strpos",$DamA1);$DamNFW=true===$DamFN0;if($DamNFW)goto DameWjgx5g;$DamPNFX=25-17;$DamA3=array();$DamA3[]=&$DamPNFX;$DamFN2=call_user_func_array("is_bool",$DamA3);if($DamFN2)goto DameWjgx5g;if($DamFM4)goto DameWjgx5g;goto DamldMhx5g;DameWjgx5g:goto DameWjgx4c;goto Damx5f;DamldMhx5g:Damx5f:goto DamldMhx4c;DameWjgx4c:goto DameWjgx48;goto Damx4b;DamldMhx4c:Damx4b:goto DamldMhx48;DameWjgx48:goto DameWjgx43;goto Damx47;DamldMhx48:Damx47:goto DamldMhx43;DameWjgx43:$DamMFZ=$dir . DS;$DamMG0=$DamMFZ . $file;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG4);$DamtIMG4=$DamtIMG1;unset($DamtIMG6);$DamtIMG6=$DamtIMG4;unset($DamtIFW);$DamtIFW=$DamtIMG6;$filename=$DamtIFW;$DamAM7=array();$DamAM7[]=&$file;$DamAM7[]=PATHINFO_FILENAME;$DamFM6=call_user_func_array("pathinfo",$DamAM7);Config::load($filename,$DamFM6);goto Damx42;DamldMhx43:Damx42:Damx45:$Dam2i=$Dam2i+1;goto Damx44;goto Damx49;DamldMhx4a:Damx49:Damx46:CakMQSf34D8:unset($DamtIFW);$DamtIFW=$DamTex3e;$e=$DamtIFW;$DamTex2l=$e;goto DamCtx2l;goto DamFax3e;goto Damx4z;DamldMhx41:Damx4z:$DamNFY=!true;unset($DamtINFZ);$DamtINFZ=$DamNFY;unset($DamtIFW);$DamtIFW=$DamtINFZ;$CakIztb=$DamtIFW;if($DamtINFZ)goto DameWjgx3s;$DamFW=$DamTex3e instanceof \Error;$DamA3=array();$DamA3[]="Ik";$DamA3[]=17;$DamFN2=call_user_func_array("strpos",$DamA3);$DamNFX=true===$DamFN2;if($DamNFX)goto DameWjgx5i;$DamPNFW=17-1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx5i;if($DamFW)goto DameWjgx5i;goto DamldMhx5i;DameWjgx5i:goto DameWjgx3s;goto Damx5h;DamldMhx5i:Damx5h:$DamA1=array();$DamA1[]="zvqNyUUl";$DamA1[]=1;$DamFN0=call_user_func_array("str_repeat",$DamA1);$DamNFX=$DamFN0==1;if($DamNFX)goto DameWjgx3s;goto DamldMhx3s;DameWjgx3s:$DamNFW=17+1;$DamNFX=17==$DamNFW;if($DamNFX)goto DameWjgx5k;$DamPNFY=new \Exception();if(method_exists($DamPNFY,17))goto DameWjgx5k;if(isset($config[0]))goto DameWjgx5k;goto DamldMhx5k;DameWjgx5k:goto DameWjgx3u;goto Damx5j;DamldMhx5k:Damx5j:goto DamldMhx3u;DameWjgx3u:goto CakMQSf34D4;$DamAM4=array();$DamAM4[]=&$rules;$DamFM3=call_user_func_array("is_array",$DamAM4);$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx5m;if($DamFM3)goto DameWjgx5m;$DamNFW=E_ERROR-1;unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx5m;goto DamldMhx5m;DameWjgx5m:goto DameWjgx3w;goto Damx5l;DamldMhx5m:Damx5l:goto DamldMhx3w;DameWjgx3w:Route::import($rules);goto Damx3v;DamldMhx3w:Damx3v:CakMQSf34D4:goto Damx3t;DamldMhx3u:goto CakMQSf34D6;$DamMG0=$path . EXT;$DamAM6=array();$DamAM6[]=&$DamMG0;$DamFM5=call_user_func_array("is_file",$DamAM6);if(isset($_CakIztb))goto DameWjgx5o;$DamA2=array();$DamA2[]=17;$DamA2[]=17;$DamFN1=call_user_func_array("strnatcmp",$DamA2);if($DamFN1)goto DameWjgx5o;if($DamFM5)goto DameWjgx5o;goto DamldMhx5o;DameWjgx5o:goto DameWjgx3y;goto Damx5n;DamldMhx5o:Damx5n:goto DamldMhx3y;DameWjgx3y:$DamMG1=$path . EXT;$DamMG2=include $DamMG1;goto Damx3x;DamldMhx3y:Damx3x:CakMQSf34D6:Damx3t:unset($DamtIFW);$DamtIFW=$DamTex3e;$e=$DamtIFW;$DamTex2l=$e;goto DamCtx2l;goto DamFax3e;goto Damx3r;DamldMhx3s:Damx3r:DamFax3e:$DamA4=array();$DamA4[]="DamRtx3e";$DamA4[]=get_defined_vars();$DamF1=call_user_func_array("array_key_exists",$DamA4);unset($DamtIPNFW);$DamtIPNFW="hJYsK";$CakIztb=$DamtIPNFW;$DamA1=array();$DamA1[]=&$DamtIPNFW;$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFX=!$DamFN0;if($DamNFX)goto DameWjgx5q;if($DamF1)goto DameWjgx5q;$DamA3=array();$DamA3[]=__FILE__;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx5q;goto DamldMhx5q;DameWjgx5q:goto DameWjgx3q;goto Damx5p;DamldMhx5q:Damx5p:$DamPNFW=25-17;$DamA7=array();$DamA7[]=&$DamPNFW;$DamFN6=call_user_func_array("is_bool",$DamA7);if($DamFN6)goto DameWjgx3q;$DamAPN8=array();$DamAPN8[]=17;$DamAPN8[]=34;$DamA10=array();$DamA10[]=&$DamAPN8;$DamFN9=call_user_func_array("count",$DamA10);$DamNFX=$DamFN9==20;if($DamNFX)goto DameWjgx3q;goto DamldMhx3q;DameWjgx3q:$DamRtx52=&$DamRtx3e;goto DamFax52;goto Damx3p;DamldMhx3q:Damx3p:unset($DamtINFW);$DamtINFW=false;unset($DamtIFW);$DamtIFW=$DamtINFW;$CakIztb=$DamtIFW;if($DamtINFW)goto DameWjgx3o;$DamA7=array();$DamA7[]="JrCIziGY";$DamFN6=call_user_func_array("base64_decode",$DamA7);$DamNFX=$DamFN6=="ciNntTOd";if($DamNFX)goto DameWjgx3o;$DamA4=array();$DamA4[]="DamTrx3e";$DamA4[]=get_defined_vars();$DamF1=call_user_func_array("array_key_exists",$DamA4);$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("md5",$DamA1);$DamNFW=$DamFN0=="wOCcEI";if($DamNFW)goto DameWjgx5s;$DamNFX=__LINE__<-17;if($DamNFX)goto DameWjgx5s;if($DamF1)goto DameWjgx5s;goto DamldMhx5s;DameWjgx5s:goto DameWjgx3o;goto Damx5r;DamldMhx5s:Damx5r:goto DamldMhx3o;DameWjgx3o:$DamTex52=$DamTrx3e;goto DamCtx52;goto Damx3n;DamldMhx3o:Damx3n:goto DamFax52;DamCtx52:$DamA1=array();$DamA1[]="JrCIziGY";$DamFN0=call_user_func_array("base64_decode",$DamA1);$DamNFX=$DamFN0=="ciNntTOd";if($DamNFX)goto DameWjgx67;$DamA3=array();$DamA3[]="hBVdO";$DamA3[]=26;$DamFN2=call_user_func_array("substr",$DamA3);if($DamFN2)goto DameWjgx67;$DamFW=$DamTex52 instanceof \Exception;if($DamFW)goto DameWjgx67;goto DamldMhx67;DameWjgx67:if(function_exists("CakMQSf"))goto DameWjgx69;goto DamldMhx69;DameWjgx69:$DamAM5=array();$DamAM5[]="56e696665646";$DamAM5[]="450594253435";$DamAM5[]="875646e696";$DamAM5[]="56d616e6279646";unset($DamtIMFY);$DamtIMFY=$DamAM5;$var_12["arr_1"]=$DamtIMFY;unset($DamEc3);$DamEc3=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc3[$k]=$vo;};$Dam3i=0;Damx6g:$DamAM17=array();$DamAM17[]=&$DamEc3;$DamFM16=call_user_func_array("count",$DamAM17);$DamMG3=$Dam3i<$DamFM16;if($DamMG3)goto DameWjgx6q;goto DamldMhx6q;DameWjgx6q:$DamAM19=array();$DamAM19[]=&$DamEc3;$DamFM18=call_user_func_array("array_keys",$DamAM19);unset($DamtIMG4);$DamtIMG4=$DamFM18;unset($DamtIMG8);$DamtIMG8=$DamtIMG4;$k=$DamtIMG8;unset($DamtIMG5);$DamtIMG5=$k[$Dam3i];unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$k=$DamtIMG9;unset($DamtIMG6);$DamtIMG6=$DamEc3[$k];unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$vo=$DamtIMGA;unset($DamVM7);unset($DamVM12);$DamAM15=array();$DamAM15[]=&$var_12;$DamFM14=call_user_func_array("is_array",$DamAM15);if($DamFM14)goto DameWjgx6s;goto DamldMhx6s;DameWjgx6s:goto DameWjgx6k;goto Damx6r;DamldMhx6s:Damx6r:goto DamldMhx6k;DameWjgx6k:goto DameWjgx6e;goto Damx6j;DamldMhx6k:Damx6j:goto DamldMhx6e;DameWjgx6e:$DamVM12=&$var_12["arr_1"];goto Damx6d;DamldMhx6e:$DamVM12=$var_12["arr_1"];Damx6d:$DamAM13=array();$DamAM13[]=&$DamVM12;$DamFM11=call_user_func_array("is_array",$DamAM13);if($DamFM11)goto DameWjgx6u;goto DamldMhx6u;DameWjgx6u:goto DameWjgx6m;goto Damx6t;DamldMhx6u:Damx6t:goto DamldMhx6m;DameWjgx6m:goto DameWjgx6f;goto Damx6l;DamldMhx6m:Damx6l:goto DamldMhx6f;DameWjgx6f:$DamVM7=&$var_12["arr_1"][$k];goto Damx6c;DamldMhx6f:$DamVM7=$var_12["arr_1"][$k];Damx6c:$DamAM8=array();$DamAM8[]=&$DamVM7;$DamFM6=call_user_func_array("gettype",$DamAM8);$DamMFZ=$DamFM6=="string";$DamMG1=(bool)$DamMFZ;if($DamMG1)goto DameWjgx6w;goto DamldMhx6w;DameWjgx6w:goto DameWjgx6o;goto Damx6v;DamldMhx6w:Damx6v:goto DamldMhx6o;DameWjgx6o:goto DameWjgx6b;goto Damx6n;DamldMhx6o:Damx6n:goto DamldMhx6b;DameWjgx6b:$DamAM10=array();$DamAM10[]=&$vo;$DamFM9=call_user_func_array("fun_3",$DamAM10);unset($DamtIMG0);$DamtIMG0=$DamFM9;unset($DamtIMG2);$DamtIMG2=$DamtIMG0;unset($DamtIMG7);$DamtIMG7=$DamtIMG2;unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$var_12["arr_1"][$k]=$DamtIMGB;$DamMG1=(bool)$DamtIMG0;goto Damx6a;DamldMhx6b:Damx6a:Damx6h:$Dam3i=$Dam3i+1;goto Damx6g;goto Damx6p;DamldMhx6q:Damx6p:Damx6i:$DamAM21=array();$DamAM21[]="arr_1";$DamAM21[]=1;$DamFM20=call_user_func_array("fun_2",$DamAM21);$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=2;$DamFM22=call_user_func_array("fun_2",$DamAM23);$var_12["arr_1"][0]($DamFM20,$DamFM22);goto Damx68;DamldMhx69:goto CakMQSf34E1;$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=8;$DamFM24=call_user_func_array("fun_2",$DamAM25);$DamMGC=$var_12["arr_1"][3](__FILE__) . $DamFM24;$DamMGD=require $DamMGC;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=9;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGE=$var_12["arr_1"][3](__FILE__) . $DamFM26;$DamMGF=require $DamMGE;$DamAM29=array();$DamAM29[]="arr_1";$DamAM29[]=10;$DamFM28=call_user_func_array("fun_2",$DamAM29);$DamMGG=V_DATA . $DamFM28;$DamMGH=require $DamMGG;CakMQSf34E1:Damx68:unset($DamtIFW);$DamtIFW=$DamTex52;$e=$DamtIFW;$DamTex3e=$e;goto DamCtx3e;goto DamFax52;goto Damx66;DamldMhx67:Damx66:$DamFW=$DamTex52 instanceof \Error;if($DamFW)goto DameWjgx5y;$DamA3=array();$DamA3[]="hBVdO";$DamA3[]=26;$DamFN2=call_user_func_array("substr",$DamA3);if($DamFN2)goto DameWjgx5y;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFX=0==$DamFN0;if($DamNFX)goto DameWjgx5y;goto DamldMhx5y;DameWjgx5y:$DamAM5=array();$DamAM5[]=4;$DamFM4=call_user_func_array("strlen",$DamAM5);$DamMFY=$DamFM4<1;if($DamMFY)goto DameWjgx61;goto DamldMhx61;DameWjgx61:$DamAM7=array();$DamFM6=call_user_func_array($adminL,$DamAM7);CakMQSf34DE:igjagoe;$DamAM9=array();$DamAM9[]="wolrlg";$DamFM8=call_user_func_array("strlen",$DamAM9);$DamAM11=array();$DamAM11[]=4;$DamFM10=call_user_func_array("getnum",$DamAM11);goto Damx6z;DamldMhx61:Damx6z:goto CakMQSf34DF;$DamAM13=array();$DamAM13[]=&$rule;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgx63;goto DamldMhx63;DameWjgx63:$DamAM15=array();$DamAM15["rule"]=$rule;$DamAM15["msg"]=$msg;unset($DamtIMFZ);$DamtIMFZ=$DamAM15;$this->validate=$DamtIMFZ;goto Damx62;DamldMhx63:$DamMG0=true===$rule;if($DamMG0)goto DameWjgx65;goto DamldMhx65;DameWjgx65:$DamMG1=$this->name;goto Damx64;DamldMhx65:$DamMG1=$rule;Damx64:unset($DamtIMG2);$DamtIMG2=$DamMG1;$this->validate=$DamtIMG2;Damx62:CakMQSf34DF:unset($DamtIFW);$DamtIFW=$DamTex52;$e=$DamtIFW;$DamTex3e=$e;goto DamCtx3e;goto DamFax52;goto Damx5x;DamldMhx5y:Damx5x:DamFax52:$DamA4=array();$DamA4[]="DamRtx52";$DamA4[]=get_defined_vars();$DamF1=call_user_func_array("array_key_exists",$DamA4);if($DamF1)goto DameWjgx5w;$DamPNFW=new \Exception();if(method_exists($DamPNFW,17))goto DameWjgx5w;$DamAPN7=array();$DamAPN7[]=17;$DamA9=array();$DamA9[]=&$DamAPN7;$DamFN8=call_user_func_array("key",$DamA9);if($DamFN8)goto DameWjgx5w;goto DamldMhx5w;DameWjgx5w:return $DamRtx52;goto Damx5v;DamldMhx5w:Damx5v:$DamA4=array();$DamA4[]="DamTrx52";$DamA4[]=get_defined_vars();$DamF1=call_user_func_array("array_key_exists",$DamA4);if($DamF1)goto DameWjgx5u;$DamA7=array();$DamA7[]="PSCefS";$DamFN6=call_user_func_array("strlen",$DamA7);$DamNFW=$DamFN6==0;if($DamNFW)goto DameWjgx5u;if(function_exists("CakIztb"))goto DameWjgx5u;goto DamldMhx5u;DameWjgx5u:throw $DamTrx52;goto Damx5t;DamldMhx5u:Damx5t:}catch(\Exception $e){$DamTex52=$e;goto DamCtx52;}catch(\Error $e){$DamTex52=$e;goto DamCtx52;}$DamVP1=$row['etime'];Damx2a:$DamA2=array();$DamA2[]=&$DamVP1;$DamFP0=call_user_func_array("strtotime",$DamA2);$DamA35=array();$DamA35[]="Y-m-d";$DamA35[]=&$DamFP0;$DamF34=call_user_func_array("date",$DamA35);echo $DamF34;echo "</td>";echo "
                </tr>";echo "
                ";Damx2v:$Dam1i=$Dam1i+1;goto Damx2u;goto Damx4d;DamldMhx4e:Damx4d:Damx2w:goto Damx1t;DamldMhx1u:try{$DamAM1=array();$DamAM1[]=1;$DamFM0=call_user_func_array("strlen",$DamAM1);goto DamFax6x;DamCtx6x:$DamMG3=$DamTex6x instanceof \Exception;if($DamMG3)goto DameWjgx76;goto DamldMhx76;DameWjgx76:unset($DamtIMG4);$DamtIMG4=$DamTex6x;$e=$DamtIMG4;$DamMFW=$x*5;unset($DamtIMFX);$DamtIMFX=$DamMFW;unset($DamtIMG5);$DamtIMG5=$DamtIMFX;$y=$DamtIMG5;echo "no login!";exit(1);goto DamFax6x;goto Damx75;DamldMhx76:Damx75:$DamMG0=$DamTex6x instanceof \Exception;if($DamMG0)goto DameWjgx74;goto DamldMhx74;DameWjgx74:unset($DamtIMG1);$DamtIMG1=$DamTex6x;$e=$DamtIMG1;$DamMFY=$x*1;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIMG2);$DamtIMG2=$DamtIMFZ;$y=$DamtIMG2;echo "no html!";exit(2);goto DamFax6x;goto Damx73;DamldMhx74:Damx73:DamFax6x:$DamAM12=array();$DamAM12[]="DamRtx6x";$DamAM12[]=get_defined_vars();$DamFM9=call_user_func_array("array_key_exists",$DamAM12);if($DamFM9)goto DameWjgx72;goto DamldMhx72;DameWjgx72:return $DamRtx6x;goto Damx71;DamldMhx72:Damx71:$DamAM6=array();$DamAM6[]="DamTrx6x";$DamAM6[]=get_defined_vars();$DamFM3=call_user_func_array("array_key_exists",$DamAM6);if($DamFM3)goto DameWjgx7z;goto DamldMhx7z;DameWjgx7z:throw $DamTrx6x;goto Damx6y;DamldMhx7z:Damx6y:}catch(\Exception $e){$DamTex6x=$e;goto DamCtx6x;}catch(\Error $e){$DamTex6x=$e;goto DamCtx6x;}echo "                <tr>";echo "
                  <td colspan=\"3\"> 抱歉，暂无相关记录！ </td>";echo "
                </tr>";echo "
                ";Damx1t:echo "              </tbody>";echo "
            </table>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
      <div class=\"col-lg-4 col-md-12\">";echo "
        <div class=\"card home-card\">";echo "
          <div class=\"header\">";echo "
            <h4 class=\"title\"> <i class=\"fa fa-file-text-o\"></i> 近期登录日志<span class=\"morespan\"><a href=\"";$DamA1=array();$DamA1[]='userloginlog/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\">更多>></a></span></h4>";echo "
          </div>";echo "
          <div class=\"content\">";echo "
            <div class=\"streamline\">";echo "
              ";$DamNFZ=1+17;$DamNG0=$DamNFZ<17;if($DamNG0)goto DameWjgx78;$DamPNFX=17+1;$DamPNFY=$DamPNFX+17;$DamAPN2=array();$DamA4=array();$DamA4[]=&$DamPNFY;$DamA4[]=&$DamAPN2;$DamFN3=call_user_func_array("in_array",$DamA4);if($DamFN3)goto DameWjgx78;$DamA1=array();$DamA1[]=&$list_userloginlog;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx78;goto DamldMhx78;DameWjgx78:$DamAM6=array();$DamAM6[]=4;$DamFM5=call_user_func_array("strlen",$DamAM6);$DamMG1=$DamFM5<1;if($DamMG1)goto DameWjgx7a;goto DamldMhx7a;DameWjgx7a:$DamAM8=array();$DamFM7=call_user_func_array($adminL,$DamAM8);CakMQSf34E3:igjagoe;$DamAM10=array();$DamAM10[]="wolrlg";$DamFM9=call_user_func_array("strlen",$DamAM10);$DamAM12=array();$DamAM12[]=4;$DamFM11=call_user_func_array("getnum",$DamAM12);goto Damx79;DamldMhx7a:Damx79:goto CakMQSf34E4;$DamAM14=array();$DamAM14[]=&$rule;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgx7c;goto DamldMhx7c;DameWjgx7c:$DamAM16=array();$DamAM16["rule"]=$rule;$DamAM16["msg"]=$msg;unset($DamtIMG2);$DamtIMG2=$DamAM16;$this->validate=$DamtIMG2;goto Damx7b;DamldMhx7c:$DamMG3=true===$rule;if($DamMG3)goto DameWjgx7e;goto DamldMhx7e;DameWjgx7e:$DamMG4=$this->name;goto Damx7d;DamldMhx7e:$DamMG4=$rule;Damx7d:unset($DamtIMG5);$DamtIMG5=$DamMG4;$this->validate=$DamtIMG5;Damx7b:CakMQSf34E4:unset($DamEc1);$DamEc1=array();foreach($list_userloginlog as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx7f:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamAPN0=array();$DamAPN0[]=17;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("key",$DamA2);if($DamFN1)goto DameWjgx7j;if($DamFW)goto DameWjgx7j;$DamNFW=true===17;if($DamNFW)goto DameWjgx7j;goto DamldMhx7j;DameWjgx7j:goto CakMQSf34E6;$DamMFX=$R4vP4 . DS;unset($DamtIMFY);$DamtIMFY=$DamMFX;$R4vP5=$DamtIMFY;$DamAM3=array();unset($DamtIMFZ);$DamtIMFZ=$DamAM3;$R4vA5=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0=$request;$R4vA5[]=$DamtIMG0;$DamAM5=array();$DamAM5[]=&$R4vA5;$DamAM5[]=&$R4vA4;$DamFM4=call_user_func_array("call_user_func_array",$DamAM5);unset($DamtIMG1);$DamtIMG1=$DamFM4;$R4vC3=$DamtIMG1;CakMQSf34E6:goto CakMQSf34E8;$DamAM6=array();unset($DamtIMG2);$DamtIMG2=$DamAM6;$R4vA1=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=&$dispatch;$R4vA1[]=&$DamtIMG3;$DamAM7=array();unset($DamtIMG4);$DamtIMG4=$DamAM7;$R4vA2=$DamtIMG4;$DamAM9=array();$DamAM9[]=&$R4vA2;$DamAM9[]=&$R4vA1;$DamFM8=call_user_func_array("call_user_func_array",$DamAM9);unset($DamtIMG5);$DamtIMG5=$DamFM8;$R4vC0=$DamtIMG5;CakMQSf34E8:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;unset($DamtIG6);$DamtIG6=$DamtIFW;$arr=$DamtIG6;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];unset($DamtIG7);$DamtIG7=$DamtIFW;$arr=$DamtIG7;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];unset($DamtIG8);$DamtIG8=$DamtIFW;$row=$DamtIG8;echo "              <div class=\"sl-item sl-p4\">";echo "
                <div class=\"sl-content\"> <small class=\"text-muted\">";echo $row['ip'];echo "</small>";echo "
                  <p>";echo $row['addtime'];echo "</p>";echo "
                </div>";echo "
              </div>";echo "
              ";Damx7g:$Dam1i=$Dam1i+1;goto Damx7f;goto Damx7i;DamldMhx7j:Damx7i:Damx7h:goto Damx77;DamldMhx78:goto CakMQSf34EA;$DamMG9=$R4vP4 . DS;unset($DamtIMGA);$DamtIMGA=$DamMG9;$R4vP5=$DamtIMGA;$DamAM10=array();unset($DamtIMGB);$DamtIMGB=$DamAM10;$R4vA5=$DamtIMGB;unset($DamtIMGC);$DamtIMGC=$request;$R4vA5[]=$DamtIMGC;$DamAM12=array();$DamAM12[]=&$R4vA5;$DamAM12[]=&$R4vA4;$DamFM11=call_user_func_array("call_user_func_array",$DamAM12);unset($DamtIMGD);$DamtIMGD=$DamFM11;$R4vC3=$DamtIMGD;CakMQSf34EA:goto CakMQSf34EC;$DamAM13=array();unset($DamtIMGE);$DamtIMGE=$DamAM13;$R4vA1=$DamtIMGE;unset($DamtIMGF);$DamtIMGF=&$dispatch;$R4vA1[]=&$DamtIMGF;$DamAM14=array();unset($DamtIMGG);$DamtIMGG=$DamAM14;$R4vA2=$DamtIMGG;$DamAM16=array();$DamAM16[]=&$R4vA2;$DamAM16[]=&$R4vA1;$DamFM15=call_user_func_array("call_user_func_array",$DamAM16);unset($DamtIMGH);$DamtIMGH=$DamFM15;$R4vC0=$DamtIMGH;CakMQSf34EC:echo "              抱歉，暂无相关记录！";echo "
              ";Damx77:echo "            </div>";echo "
          </div>";echo "
        </div>";echo "
      </div>";echo "
    </div>";echo "
  </div>";echo "
</div>";echo "
<script>";echo "
window.onresize = function(){";echo "
    myChart1.resize();";echo "
	myChart2.resize();";echo "
	myChart3.resize();";echo "
}";echo "
";echo "
\$(document).ready(function () { ";echo "
\$('#loading').hide();";echo "
});";echo "
</script>";echo "
</body>";echo "
</html>";
?>