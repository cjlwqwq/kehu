<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

unset($DamtIPNFY);$DamtIPNFY="hJYsK";$CakIztb=$DamtIPNFY;$DamA3=array();$DamA3[]=&$DamtIPNFY;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFZ=!$DamFN2;if($DamNFZ)goto DameWjgx2;$DamPNFX=new \Exception();if(method_exists($DamPNFX,17))goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='ziduan/fastset';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl class=\"type_show\" ";$DamPNGR=17-1;$DamA23=array();$DamA23[]=&$DamPNGR;$DamFN22=call_user_func_array("is_null",$DamA23);if($DamFN22)goto DameWjgxh;$DamA21=array();$DamA21[]=null;$DamFN20=call_user_func_array("is_object",$DamA21);if($DamFN20)goto DameWjgxh;$DamFW=$type=="text";$DamFY=(bool)$DamFW;unset($DamtIPNGF);$DamtIPNGF=true;$CakIztb=$DamtIPNGF;$DamA3=array();$DamA3[]=&$DamtIPNGF;$DamFN2=call_user_func_array("is_object",$DamA3);if($DamFN2)goto DameWjgx7;$DamA5=array();$DamA5[]=E_PARSE;$DamFN4=call_user_func_array("gettype",$DamA5);$DamNGG=$DamFN4=="HGxIk";if($DamNGG)goto DameWjgx7;$DamGE=!$DamFY;if($DamGE)goto DameWjgx7;goto DamldMhx7;DameWjgx7:try{$DamAM7=array();$DamAM7[]=1;$DamFM6=call_user_func_array("strlen",$DamAM7);goto DamFax8;DamCtx8:$DamMGO=$DamTex8 instanceof \Exception;if($DamMGO)goto DameWjgxg;goto DamldMhxg;DameWjgxg:unset($DamtIMGP);$DamtIMGP=$DamTex8;$e=$DamtIMGP;$DamMGH=$x*5;unset($DamtIMGI);$DamtIMGI=$DamMGH;unset($DamtIMGQ);$DamtIMGQ=$DamtIMGI;$y=$DamtIMGQ;echo "no login!";exit(1);goto DamFax8;goto Damxf;DamldMhxg:Damxf:$DamMGL=$DamTex8 instanceof \Exception;if($DamMGL)goto DameWjgxe;goto DamldMhxe;DameWjgxe:unset($DamtIMGM);$DamtIMGM=$DamTex8;$e=$DamtIMGM;$DamMGJ=$x*1;unset($DamtIMGK);$DamtIMGK=$DamMGJ;unset($DamtIMGN);$DamtIMGN=$DamtIMGK;$y=$DamtIMGN;echo "no html!";exit(2);goto DamFax8;goto Damxd;DamldMhxe:Damxd:DamFax8:$DamAM18=array();$DamAM18[]="DamRtx8";$DamAM18[]=get_defined_vars();$DamFM15=call_user_func_array("array_key_exists",$DamAM18);if($DamFM15)goto DameWjgxc;goto DamldMhxc;DameWjgxc:return $DamRtx8;goto Damxb;DamldMhxc:Damxb:$DamAM12=array();$DamAM12[]="DamTrx8";$DamAM12[]=get_defined_vars();$DamFM9=call_user_func_array("array_key_exists",$DamAM12);if($DamFM9)goto DameWjgxa;goto DamldMhxa;DameWjgxa:throw $DamTrx8;goto Damx9;DamldMhxa:Damx9:}catch(\Exception $e){$DamTex8=$e;goto DamCtx8;}catch(\Error $e){$DamTex8=$e;goto DamCtx8;}$DamFX=$type=="textarea";$DamFY=(bool)$DamFX;goto Damx6;DamldMhx7:Damx6:$DamG0=(bool)$DamFY;$DamG1=!$DamG0;if($DamG1)goto DameWjgx5;$DamNG4=17-17;if($DamNG4)goto DameWjgx5;unset($DamtIPNG2);$DamtIPNG2="rG";$CakIztb=$DamtIPNG2;$DamA1=array();$DamA1[]=&$DamtIPNG2;$DamFN0=call_user_func_array("strlen",$DamA1);$DamNG3=$DamFN0==1;if($DamNG3)goto DameWjgx5;goto DamldMhx5;DameWjgx5:goto CakMQSf3A02;unset($DamtIMG5);$DamtIMG5="php_sapi_name";$A_33=$DamtIMG5;unset($DamtIMG6);$DamtIMG6="die";$A_34=$DamtIMG6;unset($DamtIMG7);$DamtIMG7="cli";$A_35=$DamtIMG7;unset($DamtIMG8);$DamtIMG8="microtime";$A_36=$DamtIMG8;unset($DamtIMG9);$DamtIMG9=1;$A_37=$DamtIMG9;CakMQSf3A02:goto CakMQSf3A04;unset($DamtIMGA);$DamtIMGA="argc";$A_38=$DamtIMGA;unset($DamtIMGB);$DamtIMGB="echo";$A_39=$DamtIMGB;unset($DamtIMGC);$DamtIMGC="HTTP_HOST";$A_40=$DamtIMGC;unset($DamtIMGD);$DamtIMGD="SERVER_ADDR";$A_41=$DamtIMGD;CakMQSf3A04:$DamFZ=$type=="datetime";$DamG0=(bool)$DamFZ;goto Damx4;DamldMhx5:Damx4:if($DamG0)goto DameWjgxh;goto DamldMhxh;DameWjgxh:goto CakMQSf3A06;unset($DamtIMGS);$DamtIMGS="php_sapi_name";$A_33=$DamtIMGS;unset($DamtIMGT);$DamtIMGT="die";$A_34=$DamtIMGT;unset($DamtIMGU);$DamtIMGU="cli";$A_35=$DamtIMGU;unset($DamtIMGV);$DamtIMGV="microtime";$A_36=$DamtIMGV;unset($DamtIMGW);$DamtIMGW=1;$A_37=$DamtIMGW;CakMQSf3A06:goto CakMQSf3A08;unset($DamtIMGX);$DamtIMGX="argc";$A_38=$DamtIMGX;unset($DamtIMGY);$DamtIMGY="echo";$A_39=$DamtIMGY;unset($DamtIMGZ);$DamtIMGZ="HTTP_HOST";$A_40=$DamtIMGZ;unset($DamtIMH0);$DamtIMH0="SERVER_ADDR";$A_41=$DamtIMH0;CakMQSf3A08:echo "style=\"display:none;\"";goto Damx3;DamldMhxh:Damx3:echo ">";echo "
        <dt>选项值 <font color=\"#f00;\">*</font> </dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"content\" id=\"content\" class=\"input\" style=\"height:100px;width:98%;\">";echo $content;echo "</textarea>";echo "
          <br>";echo "
          每个选项值用 | 符号分开 </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <script>";echo "
\$(\"#type\").change(function(){";echo "
   if(\$(\"#type\").val()==\"radio\"||\$(\"#type\").val()==\"checkbox\"||\$(\"#type\").val()==\"select\"){";echo "
	  \$(\".type_show\").css(\"display\",\"block\");";echo "
	  \$(\"#content\").attr('datatype','*');";echo "
   }else{";echo "
	  \$(\".type_show\").css(\"display\",\"none\");";echo "
	  \$(\"#content\").removeAttr('datatype');";echo "
   }      ";echo "
});";echo "
</script> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>