<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="hBVdO";$DamA2[]=26;$DamFN1=call_user_func_array("substr",$DamA2);if($DamFN1)goto DameWjgx2;$DamA4=array();$DamFN3=call_user_func_array("getdate",$DamA4);$DamNFX=!$DamFN3;if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "<script src=\"/themes/default/js/jQuery.Hz2Py-min.js\"></script>";echo "
<script type=\"text/javascript\">";echo "
//\$(\"#title\").on(\"keyup keydown change blur\",function (){";echo "
//	";echo "
//});";echo "
\$(function(){";echo "
\$(\"#title\").on(\"click\",function(){";echo "
\$(\"#name\").val(\$(this).toPinyin().replace(/(^\\s+)|(\\s+\$)/g, \"\"));";echo "
});";echo "
";echo "
\$(\"#title\").on(\"keyup\",function(){";echo "
\$(\"#name\").val(\$(this).toPinyin().replace(/(^\\s+)|(\\s+\$)/g, \"\"));";echo "
});";echo "
";echo "
\$(\"#title\").on(\"change\",function(){";echo "
\$(\"#name\").val(\$(this).toPinyin().replace(/(^\\s+)|(\\s+\$)/g, \"\"));";echo "
});";echo "
";echo "
\$(\"#title\").on(\"blur\",function(){";echo "
\$(\"#name\").val(\$(this).toPinyin().replace(/(^\\s+)|(\\s+\$)/g, \"\"));";echo "
});";echo "
});";echo "
</script>";echo "
</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='ziduan/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 数据表 <font color=\"#F00\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
";echo "
            <select name=\"table_name\" datatype=\"*\">";echo "
              <option value=\"kehu\">客户管理（Kehu）</option>";echo "
              <option value=\"linkman\">联系人（Linkman）</option>";echo "
              <option value=\"gendan\">跟单管理（Gendan）</option>";echo "
              <option value=\"dingdan\">订单管理（Dingdan）</option>";echo "
              <option value=\"hetong\">合同管理（Hetong）</option>";echo "
              <option value=\"shouhou\">售后管理（Shouhou）</option>";echo "
              <option value=\"caiwu\">财务管理（Caiwu）</option>";echo "
            </select>";echo "
";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 显示名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input id=\"title\" name=\"title\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"s1-6\" />";echo "
          <br>";echo "
          字段显示名称，例如：客户来源、客户级别等 </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 字段名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input id=\"name\" name=\"name\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"/^[a-zA-Z][a-zA-Z\\d]+\$/\" errormsg=\"只能是英文或数字，英文开头\" />";echo "
          <br>";echo "
          只能由英文字母、数字组成 </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 字段类型 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
";echo "
            <select name='type' id=\"type\" datatype=\"*\">";echo "
              <option value=\"\">请选择字段类型...</option>";echo "
              <option value=\"text\"> 单行文本（Text） </option>";echo "
              <option value=\"textarea\"> 多行文本（Textarea） </option>";echo "
              <option value=\"money\"> 金额（Money） </option>";echo "
              <option value=\"yes\"> 是否（Yes） </option>";echo "
              <option value=\"radio\"> 单选（Radio） </option>";echo "
              <option value=\"checkbox\"> 多项选择（Checkbox） </option>";echo "
              <option value=\"select\"> 下拉选择（Select） </option>";echo "
              <option value=\"datetime\"> 日期时间（Datetime） </option>";echo "
              <option value=\"area\"> 所在地区（Area） </option>";echo "
              <option value=\"upload\"> 文件上传（Upload） </option>";echo "
              <option value=\"linkman\"> 客户联系人（Linkman） </option>";echo "
              <option value=\"users\"> 员工选择（Users） </option>";echo "
            </select>";echo "
";echo "
        </dd>";echo "
      </dl>";echo "
      <dl class=\"type_show\" style=\"display:none;\">";echo "
        <dt>参数配置 <font color=\"#f00;\">*</font> </dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"content\" id=\"content\" class=\"input\" style=\"height:80px;width:98%;\">选项值1|选项值2</textarea>";echo "
          <br>";echo "
          <span id=\"tianxietips\">每个选项值用 | 符号分开</span> </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt><font color=\"#f00;\"></font> 填写提示</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"tip\" type=\"text\" value=\"\" class=\"input normal\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>选项</dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-multi-porp multi-porp\">";echo "
            <ul>";echo "
              <li><a href=\"javascript:;\">必填字段</a><i class=\"fa-check-square-o-mark\"></i></li>";echo "
              <li><a href=\"javascript:;\">列表显示</a><i class=\"fa-check-square-o-mark\"></i></li>";echo "
              <li><a href=\"javascript:;\">高级搜索</a><i class=\"fa-check-square-o-mark\"></i></li>";echo "
            </ul>";echo "
            <span id=\"cblAttributeField\" style=\"display: none;\">";echo "
            <input id=\"bitian\" name=\"bitian\" type=\"checkbox\" value=\"1\">";echo "
            <label for=\"bitian\">必填字段</label>";echo "
            <input id=\"liebiao\" name=\"liebiao\" type=\"checkbox\" value=\"1\">";echo "
            <label for=\"liebiao\">列表显示</label>";echo "
            <input id=\"sousuo\" name=\"sousuo\" type=\"checkbox\" value=\"1\">";echo "
            <label for=\"sousuo\">高级搜索</label>";echo "
            </span> </div>";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt><font color=\"#f00;\"></font> 字段排序</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"ord\" type=\"text\" value=\"50\" class=\"input\" datatype=\"*\" size=\"4\"/>";echo "
          数字越小越靠前，默认50 </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>是否启用</dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-single-checkbox single-checkbox\"><a href=\"javascript:;\"><i class=\"off\">否</i><i class=\"on\">是</i></a>";echo "
            <input name=\"inuse\" type=\"checkbox\" style=\"display: none;\" value=\"是\" checked>";echo "
          </div>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <script>";echo "
";echo "
\$(function(){";echo "
   types(); ";echo "
   z_datetime();";echo "
});";echo "
";echo "
\$(\"#type\").change(function(){";echo "
";echo "
   types();";echo "
   z_datetime();";echo "
     ";echo "
});";echo "
";echo "
function types(){";echo "
";echo "
   if(\$(\"#type\").val()==\"radio\"||\$(\"#type\").val()==\"checkbox\"||\$(\"#type\").val()==\"select\"||\$(\"#type\").val()==\"datetime\"){";echo "
	  \$(\".type_show\").css(\"display\",\"block\");";echo "
	  \$(\"#content\").attr('datatype','*');";echo "
   }else{";echo "
	  \$(\".type_show\").css(\"display\",\"none\");";echo "
	  \$(\"#content\").removeAttr('datatype');";echo "
   } ";echo "
   ";echo "
}";echo "
";echo "
";echo "
function z_datetime(){";echo "
if(\$(\"#type\").val()==\"datetime\"){";echo "
\$(\"#tianxietips\").text(\"时间格式：yyyy-MM-dd HH:mm:ss\");";echo "
\$(\"#content\").val(\"yyyy-MM-dd HH:mm:ss\");";echo "
}else{";echo "
\$(\"#tianxietips\").text(\"每个选项值用 | 符号分开\");";echo "
}";echo "
";echo "
}";echo "
</script> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>