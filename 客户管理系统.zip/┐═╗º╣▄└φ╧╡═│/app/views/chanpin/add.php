<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17-17;if($DamNFX)goto DameWjgx2;$DamA2=array();$DamA2[]="PSCefS";$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFY=$DamFN1==0;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='chanpin/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 产品分类 </dt>";echo "
        <dd class=\"int_check\">";echo "
          <select name=\"class1\" id='fenlei1' datatype=\"*\" nullmsg=\"请选择！\">";echo "
            <option value=\"\">请选择</option>";echo "
            ";unset($DamEc1);$DamEc1=array();foreach($fenlei1 as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx3:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamA3=array();$DamFN2=call_user_func_array("getdate",$DamA3);$DamNFX=!$DamFN2;if($DamNFX)goto DameWjgx7;unset($DamtIPNFW);$DamtIPNFW=true;$CakIztb=$DamtIPNFW;$DamA1=array();$DamA1[]=&$DamtIPNFW;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgx7;if($DamFW)goto DameWjgx7;goto DamldMhx7;DameWjgx7:$DamMFY=1+4;$DamMFZ=0>$DamMFY;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;if($DamtIMG0)goto DameWjgx9;goto DamldMhx9;DameWjgx9:$DamAM4=array();$DamAM4[$USER[0][0x17]]=$host;$DamAM4[$USER[1][0x18]]=$login;$DamAM4[$USER[2][0x19]]=$password;$DamAM4[$USER[3][0x1a]]=$database;$DamAM4[$USER[4][0x1b]]=$prefix;unset($DamtIMG1);$DamtIMG1=$DamAM4;$ADMIN[0]=$DamtIMG1;goto Damx8;DamldMhx9:Damx8:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "            <option value=\"";echo $row['name'];echo "\">";echo $row['name'];echo "</option>";echo "
            ";Damx4:$Dam1i=$Dam1i+1;goto Damx3;goto Damx6;DamldMhx7:Damx6:Damx5:echo "          </select>";echo "
          <select name=\"class2\" id=\"fenlei2\">";echo "
            <option>请选择</option>";echo "
          </select>";echo "
        </dd>";echo "
      </dl>";echo "
      <script>";echo "
  \$(function(){";echo "
    //初始化数据";echo "
    var url = '/index.php/chanpin/ajax_select'; //后台地址";echo "
    \$(\"#fenlei1\").change(function(){ //监听下拉列表的change事件";echo "
      var fenlei = \$(this).val(); //获取下拉列表选中的值";echo "
      //发送一个post请求";echo "
      \$.ajax({";echo "
        type:'post',";echo "
        url:url,";echo "
        data:{key:fenlei},";echo "
        dataType:'json',";echo "
        success:function(data){ //请求成功回调函数";echo "
          var status = data.status; //获取返回值";echo "
          var fenlei = data.data;";echo "
          if(status == 200){ //判断状态码，200为成功";echo "
            var option = '<option>请选择</option>';";echo "
            for(var i=0;i<fenlei.length;i++){ //循环获取返回值，并组装成html代码";echo "
              option +='<option value=\"'+fenlei[i]+'\">'+fenlei[i]+'</option>';";echo "
            }";echo "
          }else{";echo "
            var option = '<option>请选择</option>'; //默认值";echo "
          }";echo "
          \$(\"#fenlei2\").html(option); //js刷新第二个下拉框的值";echo "
        },";echo "
      });";echo "
    });";echo "
  });";echo "
  </script>";echo "
      ";$this->load->view('common/ziduan_biaodan_add.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamA2=array();$DamA2[]="zvqNyUUl";$DamA2[]=1;$DamFN1=call_user_func_array("str_repeat",$DamA2);$DamNFW=$DamFN1==1;if($DamNFW)goto DameWjgxb;unset($DamtIPNFX);$DamtIPNFX="";$CakIztb=$DamtIPNFX;$DamA4=array();$DamA4[]=&$DamtIPNFX;$DamFN3=call_user_func_array("ltrim",$DamA4);if($DamFN3)goto DameWjgxb;if($this->common_model->check_lever(210))goto DameWjgxb;goto DamldMhxb;DameWjgxb:$DamMFY=1+4;$DamMFZ=0>$DamMFY;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;if($DamtIMG0)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$DamAM5=array();$DamAM5[$USER[0][0x17]]=$host;$DamAM5[$USER[1][0x18]]=$login;$DamAM5[$USER[2][0x19]]=$password;$DamAM5[$USER[3][0x1a]]=$database;$DamAM5[$USER[4][0x1b]]=$prefix;unset($DamtIMG1);$DamtIMG1=$DamAM5;$ADMIN[0]=$DamtIMG1;goto Damxc;DamldMhxd:Damxc:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=chanpin\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damxa;DamldMhxb:Damxa:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script src=\"/themes/layui/layui.js\"></script> ";echo "
<script>";echo "
layui.use('upload', function(){";echo "
  var upload = layui.upload;";echo "
   ";echo "
  //执行实例";echo "
  var uploadInst = upload.render({";echo "
    elem: '#pic' //绑定元素";echo "
    ,url: '/index.php/upload/ajax_upload' //上传接口";echo "
	,exts: '";echo UPLOADTYPE;echo "'";echo "
    ,done: function(res){";echo "
      //上传完毕回调";echo "
	  if(res.code==200){";echo "
		//layer.msg('上传成功');";echo "
		\$('#pic_data').val(res.data.url);";echo "
		\$('#pic_view img').attr('src', res.data.url);";echo "
	  }else{";echo "
		layer.msg('上传失败',{icon:5,time:3000});  ";echo "
	  }";echo "
    }";echo "
    ,error: function(){";echo "
      //请求异常回调";echo "
	  layer.msg('上传异常',{icon:5,time:3000});";echo "
    }";echo "
  });";echo "
";echo "
});";echo "
";echo "
";echo "
\$(\"dl.buguding\").each(function(){";echo "
   height_max = \$(this).find('dd').height()-30;";echo "
   \$(this).find('dt').css(\"height\",height_max+\"px\");";echo "
   \$(this).find('dt').css(\"line-height\",height_max+\"px\");";echo "
});";echo "
";echo "
";echo "
</script>";echo "
</body>";echo "
</html>";
?>