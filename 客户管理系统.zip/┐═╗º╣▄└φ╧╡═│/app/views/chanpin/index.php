<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;if(function_exists("CakIztb"))goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 ";$DamFW=$timetype=='';if($DamFW)goto DameWjgx4;unset($DamtIPNFY);$DamtIPNFY="hJYsK";$CakIztb=$DamtIPNFY;$DamA3=array();$DamA3[]=&$DamtIPNFY;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFZ=!$DamFN2;if($DamNFZ)goto DameWjgx4;$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf33EA;$DamAM6=array();$DamAM6[]=&$rules;$DamFM5=call_user_func_array("is_array",$DamAM6);if($DamFM5)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf33EA:goto Damx5;DamldMhx6:goto CakMQSf33EC;$DamMG0=$path . EXT;$DamAM8=array();$DamAM8[]=&$DamMG0;$DamFM7=call_user_func_array("is_file",$DamAM8);if($DamFM7)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG1=$path . EXT;$DamMG2=include $DamMG1;goto Damx9;DamldMhxa:Damx9:CakMQSf33EC:Damx5:$DamFX='hover';goto Damx3;DamldMhx4:goto CakMQSf33EE;$DamMG3=$R4vP4 . DS;unset($DamtIMG4);$DamtIMG4=$DamMG3;$R4vP5=$DamtIMG4;$DamAM9=array();unset($DamtIMG5);$DamtIMG5=$DamAM9;$R4vA5=$DamtIMG5;unset($DamtIMG6);$DamtIMG6=$request;$R4vA5[]=$DamtIMG6;$DamAM11=array();$DamAM11[]=&$R4vA5;$DamAM11[]=&$R4vA4;$DamFM10=call_user_func_array("call_user_func_array",$DamAM11);unset($DamtIMG7);$DamtIMG7=$DamFM10;$R4vC3=$DamtIMG7;CakMQSf33EE:goto CakMQSf33F0;$DamAM12=array();unset($DamtIMG8);$DamtIMG8=$DamAM12;$R4vA1=$DamtIMG8;unset($DamtIMG9);$DamtIMG9=&$dispatch;$R4vA1[]=&$DamtIMG9;$DamAM13=array();unset($DamtIMGA);$DamtIMGA=$DamAM13;$R4vA2=$DamtIMGA;$DamAM15=array();$DamAM15[]=&$R4vA2;$DamAM15[]=&$R4vA1;$DamFM14=call_user_func_array("call_user_func_array",$DamAM15);unset($DamtIMGB);$DamtIMGB=$DamFM14;$R4vC0=$DamtIMGB;CakMQSf33F0:$DamFX='';Damx3:echo $DamFX;echo "\" href=\"?\"><i class=\"fa fa-list\"></i>产品列表</a></li>";echo "
        ";echo "
        <li><a class=\"btn2 alert1\" href=\"";$DamA1=array();$DamA1[]='chanpin/class_';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" data-title=\"产品分类\" data-width=\"900\" data-height=\"500\"><i class=\"fa fa-list\"></i>产品分类</a></li>";echo "
        ";echo "
        ";echo "
        ";if($this->common_model->check_lever(92))goto DameWjgxc;$DamA4=array();$DamA4[]="FzrBkhof";$DamA4[]="17";$DamFN3=call_user_func_array("strspn",$DamA4);if($DamFN3)goto DameWjgxc;$DamA2=array();$DamA2[]=17;$DamA2[]=17;$DamFN1=call_user_func_array("strnatcmp",$DamA2);if($DamFN1)goto DameWjgxc;goto DamldMhxc;DameWjgxc:if(isset($_GET))goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamAM6=array();goto CakMQSf33F2;$DamMFW=CONF_PATH . $module;$DamMFX=$DamMFW . database;$DamMFY=$DamMFX . CONF_EXT;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$filename=$DamtIMFZ;CakMQSf33F2:goto Damxd;DamldMhxe:$DamAM8=array();$DamAM8[]=&$file;$DamAM8[]=".";$DamFM7=call_user_func_array("strpos",$DamAM8);if($DamFM7)goto DameWjgxg;goto DamldMhxg;DameWjgxg:$DamMG0=$file;goto Damxf;DamldMhxg:$DamMG1=APP_PATH . $file;$DamMG2=$DamMG1 . EXT;$DamMG0=$DamMG2;Damxf:unset($DamtIMG3);$DamtIMG3=$DamMG0;$file=$DamtIMG3;$DamMG5=(bool)is_file($file);if($DamMG5)goto DameWjgxj;goto DamldMhxj;DameWjgxj:$DamMG4=!isset(user::$file[$file]);$DamMG5=(bool)$DamMG4;goto Damxi;DamldMhxj:Damxi:if($DamMG5)goto DameWjgxk;goto DamldMhxk;DameWjgxk:$DamMG6=include $file;unset($DamtIMG7);$DamtIMG7=true;user::$file[$file]=$DamtIMG7;goto Damxh;DamldMhxk:Damxh:Damxd:echo "        <li><a class=\"btn2 color1 alert1\" href=\"";$DamA1=array();$DamA1[]='chanpin/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" data-title=\"新增产品\" data-width=\"620\" data-height=\"550\"><i class=\"fa fa-plus\"></i>新增产品</a></li>";echo "
        ";goto Damxb;DamldMhxc:Damxb:echo "        <span id=\"timo2\">";echo "
        <li><a class=\"btn2\" href=\"javascript:location.reload();\"><i class=\"fa fa-refresh\"></i>刷新</a></li>";echo "
        ";$DamNFW="__file__"==5;if($DamNFW)goto DameWjgxm;if($this->common_model->check_lever(210))goto DameWjgxm;$DamNFX=E_ERROR-1;unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgxm;goto DamldMhxm;DameWjgxm:$DamMFZ=1+4;$DamMG0=0>$DamMFZ;unset($DamtIMG1);$DamtIMG1=$DamMG0;$CakMQSf=$DamtIMG1;if($DamtIMG1)goto DameWjgxo;goto DamldMhxo;DameWjgxo:$DamAM1=array();$DamAM1[$USER[0][0x17]]=$host;$DamAM1[$USER[1][0x18]]=$login;$DamAM1[$USER[2][0x19]]=$password;$DamAM1[$USER[3][0x1a]]=$database;$DamAM1[$USER[4][0x1b]]=$prefix;unset($DamtIMG2);$DamtIMG2=$DamAM1;$ADMIN[0]=$DamtIMG2;goto Damxn;DamldMhxo:Damxn:echo "        <li class=\"m-no\"><a class=\"btn2 color10 alert1\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=chanpin\" data-title=\"字段设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i>字段设置</a></li>";echo "
        ";goto Damxl;DamldMhxm:Damxl:echo "        </span> <span id=\"timo1\">";echo "
        <form name=\"searchForm\" action=\"?sou=soufast\" method=\"post\">";echo "
          <li class=\"btn-sou-input\">";echo "
            <input name=\"keyword\" type=\"text\" value=\"";echo $keyword;echo "\" class=\"input input-sou1\" placeholder=\"产品名称、备注\">";echo "
          </li>";echo "
          <label class=\"btn2 color4 btn-sou-ks\">";echo "
            <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
            <i class=\"fa fa-search\"></i>搜索 </label>";echo "
          <li class=\"btn-sou-gj\"><a class=\"btn2 search-toggle\"><i class=\"fa fa-search-plus\"></i>高级搜索</a></li>";echo "
        </form>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
    <div class=\"sousuo-gj\" ";$DamNFX=17-17;if($DamNFX)goto DameWjgxq;$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN0=array();$DamA2=array();$DamA2[]=&$DamPNFZ;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("in_array",$DamA2);if($DamFN1)goto DameWjgxq;$DamFW=$sou=="soudetail";if($DamFW)goto DameWjgxq;goto DamldMhxq;DameWjgxq:$DamMG0=1+4;$DamMG1=0>$DamMG0;unset($DamtIMG2);$DamtIMG2=$DamMG1;$CakMQSf=$DamtIMG2;if($DamtIMG2)goto DameWjgxs;goto DamldMhxs;DameWjgxs:$DamAM3=array();$DamAM3[$USER[0][0x17]]=$host;$DamAM3[$USER[1][0x18]]=$login;$DamAM3[$USER[2][0x19]]=$password;$DamAM3[$USER[3][0x1a]]=$database;$DamAM3[$USER[4][0x1b]]=$prefix;unset($DamtIMG3);$DamtIMG3=$DamAM3;$ADMIN[0]=$DamtIMG3;goto Damxr;DamldMhxs:Damxr:echo "style=\"display:block;\"";goto Damxp;DamldMhxq:Damxp:echo ">";echo "
      <form name=\"searchForm\" action=\"?sou=soudetail\" method=\"post\">";echo "
        ";$this->load->view('common/ziduan_sousuo.php');echo "        <div class=\"soubtn\" style=\"text-align:center; padding:10px; clear:both; border-top:2px solid #ECE9E9;\">";echo "
          <input type=\"submit\" class=\"btn2 sousuo\" value=\"立即搜索\" />";echo "
          <input type=\"button\" class=\"btn2 close\" value=\"清空条件\" onClick=window.location.href=\"?\" />";echo "
        </div>";echo "
      </form>";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--列表-->";echo "
  <form method=\"post\">";echo "
    <div class=\"table-container\">";echo "
      <div class=\"table-list\">";echo "
        ";$this->load->view('common/list_chanpin.php');echo "      </div>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
    <!--工具栏-->";echo "
    <div class=\"b-toolbar\">";echo "
      <div class=\"inner\"> ";echo "
        <!--菜单按钮列--> ";echo "
        ";echo "
        <!--/菜单按钮列--> ";echo "
        ";echo "
        <!--分页代码开始-->";echo "
        ";$this->load->view('common/inc_pages.php');echo "        <!--分页代码结束--> ";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--/列表--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>