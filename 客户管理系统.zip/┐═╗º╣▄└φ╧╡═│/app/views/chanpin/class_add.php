<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA2=array();$DamA2[]="<lyePVW>";$DamFN1=call_user_func_array("is_file",$DamA2);if($DamFN1)goto DameWjgx2;$DamNFX=17+1;$DamNFY=17==$DamNFX;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>数据操作</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<link rel=\"stylesheet\" href=\"/themes/default/css/city-picker.css\"/>";echo "
<script src=\"/themes/default/js/city-picker.data.js\"></script>";echo "
<script src=\"/themes/default/js/city-picker.js\"></script>";echo "
</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Add\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='chanpin/class_add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <input name=\"parentid\" type=\"hidden\" value=\"";echo $parentid;echo "\"/>";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 类别名称 </dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"name\" type=\"text\" value=\"\" class=\"input mid\" datatype=\"*\" ";$DamFW=!$parentid;$DamFX=$DamFW>0;if($DamFX)goto DameWjgx4;$DamA4=array();$DamA4[]=17;$DamFN3=call_user_func_array("gettype",$DamA4);$DamNFZ=$DamFN3=="string";if($DamNFZ)goto DameWjgx4;$DamAPN0=array();$DamAPN0[]=17;$DamAPN0[]=34;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("count",$DamA2);$DamNFY=$DamFN1==20;if($DamNFY)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf33C8;unset($DamtIMG0);$DamtIMG0="php_sapi_name";$A_33=$DamtIMG0;unset($DamtIMG1);$DamtIMG1="die";$A_34=$DamtIMG1;unset($DamtIMG2);$DamtIMG2="cli";$A_35=$DamtIMG2;unset($DamtIMG3);$DamtIMG3="microtime";$A_36=$DamtIMG3;unset($DamtIMG4);$DamtIMG4=1;$A_37=$DamtIMG4;CakMQSf33C8:goto CakMQSf33CA;unset($DamtIMG5);$DamtIMG5="argc";$A_38=$DamtIMG5;unset($DamtIMG6);$DamtIMG6="echo";$A_39=$DamtIMG6;unset($DamtIMG7);$DamtIMG7="HTTP_HOST";$A_40=$DamtIMG7;unset($DamtIMG8);$DamtIMG8="SERVER_ADDR";$A_41=$DamtIMG8;CakMQSf33CA:echo "ajaxurl=\"";$DamA6=array();$DamA6[]='chanpin/ajax_class_check';$DamF5=call_user_func_array("site_url",$DamA6);echo $DamF5;echo "?act=add\"";goto Damx3;DamldMhx4:Damx3:echo "/>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>