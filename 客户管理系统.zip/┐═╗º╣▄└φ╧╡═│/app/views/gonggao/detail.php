<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFY=17=="";unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="PSCefS";$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFX=$DamFN1==0;if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <div class=\"tab-content\">";echo "
    <dl>";echo "
      <dt>公告分类 <font color=\"#f00;\">*</font></dt>";echo "
      <dd class=\"int_check\"> ";echo $types;echo " </dd>";echo "
    </dl>";echo "
    <dl>";echo "
      <dt>公告标题 <font color=\"#f00;\">*</font></dt>";echo "
      <dd class=\"int_check\"> ";echo $title;echo " </dd>";echo "
    </dl>";echo "
    <dl>";echo "
      <dt>公告内容 <font color=\"#f00;\">*</font></dt>";echo "
      <dd class=\"int_check\"> ";$DamA1=array();$DamA1[]=&$content;$DamF0=call_user_func_array("str_htmldecode",$DamA1);echo $DamF0;echo " </dd>";echo "
    </dl>";echo "
  </div>";echo "
  <!--/内容--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>