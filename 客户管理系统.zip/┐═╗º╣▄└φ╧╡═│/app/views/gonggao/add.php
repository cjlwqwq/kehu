<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

if(function_exists("CakIztb"))goto DameWjgx2;$DamA3=array();$DamA3[]=__FILE__;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<script src=\"/themes/editor/xheditor-1.2.2.min.js\"></script>";echo "
<script src=\"/themes/editor/xheditor_lang/zh-cn.js\"></script>";echo "
</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='gonggao/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <!--内容-->";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt>公告分类 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-multi-radio\"> <span>";echo "
            ";unset($DamEc1);$DamEc1=array();foreach($types as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx3:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;if($DamFW)goto DameWjgx7;$DamA1=array();$DamA1[]=E_PARSE;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="HGxIk";if($DamNFW)goto DameWjgx7;$DamNFX=17+1;$DamNFY=17==$DamNFX;if($DamNFY)goto DameWjgx7;goto DamldMhx7;DameWjgx7:try{$DamAM3=array();$DamAM3[]=1;$DamFM2=call_user_func_array("strlen",$DamAM3);goto DamFax8;DamCtx8:$DamMG6=$DamTex8 instanceof \Exception;if($DamMG6)goto DameWjgxg;goto DamldMhxg;DameWjgxg:unset($DamtIMG7);$DamtIMG7=$DamTex8;$e=$DamtIMG7;$DamMFZ=$x*5;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG8);$DamtIMG8=$DamtIMG0;$y=$DamtIMG8;echo "no login!";exit(1);goto DamFax8;goto Damxf;DamldMhxg:Damxf:$DamMG3=$DamTex8 instanceof \Exception;if($DamMG3)goto DameWjgxe;goto DamldMhxe;DameWjgxe:unset($DamtIMG4);$DamtIMG4=$DamTex8;$e=$DamtIMG4;$DamMG1=$x*1;unset($DamtIMG2);$DamtIMG2=$DamMG1;unset($DamtIMG5);$DamtIMG5=$DamtIMG2;$y=$DamtIMG5;echo "no html!";exit(2);goto DamFax8;goto Damxd;DamldMhxe:Damxd:DamFax8:$DamAM14=array();$DamAM14[]="DamRtx8";$DamAM14[]=get_defined_vars();$DamFM11=call_user_func_array("array_key_exists",$DamAM14);if($DamFM11)goto DameWjgxc;goto DamldMhxc;DameWjgxc:return $DamRtx8;goto Damxb;DamldMhxc:Damxb:$DamAM8=array();$DamAM8[]="DamTrx8";$DamAM8[]=get_defined_vars();$DamFM5=call_user_func_array("array_key_exists",$DamAM8);if($DamFM5)goto DameWjgxa;goto DamldMhxa;DameWjgxa:throw $DamTrx8;goto Damx9;DamldMhxa:Damx9:}catch(\Exception $e){$DamTex8=$e;goto DamCtx8;}catch(\Error $e){$DamTex8=$e;goto DamCtx8;}$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "            <input type=\"radio\" name=\"types\" value=\"";echo $row;echo "\" datatype=\"*\" />";echo "
            <label>";echo $row;echo "</label>";echo "
            ";Damx4:$Dam1i=$Dam1i+1;goto Damx3;goto Damx6;DamldMhx7:Damx6:Damx5:echo "            </span></div>";echo "
          <a class=\"btn1 color1 alert1\" href=\"";$DamA1=array();$DamA1[]='ziduan/fastset';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=123\" data-title=\"设置选项值\" data-width=\"520\" data-height=\"250\"><i class=\"fa fa-plus-circle\"></i>设置</a> </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>公告标题 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"title\" type=\"text\" class=\"input int-max\" value=\"\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>公告内容 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"content\" class=\"xheditor-mfull {skin:'nostyle'}\" rows=\"20\" cols=\"80\" style=\"width:98%\" datatype=\"*\" nullmsg=\"内容为空或者内容过少！\"></textarea>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>