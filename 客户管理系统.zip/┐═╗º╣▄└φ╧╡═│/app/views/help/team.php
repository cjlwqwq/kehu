<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA4=array();$DamA4[]=E_PARSE;$DamFN3=call_user_func_array("gettype",$DamA4);$DamNFY=$DamFN3=="HGxIk";if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("chr",$DamA2);$DamNFX=$DamFN1=="h";if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
";echo "
  <style>";echo "
* { line-height: 30px; }";echo "
a { text-decoration: none; }";echo "
.jszc h1 { font-size: 18px; text-align: center; }";echo "
.jszc a { color:#2B2828; }";echo "
</style>";echo "
  <div style=\"width:500px; height:300px; border:1px dashed #CBC9C9; \">";echo "
    <div style=\"padding:15px; padding-bottom:0;\" class=\"jszc\">";echo "
      <h1 style=\"margin-bottom:10px;\">帮管客CRM客户管理系统</h1>";echo "
      <p><strong>当前版本：</strong>正式版v";echo $this->common_model->version;echo " </p>";echo "
      <p><strong>客服电话：</strong>027-59765168（工作日8:00-20:00）</p>";echo "
      <p><strong>官方网站：</strong><a href=\"http://www.bgk100.com\" target=\"_blank\">www.bgk100.com</a></p>";echo "
      <p><strong>QQ交流群：</strong>223060900 <img src=\"/themes/default/images/qqqun.png\" width=\"150\" height=\"150\"> </p>";echo "
      </p>";echo "
    </div>";echo "
  </div>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>