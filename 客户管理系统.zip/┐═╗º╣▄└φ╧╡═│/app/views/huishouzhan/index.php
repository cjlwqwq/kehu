<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17+1;$DamNFY=17>$DamNFX;if($DamNFY)goto DameWjgx2;$DamAPN1=array();$DamAPN1[]=17;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("key",$DamA3);if($DamFN2)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1,maximum-scale=1\">";echo "
<!--设备的缩放-->";echo "
<meta name=\"format-detection\" content=\"telephone=no\" >";echo "
<!--禁止自动识别数字为手机号码-->";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\">";echo "
<!--去掉苹果工具栏和菜单栏-->";echo "
<meta name=\"apple-touch-fullscreen\" content=\"yes\">";echo "
<!--全屏-->";echo "
";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 ";$DamFW=$timetype=='';$DamPNFY=new \Exception();if(method_exists($DamPNFY,17))goto DameWjgx4;$DamPNFZ=25-17;$DamA2=array();$DamA2[]=&$DamPNFZ;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx4;if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf34EE;$DamMG0=$R4vP4 . DS;unset($DamtIMG1);$DamtIMG1=$DamMG0;$R4vP5=$DamtIMG1;$DamAM3=array();unset($DamtIMG2);$DamtIMG2=$DamAM3;$R4vA5=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=$request;$R4vA5[]=$DamtIMG3;$DamAM5=array();$DamAM5[]=&$R4vA5;$DamAM5[]=&$R4vA4;$DamFM4=call_user_func_array("call_user_func_array",$DamAM5);unset($DamtIMG4);$DamtIMG4=$DamFM4;$R4vC3=$DamtIMG4;CakMQSf34EE:goto CakMQSf34F0;$DamAM6=array();unset($DamtIMG5);$DamtIMG5=$DamAM6;$R4vA1=$DamtIMG5;unset($DamtIMG6);$DamtIMG6=&$dispatch;$R4vA1[]=&$DamtIMG6;$DamAM7=array();unset($DamtIMG7);$DamtIMG7=$DamAM7;$R4vA2=$DamtIMG7;$DamAM9=array();$DamAM9[]=&$R4vA2;$DamAM9[]=&$R4vA1;$DamFM8=call_user_func_array("call_user_func_array",$DamAM9);unset($DamtIMG8);$DamtIMG8=$DamFM8;$R4vC0=$DamtIMG8;CakMQSf34F0:$DamFX='hover';goto Damx3;DamldMhx4:$DamAM11=array();$DamAM11[]=4;$DamFM10=call_user_func_array("strlen",$DamAM11);$DamMG9=$DamFM10<1;if($DamMG9)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM13=array();$DamFM12=call_user_func_array($adminL,$DamAM13);CakMQSf34F2:igjagoe;$DamAM15=array();$DamAM15[]="wolrlg";$DamFM14=call_user_func_array("strlen",$DamAM15);$DamAM17=array();$DamAM17[]=4;$DamFM16=call_user_func_array("getnum",$DamAM17);goto Damx5;DamldMhx6:Damx5:goto CakMQSf34F3;$DamAM19=array();$DamAM19[]=&$rule;$DamFM18=call_user_func_array("is_array",$DamAM19);if($DamFM18)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamAM21=array();$DamAM21["rule"]=$rule;$DamAM21["msg"]=$msg;unset($DamtIMGA);$DamtIMGA=$DamAM21;$this->validate=$DamtIMGA;goto Damx7;DamldMhx8:$DamMGB=true===$rule;if($DamMGB)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMGC=$this->name;goto Damx9;DamldMhxa:$DamMGC=$rule;Damx9:unset($DamtIMGD);$DamtIMGD=$DamMGC;$this->validate=$DamtIMGD;Damx7:CakMQSf34F3:$DamFX='';Damx3:echo $DamFX;echo "\" href=\"?\"><i class=\"fa fa-list\"></i>回收站列表</a></li>";echo "
        <span class=\"tips\"> 提示：目前回收站仅支持客户资料管理 </span> <span id=\"timo2\">";echo "
        <li><a class=\"btn2 btn-primary tree_table_all_open waves-effect\" href=\"javascript:;\" id=\"zksqAll\" data-target=\"#contents\"><i class=\"fa fa-caret-down\"></i>全部展开</a></li>";echo "
        <li><a class=\"btn2\" href=\"javascript:location.reload();\"><i class=\"fa fa-refresh\"></i>刷新</a></li>";echo "
        </span> <span id=\"timo1\">";echo "
        <form name=\"searchForm\" action=\"?sou=soufast\" method=\"post\">";echo "
          <li class=\"btn-sou-input\">";echo "
            <input name=\"keyword\" type=\"text\" value=\"";echo $keyword;echo "\" class=\"input input-sou1\" placeholder=\"客户名称、联系人、手机\">";echo "
          </li>";echo "
          <label class=\"btn2 color4 btn-sou-ks\">";echo "
            <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
            <i class=\"fa fa-search\"></i>搜索 </label>";echo "
          <li class=\"btn-sou-gj\"><a class=\"btn2 search-toggle\"><i class=\"fa fa-search-plus\"></i>高级搜索</a></li>";echo "
        </form>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
    <div class=\"sousuo-gj\" ";unset($DamtIPNFX);$DamtIPNFX=true;$CakIztb=$DamtIPNFX;$DamA1=array();$DamA1[]=&$DamtIPNFX;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgxc;$DamFW=$sou=="soudetail";if($DamFW)goto DameWjgxc;$DamNFY=__LINE__<-17;if($DamNFY)goto DameWjgxc;goto DamldMhxc;DameWjgxc:if(function_exists("CakMQSf"))goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamAM3=array();$DamAM3[]="56e696665646";$DamAM3[]="450594253435";$DamAM3[]="875646e696";$DamAM3[]="56d616e6279646";unset($DamtIMFZ);$DamtIMFZ=$DamAM3;$var_12["arr_1"]=$DamtIMFZ;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxl:$DamAM15=array();$DamAM15[]=&$DamEc1;$DamFM14=call_user_func_array("count",$DamAM15);$DamMG4=$Dam1i<$DamFM14;if($DamMG4)goto DameWjgxv;goto DamldMhxv;DameWjgxv:$DamAM17=array();$DamAM17[]=&$DamEc1;$DamFM16=call_user_func_array("array_keys",$DamAM17);unset($DamtIMG5);$DamtIMG5=$DamFM16;unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$k=$DamtIMG9;unset($DamtIMG6);$DamtIMG6=$k[$Dam1i];unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$k=$DamtIMGA;unset($DamtIMG7);$DamtIMG7=$DamEc1[$k];unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$vo=$DamtIMGB;unset($DamVM5);unset($DamVM10);$DamAM13=array();$DamAM13[]=&$var_12;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgxx;goto DamldMhxx;DameWjgxx:goto DameWjgxp;goto Damxw;DamldMhxx:Damxw:goto DamldMhxp;DameWjgxp:goto DameWjgxj;goto Damxo;DamldMhxp:Damxo:goto DamldMhxj;DameWjgxj:$DamVM10=&$var_12["arr_1"];goto Damxi;DamldMhxj:$DamVM10=$var_12["arr_1"];Damxi:$DamAM11=array();$DamAM11[]=&$DamVM10;$DamFM9=call_user_func_array("is_array",$DamAM11);if($DamFM9)goto DameWjgxz;goto DamldMhxz;DameWjgxz:goto DameWjgxr;goto Damxy;DamldMhxz:Damxy:goto DamldMhxr;DameWjgxr:goto DameWjgxk;goto Damxq;DamldMhxr:Damxq:goto DamldMhxk;DameWjgxk:$DamVM5=&$var_12["arr_1"][$k];goto Damxh;DamldMhxk:$DamVM5=$var_12["arr_1"][$k];Damxh:$DamAM6=array();$DamAM6[]=&$DamVM5;$DamFM4=call_user_func_array("gettype",$DamAM6);$DamMG0=$DamFM4=="string";$DamMG2=(bool)$DamMG0;if($DamMG2)goto DameWjgx12;goto DamldMhx12;DameWjgx12:goto DameWjgxt;goto Damx11;DamldMhx12:Damx11:goto DamldMhxt;DameWjgxt:goto DameWjgxg;goto Damxs;DamldMhxt:Damxs:goto DamldMhxg;DameWjgxg:$DamAM8=array();$DamAM8[]=&$vo;$DamFM7=call_user_func_array("fun_3",$DamAM8);unset($DamtIMG1);$DamtIMG1=$DamFM7;unset($DamtIMG3);$DamtIMG3=$DamtIMG1;unset($DamtIMG8);$DamtIMG8=$DamtIMG3;unset($DamtIMGC);$DamtIMGC=$DamtIMG8;$var_12["arr_1"][$k]=$DamtIMGC;$DamMG2=(bool)$DamtIMG1;goto Damxf;DamldMhxg:Damxf:Damxm:$Dam1i=$Dam1i+1;goto Damxl;goto Damxu;DamldMhxv:Damxu:Damxn:$DamAM19=array();$DamAM19[]="arr_1";$DamAM19[]=1;$DamFM18=call_user_func_array("fun_2",$DamAM19);$DamAM21=array();$DamAM21[]="arr_1";$DamAM21[]=2;$DamFM20=call_user_func_array("fun_2",$DamAM21);$var_12["arr_1"][0]($DamFM18,$DamFM20);goto Damxd;DamldMhxe:goto CakMQSf34F5;$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=8;$DamFM22=call_user_func_array("fun_2",$DamAM23);$DamMGD=$var_12["arr_1"][3](__FILE__) . $DamFM22;$DamMGE=require $DamMGD;$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=9;$DamFM24=call_user_func_array("fun_2",$DamAM25);$DamMGF=$var_12["arr_1"][3](__FILE__) . $DamFM24;$DamMGG=require $DamMGF;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=10;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGH=V_DATA . $DamFM26;$DamMGI=require $DamMGH;CakMQSf34F5:Damxd:echo "style=\"display:block;\"";goto Damxb;DamldMhxc:Damxb:echo ">";echo "
      <form name=\"searchForm\" action=\"?sou=soudetail\" method=\"post\">";echo "
        ";$this->load->view('common/ziduan_sousuo.php');echo "        <div class=\"soubtn\" style=\"text-align:center; padding:10px; clear:both; border-top:2px solid #ECE9E9;\">";echo "
          <input type=\"submit\" class=\"btn2 sousuo\" value=\"立即搜索\" />";echo "
          <input type=\"button\" class=\"btn2 close\" value=\"清空条件\" onClick=window.location.href=\"?\" />";echo "
        </div>";echo "
      </form>";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--列表-->";echo "
  <div class=\"table-container\">";echo "
    <form name=\"Search\" action=\"";$DamA1=array();$DamA1[]='kehu/other';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?action=CheckSub&sou=Search&PN=1\" method=\"post\">";echo "
      <div class=\"table-list\">";echo "
        ";$this->load->view('common/list_kehu.php');echo "      </div>";echo "
      <!--工具栏-->";echo "
      <div class=\"b-toolbar\">";echo "
        <div class=\"inner\"> ";echo "
          ";echo "
          <!--菜单按钮列--> ";echo "
          <!--        <div class=\"b-list\">";echo "
          <ul class=\"icon-list bottom-list\">";echo "
            <li style=\"line-height: 30px;\"><span class=\"checkall pretty primary\">";echo "
              <input type=\"checkbox\" class=\"checkall\" value=\"\" id=\"checkall\"/>";echo "
              <label><i class=\"mdi mdi-check\"></i></label>";echo "
              全选 </span></li>";echo "
            ";$DamNFW=17+1;$DamNFX=17==$DamNFW;if($DamNFX)goto DameWjgx14;$DamA2=array();$DamFN1=call_user_func_array("getdate",$DamA2);$DamNFY=!$DamFN1;if($DamNFY)goto DameWjgx14;if($this->common_model->check_lever(146))goto DameWjgx14;goto DamldMhx14;DameWjgx14:unset($DamtIMFZ);$DamtIMFZ="login";$CakMQSf=$DamtIMFZ;$DamlFkgHhx15=$DamtIMFZ;$DamMG0=$DamlFkgHhx15=="admin";if($DamMG0)goto DameWjgx1d;goto DamldMhx1d;DameWjgx1d:goto DamcgFhx16;goto Damx1c;DamldMhx1d:Damx1c:$DamMG3=$DamlFkgHhx15=="user";if($DamMG3)goto DameWjgx1b;goto DamldMhx1b;DameWjgx1b:goto DamcgFhx17;goto Damx1a;DamldMhx1b:Damx1a:goto Damx15;DamcgFhx16:$DamAM4=array();$DamAM4[]=&$depr;$DamAM4[]="|";$DamAM4[]=&$url;$DamFM3=call_user_func_array("str_replace",$DamAM4);unset($DamtIMG1);$DamtIMG1=$DamFM3;$url=$DamtIMG1;$DamAM6=array();$DamAM6[]="|";$DamAM6[]=&$url;$DamAM6[]=2;$DamFM5=call_user_func_array("explode",$DamAM6);unset($DamtIMG2);$DamtIMG2=$DamFM5;$array=$DamtIMG2;DamcgFhx17:$DamAM8=array();$DamAM8[]=&$url;$DamFM7=call_user_func_array("parse_url",$DamAM8);unset($DamtIMG4);$DamtIMG4=$DamFM7;$info=$DamtIMG4;unset($DamVM10);$DamAM13=array();$DamAM13[]=&$info;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgx19;goto DamldMhx19;DameWjgx19:$DamVM10=&$info["path"];goto Damx18;DamldMhx19:$DamVM10=$info["path"];Damx18:$DamAM11=array();$DamAM11[]="/";$DamAM11[]=&$DamVM10;$DamFM9=call_user_func_array("explode",$DamAM11);unset($DamtIMG5);$DamtIMG5=$DamFM9;$path=$DamtIMG5;Damx15:echo "            <li><a class=\"btn2\" onclick=\"share();\"><i class=\"fa fa-reply\"></i>批量还原</a></li>";echo "
            ";goto Damx13;DamldMhx14:Damx13:echo "            ";if($this->common_model->check_lever(145))goto DameWjgx1f;$DamA2=array();$DamA2[]=E_PARSE;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFW=$DamFN1=="HGxIk";if($DamNFW)goto DameWjgx1f;$DamPNFX=17+1;$DamA4=array();$DamA4[]=&$DamPNFX;$DamFN3=call_user_func_array("is_array",$DamA4);if($DamFN3)goto DameWjgx1f;goto DamldMhx1f;DameWjgx1f:$DamMFY=1+4;$DamMFZ=0>$DamMFY;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;if($DamtIMG0)goto DameWjgx1h;goto DamldMhx1h;DameWjgx1h:$DamAM5=array();$DamAM5[$USER[0][0x17]]=$host;$DamAM5[$USER[1][0x18]]=$login;$DamAM5[$USER[2][0x19]]=$password;$DamAM5[$USER[3][0x1a]]=$database;$DamAM5[$USER[4][0x1b]]=$prefix;unset($DamtIMG1);$DamtIMG1=$DamAM5;$ADMIN[0]=$DamtIMG1;goto Damx1g;DamldMhx1h:Damx1g:echo "            <li><a class=\"btn2 col-del\" onclick=\"dels();\"><i class=\"fa fa-trash-o\"></i>批量删除</a></li>";echo "
            ";goto Damx1e;DamldMhx1f:Damx1e:echo "            <div class=\"clear\"></div>";echo "
          </ul>";echo "
        </div>--> ";echo "
          <!--/菜单按钮列--> ";echo "
          ";echo "
          <!--分页代码开始-->";echo "
          ";$this->load->view('common/inc_pages.php');echo "          <!--分页代码结束--> ";echo "
        </div>";echo "
      </div>";echo "
      <!--/工具栏-->";echo "
      ";echo "
    </form>";echo "
  </div>";echo "
  ";echo "
  <!--/列表--> ";echo "
  ";echo "
  <!--内容底部-->";echo "
  <div class=\"line20\"></div>";echo "
  <span id=\"CheckSub\"></span> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script>";echo "
";echo "
function getids() {";echo "
	var arrchk = \$(\"input.aids:checked\");";echo "
	var id=\"\";";echo "
	\$(arrchk).each(function(){";echo "
		if (id==\"\") {";echo "
			  id+=this.value";echo "
		} else {";echo "
			  id+=\",\"+this.value";echo "
		}                   ";echo "
	}); ";echo "
	return id; ";echo "
} ";echo "
";echo "
";echo "
";echo "
";echo "
function zhuanyi() {";echo "
	";echo "
   if (!getids()) {";echo "
	   layer.msg('未选中数据');";echo "
       return false;";echo "
   }";echo "
";echo "
";echo "
art.dialog.open('";$DamA1=array();$DamA1[]='kehu/zhuanyi';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id='+getids());";echo "
	   };";echo "
";echo "
";echo "
";echo "
";echo "
function dels() {";echo "
	";echo "
   if (!getids()) {";echo "
	   layer.msg('未选中数据');";echo "
       return false;";echo "
   }";echo "
";echo "
   art.dialog({";echo "
	   content: '是否确定删除？',";echo "
	   icon: 'warning',";echo "
	   ok: function () {";echo "
	   art.dialog.open('";$DamA1=array();$DamA1[]='kehu/del';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id='+getids());";echo "
	   },";echo "
	   cancelVal: '关闭',";echo "
	   cancel: true";echo "
   });";echo "
};";echo "
";echo "
";echo "
";echo "
";echo "
function share() {";echo "
	";echo "
   if (!getids()) {";echo "
	   layer.msg('未选中数据');";echo "
       return false;";echo "
   }";echo "
";echo "
	   art.dialog.open('";$DamA1=array();$DamA1[]='kehu/share';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id='+getids());";echo "
	   };";echo "
";echo "
";echo "
";echo "
";echo "
function zhuanyi_gh() {";echo "
	";echo "
   if (!getids()) {";echo "
	   layer.msg('未选中数据');";echo "
       return false;";echo "
   }";echo "
";echo "
   art.dialog({";echo "
	   content: '是否确定转移公海？',";echo "
	   icon: 'warning',";echo "
	   ok: function () {";echo "
	   art.dialog.open('";$DamA1=array();$DamA1[]='kehu/zhuanyi_gh';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id='+getids());";echo "
	   },";echo "
	   cancelVal: '关闭',";echo "
	   cancel: true";echo "
   });";echo "
};";echo "
";echo "
</script> ";echo "
<script>";echo "
\$(function() {";echo "
";echo "
    \$(document).on('click', \".fa-chevron-circle-right\",";echo "
    function(event) {";echo "
        \$(this).removeClass('fa-chevron-circle-right').addClass('fa-chevron-circle-down');";echo "
        \$thatTr = \$(this).parents('tr');";echo "
        \$nextTr = \$thatTr.siblings('tr');";echo "
        \$nextTr.addClass('table-hide').removeClass('table-show');";echo "
        /* 收缩更多 */";echo "
    }).on('click', \".fa-chevron-circle-down\",function(event) {";echo "
        \$(this).removeClass('fa-chevron-circle-down').addClass('fa-chevron-circle-right');";echo "
        \$thatTr = \$(this).parents('tr');";echo "
        \$nextTr = \$thatTr.siblings('tr');";echo "
        \$nextTr.removeClass('table-hide').addClass('table-show');";echo "
        /* 展开更多 */";echo "
    }).on('click', \".aids\",function(event) {";echo "
		if(\$(this).prop('checked')){";echo "
			\$(this).parents('tr').css('background-color','#FFFED9');";echo "
		}else{";echo "
			\$(this).parents('tr').css('background-color','');";echo "
		}";echo "
";echo "
        /* 单选 */";echo "
    }).on('click', \"#checkall\",function(event) {";echo "
		if(\$(this).is(':checked')==true){";echo "
			//全部添加选中并添加消背景";echo "
			\$(\".aids\").prop('checked', true).parents('tr').css('background-color','#FFFED9');";echo "
		}";echo "
		else{";echo "
			//全部取消选中并取消背景";echo "
			\$(\".aids\").prop('checked', false).parents('tr').css('background-color','');";echo "
		}";echo "
       ";echo "
        /* 多选 */";echo "
		";echo "
    }).on('click', '#zksqAll',function(event) {";echo "
		";echo "
		if(\$(this).find('span').text()=='全部展开'){";echo "
			\$(\".tree_table\").find('tr.table-hide').removeClass('table-hide').addClass('table-show');";echo "
			\$(\".fa-chevron-circle-down\").each(function(index, el) {";echo "
				\$(el).removeClass('fa-chevron-circle-down').addClass('fa-chevron-circle-right');	";echo "
			});";echo "
		    \$(this).find('span').text('全部收起')";echo "
			\$(this).find('i.fa').removeClass('fa-caret-down')";echo "
			\$(this).find('i.fa').addClass('fa-caret-right')";echo "
			";echo "
		}else if(\$(this).find('span').text()=='全部收起'){";echo "
			\$(\".tree_table\").find('tr.table-show').addClass('table-hide').removeClass('table-show');";echo "
			\$(\".fa-chevron-circle-right\").each(function(index, el) {";echo "
				\$(el).removeClass('fa-chevron-circle-right').addClass('fa-chevron-circle-down');";echo "
			});";echo "
		    \$(this).find('span').text('全部展开')";echo "
			\$(this).find('i.fa').removeClass('fa-caret-right')";echo "
			\$(this).find('i.fa').addClass('fa-caret-down')";echo "
			";echo "
		}";echo "
";echo "
        /* 全部展开和收起 */";echo "
		";echo "
    });";echo "
";echo "
";echo "
});";echo "
</script>";echo "
</body>";echo "
</html>";
?>