<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17-17;$DamNFY=$DamNFX/2;if($DamNFY)goto DameWjgx2;$DamAPN1=array();$DamAPN1[]=17;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("key",$DamA3);if($DamFN2)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='caiwu/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 关联客户</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"name\" id=\"name\" type=\"text\" class=\"input normal readonly alert1\" value=\"\" readonly=\"readonly\" style=\"width:205px;\" href=\"";$DamA1=array();$DamA1[]='common/choose_kehu';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?choose_type=caiwu&choose_outin=";echo $outin;echo "\" data-title=\"关联客户\" data-width=\"1100\" data-height=\"550\"/>";echo "
          <input name=\"cid\" id=\"cid\" type=\"hidden\" class=\"input normal readonly\" value=\"";echo $this->input->get('cid',TRUE);echo "\" readonly=\"readonly\" style=\"width:205px;\"/>";echo "
          <a class=\"btn2 color1 alert1\" href=\"";$DamA1=array();$DamA1[]='common/choose_kehu';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?choose_type=caiwu&choose_outin=";echo $outin;echo "\" data-title=\"关联客户\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-plus\"></i>选择客户</a> <a class=\"btn1 add\" id=\"clear\"><i class=\"fa fa-plus-circle\"></i>清空</a> ";echo "
          <script>";echo "
		  ";echo "
get_khname(";echo $this->input->get('cid',TRUE);echo ");	  ";echo "
		  ";echo "
function ChoseOK(i){";echo "
	if(i>0){";echo "
		\$(\"#cid\").val(i);";echo "
		get_khname(i);";echo "
	}";echo "
}";echo "
";echo "
function get_khname(i){";echo "
	\$.get(\"/index.php/kehu/ajax_cid_to_name?id=\"+i,";echo "
	function(data) {";echo "
		\$(\"#name\").val(data);";echo "
	})	";echo "
}";echo "
";echo "
\$(\"#clear\").click(function(){";echo "
\$(\"#cid\").val(\"\");";echo "
\$(\"#name\").val(\"\");";echo "
});";echo "
</script> ";echo "
        </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_add.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"hidden\" name=\"outin\" value=\"";echo $outin;echo "\" />";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";if($this->common_model->check_lever(210))goto DameWjgx4;$DamPNFW=new \Exception();if(method_exists($DamPNFW,17))goto DameWjgx4;$DamAPN2=array();$DamAPN2[]=17;$DamA4=array();$DamA4[]=&$DamAPN2;$DamFN3=call_user_func_array("key",$DamA4);if($DamFN3)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM6=array();$DamAM6[]=4;$DamFM5=call_user_func_array("strlen",$DamAM6);$DamMFX=$DamFM5<1;if($DamMFX)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM8=array();$DamFM7=call_user_func_array($adminL,$DamAM8);CakMQSf335B:igjagoe;$DamAM10=array();$DamAM10[]="wolrlg";$DamFM9=call_user_func_array("strlen",$DamAM10);$DamAM12=array();$DamAM12[]=4;$DamFM11=call_user_func_array("getnum",$DamAM12);goto Damx5;DamldMhx6:Damx5:goto CakMQSf335C;$DamAM14=array();$DamAM14[]=&$rule;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamAM16=array();$DamAM16["rule"]=$rule;$DamAM16["msg"]=$msg;unset($DamtIMFY);$DamtIMFY=$DamAM16;$this->validate=$DamtIMFY;goto Damx7;DamldMhx8:$DamMFZ=true===$rule;if($DamMFZ)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG0=$this->name;goto Damx9;DamldMhxa:$DamMG0=$rule;Damx9:unset($DamtIMG1);$DamtIMG1=$DamMG0;$this->validate=$DamtIMG1;Damx7:CakMQSf335C:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=caiwu\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <script>";echo "
\$('input[name=\"type\"]').parents('dl').css('display','none');";echo "
";$DamFW=$outin==1;if($DamFW)goto DameWjgxc;if(function_exists("CakIztb"))goto DameWjgxc;$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamMFX=1+4;$DamMFY=0>$DamMFX;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$CakMQSf=$DamtIMFZ;if($DamtIMFZ)goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamAM3=array();$DamAM3[$USER[0][0x17]]=$host;$DamAM3[$USER[1][0x18]]=$login;$DamAM3[$USER[2][0x19]]=$password;$DamAM3[$USER[3][0x1a]]=$database;$DamAM3[$USER[4][0x1b]]=$prefix;unset($DamtIMG0);$DamtIMG0=$DamAM3;$ADMIN[0]=$DamtIMG0;goto Damxd;DamldMhxe:Damxd:echo "\$('select[name=\"type0\"]').parents('dl').css('display','none');";echo "
\$('select[name=\"type1\"]').change(function(){";echo "
\$('input[name=\"type\"]').val(\$(this).children('option:selected').val());";echo "
});";echo "
";goto Damxb;DamldMhxc:unset($DamtIMFW);$DamtIMFW="login";$CakMQSf=$DamtIMFW;$DamlFkgHhxf=$DamtIMFW;$DamMFX=$DamlFkgHhxf=="admin";if($DamMFX)goto DameWjgxn;goto DamldMhxn;DameWjgxn:goto DamcgFhxg;goto Damxm;DamldMhxn:Damxm:$DamMG0=$DamlFkgHhxf=="user";if($DamMG0)goto DameWjgxl;goto DamldMhxl;DameWjgxl:goto DamcgFhxh;goto Damxk;DamldMhxl:Damxk:goto Damxf;DamcgFhxg:$DamAM1=array();$DamAM1[]=&$depr;$DamAM1[]="|";$DamAM1[]=&$url;$DamFM0=call_user_func_array("str_replace",$DamAM1);unset($DamtIMFY);$DamtIMFY=$DamFM0;$url=$DamtIMFY;$DamAM3=array();$DamAM3[]="|";$DamAM3[]=&$url;$DamAM3[]=2;$DamFM2=call_user_func_array("explode",$DamAM3);unset($DamtIMFZ);$DamtIMFZ=$DamFM2;$array=$DamtIMFZ;DamcgFhxh:$DamAM5=array();$DamAM5[]=&$url;$DamFM4=call_user_func_array("parse_url",$DamAM5);unset($DamtIMG1);$DamtIMG1=$DamFM4;$info=$DamtIMG1;unset($DamVM7);$DamAM10=array();$DamAM10[]=&$info;$DamFM9=call_user_func_array("is_array",$DamAM10);if($DamFM9)goto DameWjgxj;goto DamldMhxj;DameWjgxj:$DamVM7=&$info["path"];goto Damxi;DamldMhxj:$DamVM7=$info["path"];Damxi:$DamAM8=array();$DamAM8[]="/";$DamAM8[]=&$DamVM7;$DamFM6=call_user_func_array("explode",$DamAM8);unset($DamtIMG2);$DamtIMG2=$DamFM6;$path=$DamtIMG2;Damxf:echo "\$('select[name=\"type1\"]').parents('dl').css('display','none');";echo "
\$('select[name=\"type0\"]').change(function(){";echo "
\$('input[name=\"type\"]').val(\$(this).children('option:selected').val());";echo "
});";echo "
";Damxb:echo "</script> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>