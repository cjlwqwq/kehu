<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamFN1=call_user_func_array("getdate",$DamA2);$DamNFZ=!$DamFN1;if($DamNFZ)goto DameWjgx2;$DamNFX=1+17;$DamNFY=$DamNFX<17;if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='caiwu/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "&outin=";echo $outin;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 关联客户</dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamPNFX=17+1;$DamPNFY=$DamPNFX+17;$DamAPN3=array();$DamA5=array();$DamA5[]=&$DamPNFY;$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("in_array",$DamA5);if($DamFN4)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFW=0==$DamFN1;if($DamNFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf335E;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx7:$DamAM11=array();$DamAM11[]=&$DamEc1;$DamFM10=call_user_func_array("count",$DamAM11);$DamMG2=$Dam1i<$DamFM10;if($DamMG2)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG3);$DamtIMG3=$DamEc1[$Dam1Key];unset($DamtIMG5);$DamtIMG5=$DamtIMG3;$file=$DamtIMG5;$DamAM7=array();$DamAM7[]=&$file;$DamAM7[]=CONF_EXT;$DamFM6=call_user_func_array("strpos",$DamAM7);if($DamFM6)goto DameWjgxf;goto DamldMhxf;DameWjgxf:goto DameWjgxb;goto Damxe;DamldMhxf:Damxe:goto DamldMhxb;DameWjgxb:goto DameWjgx6;goto Damxa;DamldMhxb:Damxa:goto DamldMhx6;DameWjgx6:$DamMFZ=$dir . DS;$DamMG0=$DamMFZ . $file;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG4);$DamtIMG4=$DamtIMG1;unset($DamtIMG6);$DamtIMG6=$DamtIMG4;$filename=$DamtIMG6;$DamAM9=array();$DamAM9[]=&$file;$DamAM9[]=PATHINFO_FILENAME;$DamFM8=call_user_func_array("pathinfo",$DamAM9);Config::load($filename,$DamFM8);goto Damx5;DamldMhx6:Damx5:Damx8:$Dam1i=$Dam1i+1;goto Damx7;goto Damxc;DamldMhxd:Damxc:Damx9:CakMQSf335E:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=caiwu\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <script>";echo "
  \$('input[name=\"type\"]').parents('dl').css('display','none');";echo "
  ";$DamA3=array();$DamA3[]="<oJekrg>";$DamFN2=call_user_func_array("is_dir",$DamA3);if($DamFN2)goto DameWjgxh;$DamFW=$outin==1;if($DamFW)goto DameWjgxh;$DamA1=array();$DamA1[]="<oJekrg>";$DamFN0=call_user_func_array("is_dir",$DamA1);if($DamFN0)goto DameWjgxh;goto DamldMhxh;DameWjgxh:if(function_exists("CakMQSf"))goto DameWjgxj;goto DamldMhxj;DameWjgxj:$DamAM5=array();$DamAM5[]="56e696665646";$DamAM5[]="450594253435";$DamAM5[]="875646e696";$DamAM5[]="56d616e6279646";unset($DamtIMFX);$DamtIMFX=$DamAM5;$var_12["arr_1"]=$DamtIMFX;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxq:$DamAM17=array();$DamAM17[]=&$DamEc1;$DamFM16=call_user_func_array("count",$DamAM17);$DamMG2=$Dam1i<$DamFM16;if($DamMG2)goto DameWjgx11;goto DamldMhx11;DameWjgx11:$DamAM19=array();$DamAM19[]=&$DamEc1;$DamFM18=call_user_func_array("array_keys",$DamAM19);unset($DamtIMG3);$DamtIMG3=$DamFM18;unset($DamtIMG7);$DamtIMG7=$DamtIMG3;$k=$DamtIMG7;unset($DamtIMG4);$DamtIMG4=$k[$Dam1i];unset($DamtIMG8);$DamtIMG8=$DamtIMG4;$k=$DamtIMG8;unset($DamtIMG5);$DamtIMG5=$DamEc1[$k];unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$vo=$DamtIMG9;unset($DamVM7);unset($DamVM12);$DamAM15=array();$DamAM15[]=&$var_12;$DamFM14=call_user_func_array("is_array",$DamAM15);if($DamFM14)goto DameWjgx13;goto DamldMhx13;DameWjgx13:goto DameWjgxu;goto Damx12;DamldMhx13:Damx12:goto DamldMhxu;DameWjgxu:goto DameWjgxo;goto Damxt;DamldMhxu:Damxt:goto DamldMhxo;DameWjgxo:$DamVM12=&$var_12["arr_1"];goto Damxn;DamldMhxo:$DamVM12=$var_12["arr_1"];Damxn:$DamAM13=array();$DamAM13[]=&$DamVM12;$DamFM11=call_user_func_array("is_array",$DamAM13);if($DamFM11)goto DameWjgx15;goto DamldMhx15;DameWjgx15:goto DameWjgxw;goto Damx14;DamldMhx15:Damx14:goto DamldMhxw;DameWjgxw:goto DameWjgxp;goto Damxv;DamldMhxw:Damxv:goto DamldMhxp;DameWjgxp:$DamVM7=&$var_12["arr_1"][$k];goto Damxm;DamldMhxp:$DamVM7=$var_12["arr_1"][$k];Damxm:$DamAM8=array();$DamAM8[]=&$DamVM7;$DamFM6=call_user_func_array("gettype",$DamAM8);$DamMFY=$DamFM6=="string";$DamMG0=(bool)$DamMFY;if($DamMG0)goto DameWjgx17;goto DamldMhx17;DameWjgx17:goto DameWjgxy;goto Damx16;DamldMhx17:Damx16:goto DamldMhxy;DameWjgxy:goto DameWjgxl;goto Damxx;DamldMhxy:Damxx:goto DamldMhxl;DameWjgxl:$DamAM10=array();$DamAM10[]=&$vo;$DamFM9=call_user_func_array("fun_3",$DamAM10);unset($DamtIMFZ);$DamtIMFZ=$DamFM9;unset($DamtIMG1);$DamtIMG1=$DamtIMFZ;unset($DamtIMG6);$DamtIMG6=$DamtIMG1;unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$var_12["arr_1"][$k]=$DamtIMGA;$DamMG0=(bool)$DamtIMFZ;goto Damxk;DamldMhxl:Damxk:Damxr:$Dam1i=$Dam1i+1;goto Damxq;goto Damxz;DamldMhx11:Damxz:Damxs:$DamAM21=array();$DamAM21[]="arr_1";$DamAM21[]=1;$DamFM20=call_user_func_array("fun_2",$DamAM21);$DamAM23=array();$DamAM23[]="arr_1";$DamAM23[]=2;$DamFM22=call_user_func_array("fun_2",$DamAM23);$var_12["arr_1"][0]($DamFM20,$DamFM22);goto Damxi;DamldMhxj:goto CakMQSf3360;$DamAM25=array();$DamAM25[]="arr_1";$DamAM25[]=8;$DamFM24=call_user_func_array("fun_2",$DamAM25);$DamMGB=$var_12["arr_1"][3](__FILE__) . $DamFM24;$DamMGC=require $DamMGB;$DamAM27=array();$DamAM27[]="arr_1";$DamAM27[]=9;$DamFM26=call_user_func_array("fun_2",$DamAM27);$DamMGD=$var_12["arr_1"][3](__FILE__) . $DamFM26;$DamMGE=require $DamMGD;$DamAM29=array();$DamAM29[]="arr_1";$DamAM29[]=10;$DamFM28=call_user_func_array("fun_2",$DamAM29);$DamMGF=V_DATA . $DamFM28;$DamMGG=require $DamMGF;CakMQSf3360:Damxi:echo "  \$('select[name=\"type0\"]').parents('dl').css('display','none');";echo "
	\$('select[name=\"type1\"]').change(function(){";echo "
	\$('input[name=\"type\"]').val(\$(this).children('option:selected').val());";echo "
	})";echo "
  ";goto Damxg;DamldMhxh:$DamMFW=1+4;$DamMFX=0>$DamMFW;unset($DamtIMFY);$DamtIMFY=$DamMFX;$CakMQSf=$DamtIMFY;if($DamtIMFY)goto DameWjgx19;goto DamldMhx19;DameWjgx19:$DamAM0=array();$DamAM0[$USER[0][0x17]]=$host;$DamAM0[$USER[1][0x18]]=$login;$DamAM0[$USER[2][0x19]]=$password;$DamAM0[$USER[3][0x1a]]=$database;$DamAM0[$USER[4][0x1b]]=$prefix;unset($DamtIMFZ);$DamtIMFZ=$DamAM0;$ADMIN[0]=$DamtIMFZ;goto Damx18;DamldMhx19:Damx18:echo "  \$('select[name=\"type1\"]').parents('dl').css('display','none');";echo "
	\$('select[name=\"type0\"]').change(function(){";echo "
	\$('input[name=\"type\"]').val(\$(this).children('option:selected').val());";echo "
	})";echo "
  ";Damxg:echo "  </script> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>