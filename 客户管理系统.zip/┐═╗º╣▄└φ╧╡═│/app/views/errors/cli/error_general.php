<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamA3=array();$DamA3[]="<lyePVW>";$DamFN2=call_user_func_array("is_file",$DamA3);if($DamFN2)goto DameWjgx2;$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;$DamNFY=17=="";unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx2;goto DamldMhx2;DameWjgx2:goto CakMQSf342B;$DamMG0=$R4vP4 . DS;unset($DamtIMG1);$DamtIMG1=$DamMG0;$R4vP5=$DamtIMG1;$DamAM4=array();unset($DamtIMG2);$DamtIMG2=$DamAM4;$R4vA5=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=$request;$R4vA5[]=$DamtIMG3;$DamAM6=array();$DamAM6[]=&$R4vA5;$DamAM6[]=&$R4vA4;$DamFM5=call_user_func_array("call_user_func_array",$DamAM6);unset($DamtIMG4);$DamtIMG4=$DamFM5;$R4vC3=$DamtIMG4;CakMQSf342B:goto CakMQSf342D;$DamAM7=array();unset($DamtIMG5);$DamtIMG5=$DamAM7;$R4vA1=$DamtIMG5;unset($DamtIMG6);$DamtIMG6=&$dispatch;$R4vA1[]=&$DamtIMG6;$DamAM8=array();unset($DamtIMG7);$DamtIMG7=$DamAM8;$R4vA2=$DamtIMG7;$DamAM10=array();$DamAM10[]=&$R4vA2;$DamAM10[]=&$R4vA1;$DamFM9=call_user_func_array("call_user_func_array",$DamAM10);unset($DamtIMG8);$DamtIMG8=$DamFM9;$R4vC0=$DamtIMG8;CakMQSf342D:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:$DamFW="
ERROR: " . $heading;$DamFX=$DamFW . "

";$DamFY=$DamFX . $message;$DamFZ=$DamFY . "

";echo $DamFZ;
?>