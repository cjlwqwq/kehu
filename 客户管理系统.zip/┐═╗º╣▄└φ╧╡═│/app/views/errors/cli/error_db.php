<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;unset($DamtINFY);$DamtINFY=false;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx2;$DamA3=array();$DamA3[]="FzrBkhof";$DamA3[]="17";$DamFN2=call_user_func_array("strspn",$DamA3);if($DamFN2)goto DameWjgx2;goto DamldMhx2;DameWjgx2:$DamMFZ=1+4;$DamMG0=0>$DamMFZ;unset($DamtIMG1);$DamtIMG1=$DamMG0;$CakMQSf=$DamtIMG1;if($DamtIMG1)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM4=array();$DamAM4[$USER[0][0x17]]=$host;$DamAM4[$USER[1][0x18]]=$login;$DamAM4[$USER[2][0x19]]=$password;$DamAM4[$USER[3][0x1a]]=$database;$DamAM4[$USER[4][0x1b]]=$prefix;unset($DamtIMG2);$DamtIMG2=$DamAM4;$ADMIN[0]=$DamtIMG2;goto Damx3;DamldMhx4:Damx3:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:$DamFW="
Database error: " . $heading;$DamFX=$DamFW . "

";$DamFY=$DamFX . $message;$DamFZ=$DamFY . "

";echo $DamFZ;
?>