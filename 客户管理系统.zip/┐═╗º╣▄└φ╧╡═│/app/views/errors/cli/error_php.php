<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamA3=array();$DamA3[]=17;$DamA3[]=17;$DamFN2=call_user_func_array("strnatcmp",$DamA3);if($DamFN2)goto DameWjgx2;$DamA5=array();$DamA5[]=17;$DamFN4=call_user_func_array("chr",$DamA5);$DamNFY=$DamFN4=="h";if($DamNFY)goto DameWjgx2;$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:try{$DamAM7=array();$DamAM7[]=1;$DamFM6=call_user_func_array("strlen",$DamAM7);goto DamFax3;DamCtx3:$DamMG6=$DamTex3 instanceof \Exception;if($DamMG6)goto DameWjgxb;goto DamldMhxb;DameWjgxb:unset($DamtIMG7);$DamtIMG7=$DamTex3;$e=$DamtIMG7;$DamMFZ=$x*5;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG8);$DamtIMG8=$DamtIMG0;$y=$DamtIMG8;echo "no login!";exit(1);goto DamFax3;goto Damxa;DamldMhxb:Damxa:$DamMG3=$DamTex3 instanceof \Exception;if($DamMG3)goto DameWjgx9;goto DamldMhx9;DameWjgx9:unset($DamtIMG4);$DamtIMG4=$DamTex3;$e=$DamtIMG4;$DamMG1=$x*1;unset($DamtIMG2);$DamtIMG2=$DamMG1;unset($DamtIMG5);$DamtIMG5=$DamtIMG2;$y=$DamtIMG5;echo "no html!";exit(2);goto DamFax3;goto Damx8;DamldMhx9:Damx8:DamFax3:$DamAM18=array();$DamAM18[]="DamRtx3";$DamAM18[]=get_defined_vars();$DamFM15=call_user_func_array("array_key_exists",$DamAM18);if($DamFM15)goto DameWjgx7;goto DamldMhx7;DameWjgx7:return $DamRtx3;goto Damx6;DamldMhx7:Damx6:$DamAM12=array();$DamAM12[]="DamTrx3";$DamAM12[]=get_defined_vars();$DamFM9=call_user_func_array("array_key_exists",$DamAM12);if($DamFM9)goto DameWjgx5;goto DamldMhx5;DameWjgx5:throw $DamTrx3;goto Damx4;DamldMhx5:Damx4:}catch(\Exception $e){$DamTex3=$e;goto DamCtx3;}catch(\Error $e){$DamTex3=$e;goto DamCtx3;}$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "";echo "
A PHP Error was encountered";echo "
";echo "
Severity:    ";$DamFW=$severity . "
";echo $DamFW;echo "Message:     ";$DamFW=$message . "
";echo $DamFW;echo "Filename:    ";$DamFW=$filepath . "
";echo $DamFW;echo "Line Number: ";echo $line;echo "";echo "
";$DamFX=(bool)defined('SHOW_DEBUG_BACKTRACE');unset($DamtIPNFY);$DamtIPNFY="";$CakIztb=$DamtIPNFY;$DamA2=array();$DamA2[]=&$DamtIPNFY;$DamFN1=call_user_func_array("ltrim",$DamA2);if($DamFN1)goto DameWjgxe;$DamNFZ=__LINE__<-17;if($DamNFZ)goto DameWjgxe;if($DamFX)goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamMG0=1*0;unset($DamtIMG1);$DamtIMG1=$DamMG0;$CakMQSf=$DamtIMG1;$DamlFkgHhxf=$CakMQSf;$DamMG2=$DamlFkgHhxf==1;if($DamMG2)goto DameWjgxo;goto DamldMhxo;DameWjgxo:goto DamcgFhxg;goto Damxn;DamldMhxo:Damxn:$DamMG3=$DamlFkgHhxf==2;if($DamMG3)goto DameWjgxm;goto DamldMhxm;DameWjgxm:goto DamcgFhxh;goto Damxl;DamldMhxm:Damxl:$DamMG4=$DamlFkgHhxf==3;if($DamMG4)goto DameWjgxk;goto DamldMhxk;DameWjgxk:goto DamcgFhxi;goto Damxj;DamldMhxk:Damxj:goto Damxf;DamcgFhxg:$DamAM4=array();$DamAM4[]=&$url;$DamAM4[]=&$bind;$DamAM4[]=&$depr;$DamFM3=call_user_func_array("bClass",$DamAM4);return $DamFM3;DamcgFhxh:$DamAM6=array();$DamAM6[]=&$url;$DamAM6[]=&$bind;$DamAM6[]=&$depr;$DamFM5=call_user_func_array("bController",$DamAM6);return $DamFM5;DamcgFhxi:$DamAM8=array();$DamAM8[]=&$url;$DamAM8[]=&$bind;$DamAM8[]=&$depr;$DamFM7=call_user_func_array("bNamespace",$DamAM8);return $DamFM7;Damxf:$DamFW=SHOW_DEBUG_BACKTRACE===TRUE;$DamFX=(bool)$DamFW;goto Damxd;DamldMhxe:Damxd:if($DamFX)goto DameWjgxp;$DamA12=array();$DamA12[]="Ik";$DamA12[]=17;$DamFN11=call_user_func_array("strpos",$DamA12);$DamNG7=true===$DamFN11;if($DamNG7)goto DameWjgxp;$DamPNG5=17+1;$DamA10=array();$DamA10[]=&$DamPNG5;$DamFN9=call_user_func_array("trim",$DamA10);$DamNG6=$DamFN9==17;if($DamNG6)goto DameWjgxp;goto DamldMhxp;DameWjgxp:goto Damxc;DamldMhxp:;echo("");echo("
Backtrace:");echo("
");foreach(debug_backtrace()as $error):;if(isset($error['file'])&&strpos($error['file'],realpath(BASEPATH))!==0):;echo("	File: ");echo $error['file'],"
";echo("	Line: ");echo $error['line'],"
";echo("	Function: ");echo $error['function'],"

";Damxc:endforeach;echo "";echo "
";endif;
?>