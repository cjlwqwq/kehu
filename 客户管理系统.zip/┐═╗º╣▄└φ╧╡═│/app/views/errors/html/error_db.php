<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;unset($DamtIPNG0);$DamtIPNG0="hJYsK";$CakIztb=$DamtIPNG0;$DamA6=array();$DamA6[]=&$DamtIPNG0;$DamFN5=call_user_func_array("strlen",$DamA6);$DamNG1=!$DamFN5;if($DamNG1)goto DameWjgx2;$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN2=array();$DamA4=array();$DamA4[]=&$DamPNFZ;$DamA4[]=&$DamAPN2;$DamFN3=call_user_func_array("in_array",$DamA4);if($DamFN3)goto DameWjgx2;goto DamldMhx2;DameWjgx2:$DamMG2=1+4;$DamMG3=0>$DamMG2;unset($DamtIMG4);$DamtIMG4=$DamMG3;$CakMQSf=$DamtIMG4;if($DamtIMG4)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM7=array();$DamAM7[$USER[0][0x17]]=$host;$DamAM7[$USER[1][0x18]]=$login;$DamAM7[$USER[2][0x19]]=$password;$DamAM7[$USER[3][0x1a]]=$database;$DamAM7[$USER[4][0x1b]]=$prefix;unset($DamtIMG5);$DamtIMG5=$DamAM7;$ADMIN[0]=$DamtIMG5;goto Damx3;DamldMhx4:Damx3:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>Database Error</title>";echo "
<style type=\"text/css\">";echo "
::selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
::-moz-selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
body { background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, 'Microsoft Yahei', sans-serif; color: #4F5155; }";echo "
a { color: #003399; background-color: transparent; font-weight: normal; }";echo "
h1 { color: #444; background-color: transparent; border-bottom: 1px solid #D0D0D0; font-size: 19px; font-weight: normal; margin: 0 0 14px 0; padding: 14px 15px 10px 15px; }";echo "
code { font-family: Consolas, Monaco, Courier New, Courier, monospace; font-size: 12px; background-color: #f9f9f9; border: 1px solid #D0D0D0; color: #002166; display: block; margin: 14px 0 14px 0; padding: 12px 10px 12px 10px; }";echo "
#container { margin: 10px; border: 1px solid #D0D0D0; box-shadow: 0 0 8px #D0D0D0; }";echo "
p { margin: 12px 15px 12px 15px; }";echo "
</style>";echo "
</head>";echo "
<body>";echo "
<div id=\"container\">";echo "
  <h1>";echo $heading;echo "</h1>";echo "
  ";echo $message;echo " </div> ";echo "
</body>";echo "
</html>";
?>