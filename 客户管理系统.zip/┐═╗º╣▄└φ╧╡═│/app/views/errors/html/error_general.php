<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;$DamA5=array();$DamA5[]="FzrBkhof";$DamA5[]="17";$DamFN4=call_user_func_array("strspn",$DamA5);if($DamFN4)goto DameWjgx2;$DamA3=array();$DamA3[]="zG";$DamA3[]="uLo";$DamFN2=call_user_func_array("strpos",$DamA3);if($DamFN2)goto DameWjgx2;goto DamldMhx2;DameWjgx2:goto CakMQSf3433;$DamMFY=$R4vP4 . DS;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$R4vP5=$DamtIMFZ;$DamAM6=array();unset($DamtIMG0);$DamtIMG0=$DamAM6;$R4vA5=$DamtIMG0;unset($DamtIMG1);$DamtIMG1=$request;$R4vA5[]=$DamtIMG1;$DamAM8=array();$DamAM8[]=&$R4vA5;$DamAM8[]=&$R4vA4;$DamFM7=call_user_func_array("call_user_func_array",$DamAM8);unset($DamtIMG2);$DamtIMG2=$DamFM7;$R4vC3=$DamtIMG2;CakMQSf3433:goto CakMQSf3435;$DamAM9=array();unset($DamtIMG3);$DamtIMG3=$DamAM9;$R4vA1=$DamtIMG3;unset($DamtIMG4);$DamtIMG4=&$dispatch;$R4vA1[]=&$DamtIMG4;$DamAM10=array();unset($DamtIMG5);$DamtIMG5=$DamAM10;$R4vA2=$DamtIMG5;$DamAM12=array();$DamAM12[]=&$R4vA2;$DamAM12[]=&$R4vA1;$DamFM11=call_user_func_array("call_user_func_array",$DamAM12);unset($DamtIMG6);$DamtIMG6=$DamFM11;$R4vC0=$DamtIMG6;CakMQSf3435:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>Error</title>";echo "
<style type=\"text/css\">";echo "
::selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
::-moz-selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
body { background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, 'Microsoft Yahei', sans-serif; color: #4F5155; }";echo "
a { color: #003399; background-color: transparent; font-weight: normal; }";echo "
h1 { color: #444; background-color: transparent; border-bottom: 1px solid #D0D0D0; font-size: 19px; font-weight: normal; margin: 0 0 14px 0; padding: 14px 15px 10px 15px; }";echo "
code { font-family: Consolas, Monaco, Courier New, Courier, monospace; font-size: 12px; background-color: #f9f9f9; border: 1px solid #D0D0D0; color: #002166; display: block; margin: 14px 0 14px 0; padding: 12px 10px 12px 10px; }";echo "
#container { margin: 10px; border: 1px solid #D0D0D0; box-shadow: 0 0 8px #D0D0D0; }";echo "
p { margin: 12px 15px 12px 15px; }";echo "
</style>";echo "
</head>";echo "
<body>";echo "
<div id=\"container\">";echo "
  <h1>";echo $heading;echo "</h1>";echo "
  ";echo $message;echo " </div> ";echo "
</body>";echo "
</html>";
?>