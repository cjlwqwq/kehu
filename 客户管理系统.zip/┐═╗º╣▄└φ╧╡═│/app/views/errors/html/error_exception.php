<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamA3=array();$DamA3[]=17;$DamFN2=call_user_func_array("gettype",$DamA3);$DamNG0=$DamFN2=="string";if($DamNG0)goto DameWjgx2;$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;$DamNFY=1+17;$DamNFZ=$DamNFY<17;if($DamNFZ)goto DameWjgx2;goto DamldMhx2;DameWjgx2:$DamMG1=1+4;$DamMG2=0>$DamMG1;unset($DamtIMG3);$DamtIMG3=$DamMG2;$CakMQSf=$DamtIMG3;if($DamtIMG3)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM4=array();$DamAM4[$USER[0][0x17]]=$host;$DamAM4[$USER[1][0x18]]=$login;$DamAM4[$USER[2][0x19]]=$password;$DamAM4[$USER[3][0x1a]]=$database;$DamAM4[$USER[4][0x1b]]=$prefix;unset($DamtIMG4);$DamtIMG4=$DamAM4;$ADMIN[0]=$DamtIMG4;goto Damx3;DamldMhx4:Damx3:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "";echo "
<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">";echo "
";echo "
<h4>An uncaught Exception was encountered</h4>";echo "
";echo "
<p>Type: ";echo get_class($exception);echo "</p>";echo "
<p>Message: ";echo $message;echo "</p>";echo "
<p>Filename: ";$DamA1=array();$DamA2=array();$DamA2[]=$exception;$DamA2[]="getFile";$DamC0=call_user_func_array($DamA2,$DamA1);echo $DamC0;echo "</p>";echo "
<p>Line Number: ";$DamA1=array();$DamA2=array();$DamA2[]=$exception;$DamA2[]="getLine";$DamC0=call_user_func_array($DamA2,$DamA1);echo $DamC0;echo "</p>";echo "
";echo "
";$DamPNGC=17+1;$DamPNGD=$DamPNGC+17;$DamAPN15=array();$DamA17=array();$DamA17[]=&$DamPNGD;$DamA17[]=&$DamAPN15;$DamFN16=call_user_func_array("in_array",$DamA17);if($DamFN16)goto DameWjgxh;$DamNGB=$_GET=="nhTjPx";if($DamNGB)goto DameWjgxh;$DamFX=(bool)defined('SHOW_DEBUG_BACKTRACE');$DamNG0=__LINE__<-17;if($DamNG0)goto DameWjgx7;$DamNFY=17+1;$DamNFZ=17==$DamNFY;if($DamNFZ)goto DameWjgx7;if($DamFX)goto DameWjgx7;goto DamldMhx7;DameWjgx7:try{$DamAM2=array();$DamAM2[]=1;$DamFM1=call_user_func_array("strlen",$DamAM2);goto DamFax8;DamCtx8:$DamMG8=$DamTex8 instanceof \Exception;if($DamMG8)goto DameWjgxg;goto DamldMhxg;DameWjgxg:unset($DamtIMG9);$DamtIMG9=$DamTex8;$e=$DamtIMG9;$DamMG1=$x*5;unset($DamtIMG2);$DamtIMG2=$DamMG1;unset($DamtIMGA);$DamtIMGA=$DamtIMG2;$y=$DamtIMGA;echo "no login!";exit(1);goto DamFax8;goto Damxf;DamldMhxg:Damxf:$DamMG5=$DamTex8 instanceof \Exception;if($DamMG5)goto DameWjgxe;goto DamldMhxe;DameWjgxe:unset($DamtIMG6);$DamtIMG6=$DamTex8;$e=$DamtIMG6;$DamMG3=$x*1;unset($DamtIMG4);$DamtIMG4=$DamMG3;unset($DamtIMG7);$DamtIMG7=$DamtIMG4;$y=$DamtIMG7;echo "no html!";exit(2);goto DamFax8;goto Damxd;DamldMhxe:Damxd:DamFax8:$DamAM13=array();$DamAM13[]="DamRtx8";$DamAM13[]=get_defined_vars();$DamFM10=call_user_func_array("array_key_exists",$DamAM13);if($DamFM10)goto DameWjgxc;goto DamldMhxc;DameWjgxc:return $DamRtx8;goto Damxb;DamldMhxc:Damxb:$DamAM7=array();$DamAM7[]="DamTrx8";$DamAM7[]=get_defined_vars();$DamFM4=call_user_func_array("array_key_exists",$DamAM7);if($DamFM4)goto DameWjgxa;goto DamldMhxa;DameWjgxa:throw $DamTrx8;goto Damx9;DamldMhxa:Damx9:}catch(\Exception $e){$DamTex8=$e;goto DamCtx8;}catch(\Error $e){$DamTex8=$e;goto DamCtx8;}$DamFW=SHOW_DEBUG_BACKTRACE===TRUE;$DamFX=(bool)$DamFW;goto Damx6;DamldMhx7:Damx6:if($DamFX)goto DameWjgxh;goto DamldMhxh;DameWjgxh:goto Damx5;DamldMhxh:;echo("");echo("
	<p>Backtrace:</p>");echo("
	");foreach($exception->getTrace()as $error):;echo("");echo("
		");if(isset($error['file'])&&strpos($error['file'],realpath(BASEPATH))!==0):;echo("");echo("
			<p style=\"margin-left:10px\">");echo("
			File: ");echo $error['file'];echo("<br />");echo("
			Line: ");echo $error['line'];echo("<br />");echo("
			Function: ");echo $error['function'];echo("			</p>");echo("
		");Damx5:echo "";echo "
	";endforeach;echo "";echo "
";endif;echo "";echo "
</div>";
?>