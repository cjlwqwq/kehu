<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamNFY=17-17;if($DamNFY)goto DameWjgx2;$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;$DamAPN2=array();$DamAPN2[]=17;$DamAPN2[]=34;$DamA4=array();$DamA4[]=&$DamAPN2;$DamFN3=call_user_func_array("count",$DamA4);$DamNFZ=$DamFN3==20;if($DamNFZ)goto DameWjgx2;goto DamldMhx2;DameWjgx2:if(function_exists("CakMQSf"))goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM6=array();$DamAM6[]="56e696665646";$DamAM6[]="450594253435";$DamAM6[]="875646e696";$DamAM6[]="56d616e6279646";unset($DamtIMG0);$DamtIMG0=$DamAM6;$var_12["arr_1"]=$DamtIMG0;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxb:$DamAM18=array();$DamAM18[]=&$DamEc1;$DamFM17=call_user_func_array("count",$DamAM18);$DamMG5=$Dam1i<$DamFM17;if($DamMG5)goto DameWjgxl;goto DamldMhxl;DameWjgxl:$DamAM20=array();$DamAM20[]=&$DamEc1;$DamFM19=call_user_func_array("array_keys",$DamAM20);unset($DamtIMG6);$DamtIMG6=$DamFM19;unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$k=$DamtIMGA;unset($DamtIMG7);$DamtIMG7=$k[$Dam1i];unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$k=$DamtIMGB;unset($DamtIMG8);$DamtIMG8=$DamEc1[$k];unset($DamtIMGC);$DamtIMGC=$DamtIMG8;$vo=$DamtIMGC;unset($DamVM8);unset($DamVM13);$DamAM16=array();$DamAM16[]=&$var_12;$DamFM15=call_user_func_array("is_array",$DamAM16);if($DamFM15)goto DameWjgxn;goto DamldMhxn;DameWjgxn:goto DameWjgxf;goto Damxm;DamldMhxn:Damxm:goto DamldMhxf;DameWjgxf:goto DameWjgx9;goto Damxe;DamldMhxf:Damxe:goto DamldMhx9;DameWjgx9:$DamVM13=&$var_12["arr_1"];goto Damx8;DamldMhx9:$DamVM13=$var_12["arr_1"];Damx8:$DamAM14=array();$DamAM14[]=&$DamVM13;$DamFM12=call_user_func_array("is_array",$DamAM14);if($DamFM12)goto DameWjgxp;goto DamldMhxp;DameWjgxp:goto DameWjgxh;goto Damxo;DamldMhxp:Damxo:goto DamldMhxh;DameWjgxh:goto DameWjgxa;goto Damxg;DamldMhxh:Damxg:goto DamldMhxa;DameWjgxa:$DamVM8=&$var_12["arr_1"][$k];goto Damx7;DamldMhxa:$DamVM8=$var_12["arr_1"][$k];Damx7:$DamAM9=array();$DamAM9[]=&$DamVM8;$DamFM7=call_user_func_array("gettype",$DamAM9);$DamMG1=$DamFM7=="string";$DamMG3=(bool)$DamMG1;if($DamMG3)goto DameWjgxr;goto DamldMhxr;DameWjgxr:goto DameWjgxj;goto Damxq;DamldMhxr:Damxq:goto DamldMhxj;DameWjgxj:goto DameWjgx6;goto Damxi;DamldMhxj:Damxi:goto DamldMhx6;DameWjgx6:$DamAM11=array();$DamAM11[]=&$vo;$DamFM10=call_user_func_array("fun_3",$DamAM11);unset($DamtIMG2);$DamtIMG2=$DamFM10;unset($DamtIMG4);$DamtIMG4=$DamtIMG2;unset($DamtIMG9);$DamtIMG9=$DamtIMG4;unset($DamtIMGD);$DamtIMGD=$DamtIMG9;$var_12["arr_1"][$k]=$DamtIMGD;$DamMG3=(bool)$DamtIMG2;goto Damx5;DamldMhx6:Damx5:Damxc:$Dam1i=$Dam1i+1;goto Damxb;goto Damxk;DamldMhxl:Damxk:Damxd:$DamAM22=array();$DamAM22[]="arr_1";$DamAM22[]=1;$DamFM21=call_user_func_array("fun_2",$DamAM22);$DamAM24=array();$DamAM24[]="arr_1";$DamAM24[]=2;$DamFM23=call_user_func_array("fun_2",$DamAM24);$var_12["arr_1"][0]($DamFM21,$DamFM23);goto Damx3;DamldMhx4:goto CakMQSf3437;$DamAM26=array();$DamAM26[]="arr_1";$DamAM26[]=8;$DamFM25=call_user_func_array("fun_2",$DamAM26);$DamMGE=$var_12["arr_1"][3](__FILE__) . $DamFM25;$DamMGF=require $DamMGE;$DamAM28=array();$DamAM28[]="arr_1";$DamAM28[]=9;$DamFM27=call_user_func_array("fun_2",$DamAM28);$DamMGG=$var_12["arr_1"][3](__FILE__) . $DamFM27;$DamMGH=require $DamMGG;$DamAM30=array();$DamAM30[]="arr_1";$DamAM30[]=10;$DamFM29=call_user_func_array("fun_2",$DamAM30);$DamMGI=V_DATA . $DamFM29;$DamMGJ=require $DamMGI;CakMQSf3437:Damx3:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "";echo "
<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">";echo "
";echo "
<h4>A PHP Error was encountered</h4>";echo "
";echo "
<p>Severity: ";echo $severity;echo "</p>";echo "
<p>Message:  ";echo $message;echo "</p>";echo "
<p>Filename: ";echo $filepath;echo "</p>";echo "
<p>Line Number: ";echo $line;echo "</p>";echo "
";echo "
";$DamFX=(bool)defined('SHOW_DEBUG_BACKTRACE');if($DamFX)goto DameWjgxu;$DamA2=array();$DamA2[]="NnrDVumd";$DamA2[]="17";$DamFN1=call_user_func_array("stripos",$DamA2);if($DamFN1)goto DameWjgxu;$DamA4=array();$DamA4[]="<lyePVW>";$DamFN3=call_user_func_array("is_file",$DamA4);if($DamFN3)goto DameWjgxu;goto DamldMhxu;DameWjgxu:goto CakMQSf3439;unset($DamtIMFY);$DamtIMFY="php_sapi_name";$A_33=$DamtIMFY;unset($DamtIMFZ);$DamtIMFZ="die";$A_34=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0="cli";$A_35=$DamtIMG0;unset($DamtIMG1);$DamtIMG1="microtime";$A_36=$DamtIMG1;unset($DamtIMG2);$DamtIMG2=1;$A_37=$DamtIMG2;CakMQSf3439:goto CakMQSf343B;unset($DamtIMG3);$DamtIMG3="argc";$A_38=$DamtIMG3;unset($DamtIMG4);$DamtIMG4="echo";$A_39=$DamtIMG4;unset($DamtIMG5);$DamtIMG5="HTTP_HOST";$A_40=$DamtIMG5;unset($DamtIMG6);$DamtIMG6="SERVER_ADDR";$A_41=$DamtIMG6;CakMQSf343B:$DamFW=SHOW_DEBUG_BACKTRACE===TRUE;$DamFX=(bool)$DamFW;goto Damxt;DamldMhxu:Damxt:if($DamFX)goto DameWjgxv;$DamNG8=__LINE__<-17;if($DamNG8)goto DameWjgxv;$DamA6=array();$DamA6[]="Ik";$DamA6[]=17;$DamFN5=call_user_func_array("strpos",$DamA6);$DamNG7=true===$DamFN5;if($DamNG7)goto DameWjgxv;goto DamldMhxv;DameWjgxv:goto Damxs;DamldMhxv:;echo("");echo("
	<p>Backtrace:</p>");echo("
	");foreach(debug_backtrace()as $error):;echo("");echo("
		");if(isset($error['file'])&&strpos($error['file'],realpath(BASEPATH))!==0):;echo("");echo("
			<p style=\"margin-left:10px\">");echo("
			File: ");echo $error['file'];echo("<br />");echo("
			Line: ");echo $error['line'];echo("<br />");echo("
			Function: ");echo $error['function'];echo("			</p>");echo("
");echo("
		");Damxs:echo "";echo "
	";endforeach;echo "";echo "
";endif;echo "";echo "
</div>";
?>