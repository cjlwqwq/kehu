<?php
/*
�Ͻ������롢������κ���ʽ����Ȩ��Ϊ��Υ�߽�׷����������
����֧�� www.bgk100.com  qq15225660
*/

$DamFW=(bool)defined('BASEPATH');$DamPNFY=17+2;$DamA5=array();$DamA5[]=&$DamPNFY;$DamFN4=call_user_func_array("is_string",$DamA5);if($DamFN4)goto DameWjgx2;$DamFX=!$DamFW;if($DamFX)goto DameWjgx2;$DamA3=array();$DamA3[]="FzrBkhof";$DamA3[]="17";$DamFN2=call_user_func_array("strspn",$DamA3);if($DamFN2)goto DameWjgx2;goto DamldMhx2;DameWjgx2:goto CakMQSf342F;unset($DamtIMFZ);$DamtIMFZ="php_sapi_name";$A_33=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0="die";$A_34=$DamtIMG0;unset($DamtIMG1);$DamtIMG1="cli";$A_35=$DamtIMG1;unset($DamtIMG2);$DamtIMG2="microtime";$A_36=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=1;$A_37=$DamtIMG3;CakMQSf342F:goto CakMQSf3431;unset($DamtIMG4);$DamtIMG4="argc";$A_38=$DamtIMG4;unset($DamtIMG5);$DamtIMG5="echo";$A_39=$DamtIMG5;unset($DamtIMG6);$DamtIMG6="HTTP_HOST";$A_40=$DamtIMG6;unset($DamtIMG7);$DamtIMG7="SERVER_ADDR";$A_41=$DamtIMG7;CakMQSf3431:$DamFW=(bool)exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>404 Page Not Found</title>";echo "
<style type=\"text/css\">";echo "
::selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
::-moz-selection {";echo "
background-color: #E13300;";echo "
color: white;";echo "
}";echo "
body { background-color: #fff; margin: 40px; font: 13px/20px normal Helvetica, 'Microsoft Yahei', sans-serif; color: #4F5155; }";echo "
a { color: #003399; background-color: transparent; font-weight: normal; }";echo "
h1 { color: #444; background-color: transparent; border-bottom: 1px solid #D0D0D0; font-size: 19px; font-weight: normal; margin: 0 0 14px 0; padding: 14px 15px 10px 15px; }";echo "
code { font-family: Consolas, Monaco, Courier New, Courier, monospace; font-size: 12px; background-color: #f9f9f9; border: 1px solid #D0D0D0; color: #002166; display: block; margin: 14px 0 14px 0; padding: 12px 10px 12px 10px; }";echo "
#container { margin: 10px; border: 1px solid #D0D0D0; box-shadow: 0 0 8px #D0D0D0; }";echo "
p { margin: 12px 15px 12px 15px; }";echo "
</style>";echo "
</head>";echo "
<body>";echo "
<div id=\"container\">";echo "
  <h1>";echo $heading;echo "</h1>";echo "
  ";echo $message;echo " </div> ";echo "
</body>";echo "
</html>";
?>