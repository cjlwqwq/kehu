<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamAPN1=array();$DamAPN1[]=17;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("key",$DamA3);if($DamFN2)goto DameWjgx2;$DamA5=array();$DamA5[]="hBVdO";$DamA5[]=26;$DamFN4=call_user_func_array("substr",$DamA5);if($DamFN4)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>授权激活</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<script src=\"/themes/editor/xheditor-1.2.2.min.js\"></script>";echo "
<script src=\"/themes/editor/xheditor_lang/zh-cn.js\"></script>";echo "
</head>";echo "
";echo "
<body style=\"background:#ddd;\">";echo "
<div class=\"mian-page-div\" style=\" position:absolute; left:50%; top:50%;width:600px; height:400px; margin-left:-300px; margin-top:-220px; border:1px solid #ddd;-moz-border-radius:5px; -webkit-border-radius:5px; border-radius:5px; background:#fff;\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='sq';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <!--内容-->";echo "
    <div class=\"tab-content\">";echo "
      <h1 style=\"text-align:center; font-weight:bold; height:40px; line-height:40px; font-size:16px; margin-top:50px; margin-bottom:20px;\">系统激活</h1>";echo "
      ";$DamA1=array();$DamA1[]="zvqNyUUl";$DamA1[]=1;$DamFN0=call_user_func_array("str_repeat",$DamA1);$DamNFX=$DamFN0==1;if($DamNFX)goto DameWjgx4;$DamA3=array();$DamA3[]="NnrDVumd";$DamA3[]="17";$DamFN2=call_user_func_array("stripos",$DamA3);if($DamFN2)goto DameWjgx4;$DamFW=$hosts=='local';if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf388F;$DamAM6=array();$DamAM6[]=&$rules;$DamFM5=call_user_func_array("is_array",$DamAM6);if($DamFM5)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf388F:goto Damx5;DamldMhx6:goto CakMQSf3891;$DamMFY=$path . EXT;$DamAM8=array();$DamAM8[]=&$DamMFY;$DamFM7=call_user_func_array("is_file",$DamAM8);if($DamFM7)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMFZ=$path . EXT;$DamMG0=include $DamMFZ;goto Damx9;DamldMhxa:Damx9:CakMQSf3891:Damx5:echo "      <dl>";echo "
        <dt>识别码 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $config_dom;echo " </dd>";echo "
      </dl>";echo "
      ";goto Damx3;DamldMhx4:if(isset($_GET))goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamAM1=array();goto CakMQSf3893;$DamMFW=CONF_PATH . $module;$DamMFX=$DamMFW . database;$DamMFY=$DamMFX . CONF_EXT;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$filename=$DamtIMFZ;CakMQSf3893:goto Damxb;DamldMhxc:$DamAM3=array();$DamAM3[]=&$file;$DamAM3[]=".";$DamFM2=call_user_func_array("strpos",$DamAM3);if($DamFM2)goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamMG0=$file;goto Damxd;DamldMhxe:$DamMG1=APP_PATH . $file;$DamMG2=$DamMG1 . EXT;$DamMG0=$DamMG2;Damxd:unset($DamtIMG3);$DamtIMG3=$DamMG0;$file=$DamtIMG3;$DamMG5=(bool)is_file($file);if($DamMG5)goto DameWjgxh;goto DamldMhxh;DameWjgxh:$DamMG4=!isset(user::$file[$file]);$DamMG5=(bool)$DamMG4;goto Damxg;DamldMhxh:Damxg:if($DamMG5)goto DameWjgxi;goto DamldMhxi;DameWjgxi:$DamMG6=include $file;unset($DamtIMG7);$DamtIMG7=true;user::$file[$file]=$DamtIMG7;goto Damxf;DamldMhxi:Damxf:Damxb:echo "      <dl>";echo "
        <dt>域 名 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $config_dom;echo " </dd>";echo "
      </dl>";echo "
      ";Damx3:echo "      <dl>";echo "
        <dt>授权码 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"config_sqm\" class=\"input int-max\" datatype=\"*\" style=\"height:110px;\">";echo $config_sqm;echo "</textarea>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    ";echo "
    <div style=\"padding-top:30px; text-align:center;\">";echo "
      <input type=\"submit\" value=\"立即激活\" class=\"btn submit\" />";echo "
    </div>";echo "
    ";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>