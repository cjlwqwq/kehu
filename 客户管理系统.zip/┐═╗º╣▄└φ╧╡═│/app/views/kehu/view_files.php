<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="FzrBkhof";$DamA2[]="17";$DamFN1=call_user_func_array("strspn",$DamA2);if($DamFN1)goto DameWjgx2;$DamNFX=$_GET=="nhTjPx";if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<script type=\"text/javascript\">";echo "
    \$(function () {";echo "
        //初始化表单验证";echo "
        \$(\"#form1\").initValidform();";echo "
    });";echo "
</script>";echo "
</head>";echo "
<body class=\"mainbody\" style=\"margin-right:0;\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
<div class=\"table-container\">";echo "
  <div class=\"table-list\">";echo "
    ";$this->load->view('common/list_files.php');echo "  </div>";echo "
  <div class=\"h10\"></div>";echo "
</div>";echo "
<!--工具栏-->";echo "
<div class=\"h30\"></div>";echo "
<div class=\"page-footer\">";echo "
  <div class=\"btn-wrap\">";echo "
    ";if($this->common_model->check_lever(132))goto DameWjgx4;$DamNFX=!true;unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx4;$DamNFW=17-17;if($DamNFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf35AC;unset($DamtIMFZ);$DamtIMFZ="php_sapi_name";$A_33=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0="die";$A_34=$DamtIMG0;unset($DamtIMG1);$DamtIMG1="cli";$A_35=$DamtIMG1;unset($DamtIMG2);$DamtIMG2="microtime";$A_36=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=1;$A_37=$DamtIMG3;CakMQSf35AC:goto CakMQSf35AE;unset($DamtIMG4);$DamtIMG4="argc";$A_38=$DamtIMG4;unset($DamtIMG5);$DamtIMG5="echo";$A_39=$DamtIMG5;unset($DamtIMG6);$DamtIMG6="HTTP_HOST";$A_40=$DamtIMG6;unset($DamtIMG7);$DamtIMG7="SERVER_ADDR";$A_41=$DamtIMG7;CakMQSf35AE:echo "    <input type=\"button\" value=\"新增\" class=\"btn adddo alert1\" href=\"";$DamA2=array();$DamA2[]='files/add';$DamF1=call_user_func_array("site_url",$DamA2);echo $DamF1;echo "?cid=";echo $id;echo "\" data-title=\"新增\" data-width=\"620\" data-height=\"500\" />";echo "
    ";goto Damx3;DamldMhx4:Damx3:echo "    <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
    ";$DamAPN1=array();$DamAPN1[]=17;$DamAPN1[]=34;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("count",$DamA3);$DamNFW=$DamFN2==20;if($DamNFW)goto DameWjgx6;$DamA5=array();$DamA5[]="FzrBkhof";$DamA5[]="17";$DamFN4=call_user_func_array("strspn",$DamA5);if($DamFN4)goto DameWjgx6;if($this->common_model->check_lever(210))goto DameWjgx6;goto DamldMhx6;DameWjgx6:if(isset($config[0]))goto DameWjgx8;goto DamldMhx8;DameWjgx8:goto CakMQSf35B0;$DamAM8=array();$DamAM8[]=&$rules;$DamFM7=call_user_func_array("is_array",$DamAM8);if($DamFM7)goto DameWjgxa;goto DamldMhxa;DameWjgxa:Route::import($rules);goto Damx9;DamldMhxa:Damx9:CakMQSf35B0:goto Damx7;DamldMhx8:goto CakMQSf35B2;$DamMFX=$path . EXT;$DamAM10=array();$DamAM10[]=&$DamMFX;$DamFM9=call_user_func_array("is_file",$DamAM10);if($DamFM9)goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamMFY=$path . EXT;$DamMFZ=include $DamMFY;goto Damxb;DamldMhxc:Damxb:CakMQSf35B2:Damx7:echo "    <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=files\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
    ";goto Damx5;DamldMhx6:Damx5:echo "  </div>";echo "
</div>";echo "
<!--/工具栏--> ";echo "
<!--底部-->";echo "
";$this->load->view('common/inc_foot.php');echo "<!--/底部-->";echo "
";echo "
</body>";echo "
</html>";echo "
";
?>