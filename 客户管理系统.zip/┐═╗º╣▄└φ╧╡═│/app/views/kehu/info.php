<?php if(!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>查看</title>
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<?php $this->load->view('common/inc_styles.php');?>
<script type="text/javascript">
    $(function () {
		
        //初始化表单验证
        $("#form1").initValidform();
		
		$("#kehuframe").css("height",($(window).height()-158)+"px")
    });
</script>
<style>
.tab-content dl, .div-content dl {
	padding:2px 0;
}
</style>
</head>
<body>
<div class="view-page"> 
  
  <!--导航栏-->
  <?php $this->load->view('common/inc_head.php');?>
  <!--/导航栏-->
  
  <div class="tab-content">
    <?php 
if (count($ziduan_suoyou)>0) {
foreach($ziduan_suoyou as $arr=>$v) {
	$get_value = ${$v['name']};
?>
    <dl>
      <dt><?php echo $v["title"]?></dt>
      <dd class="int_check"> <?php echo $get_value?> </dd>
    </dl>
    <?php 		
}}
?>
  </div>
  
  <!--工具栏-->
  <div class="h30"></div>
  <div class="page-footer">
    <div class="btn-wrap">
      <?php if ($this->common_model->check_lever(3)){?>
      <input type="button" value="编辑" class="btn editdo alert1" href="<?php echo site_url('kehu/edit')?>?id=<?php echo $id?>" data-title="编辑" data-width="620" data-height="550" />
      <?php }?>
      <input type="button" value="关闭" class="btn close" onclick="art.dialog.close();parent.layclose();" />
    </div>
  </div>
  <!--/工具栏--> 
  <!--底部-->
  <?php $this->load->view('common/inc_foot.php');?>
  <!--/底部--> 
  
</div>
</body>
</html>