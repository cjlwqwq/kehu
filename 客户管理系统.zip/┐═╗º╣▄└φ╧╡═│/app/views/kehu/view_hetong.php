<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamAPN1=array();$DamAPN1[]=17;$DamAPN1[]=34;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("count",$DamA3);$DamNFY=$DamFN2==20;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamNFX=$_GET=="nhTjPx";if($DamNFX)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body>";echo "
<div class=\"view-page\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      ";$this->load->view('common/list_hetong.php');echo "    </div>";echo "
    <div class=\"h10\"></div>";echo "
  </div>";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      ";if($this->common_model->check_lever(42))goto DameWjgx4;$DamA2=array();$DamA2[]="<oJekrg>";$DamFN1=call_user_func_array("is_dir",$DamA2);if($DamFN1)goto DameWjgx4;unset($DamtIPNFW);$DamtIPNFW="hJYsK";$CakIztb=$DamtIPNFW;$DamA4=array();$DamA4[]=&$DamtIPNFW;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFX=!$DamFN3;if($DamNFX)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamMFY=1+4;$DamMFZ=0>$DamMFY;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;if($DamtIMG0)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM5=array();$DamAM5[$USER[0][0x17]]=$host;$DamAM5[$USER[1][0x18]]=$login;$DamAM5[$USER[2][0x19]]=$password;$DamAM5[$USER[3][0x1a]]=$database;$DamAM5[$USER[4][0x1b]]=$prefix;unset($DamtIMG1);$DamtIMG1=$DamAM5;$ADMIN[0]=$DamtIMG1;goto Damx5;DamldMhx6:Damx5:echo "      <input type=\"button\" value=\"新增\" class=\"btn adddo alert1\" href=\"";$DamA1=array();$DamA1[]='hetong/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $id;echo "\" data-title=\"新增\" data-width=\"620\" data-height=\"500\" />";echo "
      ";goto Damx3;DamldMhx4:Damx3:echo "      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      ";$DamA4=array();$DamA4[]=17;$DamA4[]="sL";$DamFN3=call_user_func_array("strrchr",$DamA4);if($DamFN3)goto DameWjgx8;if($this->common_model->check_lever(210))goto DameWjgx8;$DamPNFW=17+2;$DamA2=array();$DamA2[]=&$DamPNFW;$DamFN1=call_user_func_array("is_string",$DamA2);if($DamFN1)goto DameWjgx8;goto DamldMhx8;DameWjgx8:if(isset($_GET))goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamAM6=array();goto CakMQSf3656;$DamMFX=CONF_PATH . $module;$DamMFY=$DamMFX . database;$DamMFZ=$DamMFY . CONF_EXT;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$filename=$DamtIMG0;CakMQSf3656:goto Damx9;DamldMhxa:$DamAM8=array();$DamAM8[]=&$file;$DamAM8[]=".";$DamFM7=call_user_func_array("strpos",$DamAM8);if($DamFM7)goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamMG1=$file;goto Damxb;DamldMhxc:$DamMG2=APP_PATH . $file;$DamMG3=$DamMG2 . EXT;$DamMG1=$DamMG3;Damxb:unset($DamtIMG4);$DamtIMG4=$DamMG1;$file=$DamtIMG4;$DamMG6=(bool)is_file($file);if($DamMG6)goto DameWjgxf;goto DamldMhxf;DameWjgxf:$DamMG5=!isset(user::$file[$file]);$DamMG6=(bool)$DamMG5;goto Damxe;DamldMhxf:Damxe:if($DamMG6)goto DameWjgxg;goto DamldMhxg;DameWjgxg:$DamMG7=include $file;unset($DamtIMG8);$DamtIMG8=true;user::$file[$file]=$DamtIMG8;goto Damxd;DamldMhxg:Damxd:Damx9:echo "      <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=hetong\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
      ";goto Damx7;DamldMhx8:Damx7:echo "    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>