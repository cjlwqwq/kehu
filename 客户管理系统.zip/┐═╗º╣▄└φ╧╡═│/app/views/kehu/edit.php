<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;if(isset($_CakIztb))goto DameWjgx2;$DamPNFX=new \Exception();if(method_exists($DamPNFX,17))goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>数据操作</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<link rel=\"stylesheet\" href=\"/themes/default/css/city-picker.css\"/>";echo "
<script src=\"/themes/default/js/city-picker.data.js\"></script>";echo "
<script src=\"/themes/default/js/city-picker.js\"></script>";echo "
</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Add\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='kehu/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?stype=";echo $stype;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
        ";if($this->common_model->check_lever(210))goto DameWjgx4;$DamPNFW="SxJ"==__LINE__;unset($DamtIPNFX);$DamtIPNFX=$DamPNFW;$CakIztb=$DamtIPNFX;$DamA5=array();$DamA5[]=&$DamtIPNFX;$DamFN4=call_user_func_array("strrev",$DamA5);if($DamFN4)goto DameWjgx4;$DamAPN1=array();$DamAPN1[]=17;$DamA3=array();$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("key",$DamA3);if($DamFN2)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamMFY=1+4;$DamMFZ=0>$DamMFY;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;if($DamtIMG0)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM6=array();$DamAM6[$USER[0][0x17]]=$host;$DamAM6[$USER[1][0x18]]=$login;$DamAM6[$USER[2][0x19]]=$password;$DamAM6[$USER[3][0x1a]]=$database;$DamAM6[$USER[4][0x1b]]=$prefix;unset($DamtIMG1);$DamtIMG1=$DamAM6;$ADMIN[0]=$DamtIMG1;goto Damx5;DamldMhx6:Damx5:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=kehu\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
  <script>              ";echo "
\$(function(){";echo "
/*  var \$citypicker1 = \$('#city-picker1');";echo "
    \$citypicker1.citypicker();";echo "
    var \$citypicker2 = \$('#city-picker2');";echo "
    \$citypicker2.citypicker({";echo "
        province: '江苏省',";echo "
        city: '常州市',";echo "
        district: '溧阳市'";echo "
    });";echo "
var \$citypicker3 = \$('#city-picker3');*/";echo "
});";echo "
</script> ";echo "
";echo "
<script src=\"/themes/layui/layui.js\"></script> ";echo "
<script>";echo "
layui.use('upload', function(){";echo "
  var upload = layui.upload;";echo "
";echo "
";echo "
";$DamNFX=__LINE__<-17;if($DamNFX)goto DameWjgx8;$DamA3=array();$DamA3[]=17;$DamFN2=call_user_func_array("strlen",$DamA3);$DamNFY=0==$DamFN2;if($DamNFY)goto DameWjgx8;$DamA1=array();$DamA1[]=&$ziduan_biaodan;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx8;goto DamldMhx8;DameWjgx8:try{$DamAM5=array();$DamAM5[]=1;$DamFM4=call_user_func_array("strlen",$DamAM5);goto DamFax9;DamCtx9:$DamMG6=$DamTex9 instanceof \Exception;if($DamMG6)goto DameWjgxh;goto DamldMhxh;DameWjgxh:unset($DamtIMG7);$DamtIMG7=$DamTex9;$e=$DamtIMG7;$DamMFZ=$x*5;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG8);$DamtIMG8=$DamtIMG0;$y=$DamtIMG8;echo "no login!";exit(1);goto DamFax9;goto Damxg;DamldMhxh:Damxg:$DamMG3=$DamTex9 instanceof \Exception;if($DamMG3)goto DameWjgxf;goto DamldMhxf;DameWjgxf:unset($DamtIMG4);$DamtIMG4=$DamTex9;$e=$DamtIMG4;$DamMG1=$x*1;unset($DamtIMG2);$DamtIMG2=$DamMG1;unset($DamtIMG5);$DamtIMG5=$DamtIMG2;$y=$DamtIMG5;echo "no html!";exit(2);goto DamFax9;goto Damxe;DamldMhxf:Damxe:DamFax9:$DamAM16=array();$DamAM16[]="DamRtx9";$DamAM16[]=get_defined_vars();$DamFM13=call_user_func_array("array_key_exists",$DamAM16);if($DamFM13)goto DameWjgxd;goto DamldMhxd;DameWjgxd:return $DamRtx9;goto Damxc;DamldMhxd:Damxc:$DamAM10=array();$DamAM10[]="DamTrx9";$DamAM10[]=get_defined_vars();$DamFM7=call_user_func_array("array_key_exists",$DamAM10);if($DamFM7)goto DameWjgxb;goto DamldMhxb;DameWjgxb:throw $DamTrx9;goto Damxa;DamldMhxb:Damxa:}catch(\Exception $e){$DamTex9=$e;goto DamCtx9;}catch(\Error $e){$DamTex9=$e;goto DamCtx9;}unset($DamEc1);$DamEc1=array();foreach($ziduan_biaodan as $arr=>$v){$DamEc1[$arr]=$v;};$Dam1i=0;Damx18:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamA1=array();$DamA1[]="FzrBkhof";$DamA1[]="17";$DamFN0=call_user_func_array("strspn",$DamA1);if($DamFN0)goto DameWjgx1u;if($DamFW)goto DameWjgx1u;$DamNFW=!true;unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx1u;goto DamldMhx1u;DameWjgx1u:goto CakMQSf3537;unset($DamEc2);$DamEc2=array();foreach($files as $file){$DamEc2[]=$file;};$Dam2i=0;Damx1x:$DamAM7=array();$DamAM7[]=&$DamEc2;$DamFM6=call_user_func_array("count",$DamAM7);$DamMG1=$Dam2i<$DamFM6;if($DamMG1)goto DameWjgx24;goto DamldMhx24;DameWjgx24:$Dam2Key=array_keys($DamEc2);$Dam2Key=$Dam2Key[$Dam2i];unset($DamtIMG2);$DamtIMG2=$DamEc2[$Dam2Key];unset($DamtIMG4);$DamtIMG4=$DamtIMG2;$file=$DamtIMG4;$DamAM3=array();$DamAM3[]=&$file;$DamAM3[]=CONF_EXT;$DamFM2=call_user_func_array("strpos",$DamAM3);if($DamFM2)goto DameWjgx26;goto DamldMhx26;DameWjgx26:goto DameWjgx22;goto Damx25;DamldMhx26:Damx25:goto DamldMhx22;DameWjgx22:goto DameWjgx1w;goto Damx21;DamldMhx22:Damx21:goto DamldMhx1w;DameWjgx1w:$DamMFY=$dir . DS;$DamMFZ=$DamMFY . $file;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG3);$DamtIMG3=$DamtIMG0;unset($DamtIMG5);$DamtIMG5=$DamtIMG3;$filename=$DamtIMG5;$DamAM5=array();$DamAM5[]=&$file;$DamAM5[]=PATHINFO_FILENAME;$DamFM4=call_user_func_array("pathinfo",$DamAM5);Config::load($filename,$DamFM4);goto Damx1v;DamldMhx1w:Damx1v:Damx1y:$Dam2i=$Dam2i+1;goto Damx1x;goto Damx23;DamldMhx24:Damx23:Damx2z:CakMQSf3537:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$v=$DamtIFW;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFX=$DamFN0=="string";if($DamNFX)goto DameWjgxj;$DamFW=$v['type']=='upload';$DamPNFW=17+1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_array",$DamA1);if($DamFN0)goto DameWjgx28;$DamNFX=true===17;if($DamNFX)goto DameWjgx28;if($DamFW)goto DameWjgx28;goto DamldMhx28;DameWjgx28:goto DameWjgx1c;goto Damx27;DamldMhx28:Damx27:$DamA1=array();$DamA1[]=17;$DamA1[]="sL";$DamFN0=call_user_func_array("strrchr",$DamA1);if($DamFN0)goto DameWjgx1c;$DamPNFW="SxJ"==__LINE__;unset($DamtIPNFX);$DamtIPNFX=$DamPNFW;unset($DamtIFW);$DamtIFW=$DamtIPNFX;$CakIztb=$DamtIFW;$DamA3=array();$DamA3[]=&$DamtIPNFX;$DamFN2=call_user_func_array("strrev",$DamA3);if($DamFN2)goto DameWjgx1c;goto DamldMhx1c;DameWjgx1c:goto DameWjgxj;goto Damx1b;DamldMhx1c:Damx1b:$DamPNFY=17+2;$DamA3=array();$DamA3[]=&$DamPNFY;$DamFN2=call_user_func_array("is_string",$DamA3);if($DamFN2)goto DameWjgxj;goto DamldMhxj;DameWjgxj:unset($DamtIMFZ);$DamtIMFZ="login";unset($DamtIFW);$DamtIFW=$DamtIMFZ;$CakMQSf=$DamtIFW;$DamlFkgHhxk=$DamtIMFZ;$DamMG0=$DamlFkgHhxk=="admin";$DamPNFX=17-1;$DamA3=array();$DamA3[]=&$DamPNFX;$DamFN2=call_user_func_array("is_null",$DamA3);if($DamFN2)goto DameWjgx2a;if($DamMG0)goto DameWjgx2a;$DamA1=array();$DamA1[]=E_PARSE;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="HGxIk";if($DamNFW)goto DameWjgx2a;goto DamldMhx2a;DameWjgx2a:goto DameWjgx1e;goto Damx29;DamldMhx2a:Damx29:$DamA1=array();$DamA1[]=E_PARSE;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="HGxIk";if($DamNFW)goto DameWjgx1e;$DamA3=array();$DamA3[]="Ik";$DamA3[]=17;$DamFN2=call_user_func_array("strpos",$DamA3);$DamNFX=true===$DamFN2;if($DamNFX)goto DameWjgx1e;goto DamldMhx1e;DameWjgx1e:goto DameWjgxs;goto Damx1d;DamldMhx1e:Damx1d:goto DamldMhxs;DameWjgxs:goto DamcgFhxl;goto Damxr;DamldMhxs:Damxr:$DamMG3=$DamlFkgHhxk=="user";$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx1g;$DamAPN0=array();$DamA2=array();$DamA2[]=17;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("array_key_exists",$DamA2);if($DamFN1)goto DameWjgx1g;$DamA1=array();$DamA1[]="PSCefS";$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFW=$DamFN0==0;if($DamNFW)goto DameWjgx2c;if($DamMG3)goto DameWjgx2c;$DamNFX=true===17;if($DamNFX)goto DameWjgx2c;goto DamldMhx2c;DameWjgx2c:goto DameWjgx1g;goto Damx2b;DamldMhx2c:Damx2b:goto DamldMhx1g;DameWjgx1g:goto DameWjgxq;goto Damx1f;DamldMhx1g:Damx1f:goto DamldMhxq;DameWjgxq:goto DamcgFhxm;goto Damxp;DamldMhxq:Damxp:goto Damxk;DamcgFhxl:$DamAM5=array();$DamAM5[]=&$depr;$DamAM5[]="|";$DamAM5[]=&$url;$DamFM4=call_user_func_array("str_replace",$DamAM5);unset($DamtIMG1);$DamtIMG1=$DamFM4;unset($DamtIFW);$DamtIFW=$DamtIMG1;$url=$DamtIFW;$DamAM7=array();$DamAM7[]="|";$DamAM7[]=&$url;$DamAM7[]=2;$DamFM6=call_user_func_array("explode",$DamAM7);unset($DamtIMG2);$DamtIMG2=$DamFM6;unset($DamtIFW);$DamtIFW=$DamtIMG2;$array=$DamtIFW;DamcgFhxm:$DamAM9=array();$DamAM9[]=&$url;$DamFM8=call_user_func_array("parse_url",$DamAM9);unset($DamtIMG4);$DamtIMG4=$DamFM8;unset($DamtIFW);$DamtIFW=$DamtIMG4;$info=$DamtIFW;unset($DamVM11);$DamAM14=array();$DamAM14[]=&$info;$DamFM13=call_user_func_array("is_array",$DamAM14);$DamAPN0=array();$DamA2=array();$DamA2[]=17;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("array_key_exists",$DamA2);if($DamFN1)goto DameWjgx2e;if($DamFM13)goto DameWjgx2e;$DamNFW=1+17;$DamNFX=$DamNFW<17;if($DamNFX)goto DameWjgx2e;goto DamldMhx2e;DameWjgx2e:goto DameWjgx1i;goto Damx2d;DamldMhx2e:Damx2d:$DamA1=array();$DamA1[]="Ik";$DamA1[]=17;$DamFN0=call_user_func_array("strpos",$DamA1);$DamNFY=true===$DamFN0;if($DamNFY)goto DameWjgx1i;$DamNFW=17+1;$DamNFX=E_STRICT==$DamNFW;if($DamNFX)goto DameWjgx1i;goto DamldMhx1i;DameWjgx1i:goto DameWjgxo;goto Damx1h;DamldMhx1i:Damx1h:goto DamldMhxo;DameWjgxo:$DamVM11=&$info["path"];goto Damxn;DamldMhxo:$DamVM11=$info["path"];Damxn:$DamAM12=array();$DamAM12[]="/";$DamAM12[]=&$DamVM11;$DamFM10=call_user_func_array("explode",$DamAM12);unset($DamtIMG5);$DamtIMG5=$DamFM10;unset($DamtIFW);$DamtIFW=$DamtIMG5;$path=$DamtIFW;Damxk:echo "  //执行实例";echo "
  var uploadInst = upload.render({";echo "
    elem: '#";echo $v['name'];echo "'";echo "
    ,url: '/index.php/upload/ajax_upload'";echo "
	,exts: '";echo UPLOADTYPE;echo "'";echo "
    ,size: ";$DamFW=!empty($v["maxlimit"]);$DamAPN0=array();$DamA2=array();$DamA2[]=17;$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("array_key_exists",$DamA2);if($DamFN1)goto DameWjgx2g;if($DamFW)goto DameWjgx2g;$DamNFW=true===17;if($DamNFW)goto DameWjgx2g;goto DamldMhx2g;DameWjgx2g:goto DameWjgx1k;goto Damx2f;DamldMhx2g:Damx2f:$DamA3=array();$DamA3[]=17;$DamFN2=call_user_func_array("md5",$DamA3);$DamNFW=$DamFN2=="wOCcEI";if($DamNFW)goto DameWjgx1k;$DamA1=array();$DamA1[]=null;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgx1k;goto DamldMhx1k;DameWjgx1k:goto DameWjgxu;goto Damx1j;DamldMhx1k:Damx1j:$DamNFY=17+1;$DamNFZ=E_STRICT==$DamNFY;if($DamNFZ)goto DameWjgxu;unset($DamtIPNG0);$DamtIPNG0=true;unset($DamtIFW);$DamtIFW=$DamtIPNG0;$CakIztb=$DamtIFW;$DamA2=array();$DamA2[]=&$DamtIPNG0;$DamFN1=call_user_func_array("is_object",$DamA2);if($DamFN1)goto DameWjgxu;goto DamldMhxu;DameWjgxu:$DamMG1=1+4;$DamMG2=0>$DamMG1;unset($DamtIMG3);$DamtIMG3=$DamMG2;unset($DamtIFW);$DamtIFW=$DamtIMG3;$CakMQSf=$DamtIFW;$DamNFX=!true;unset($DamtINFY);$DamtINFY=$DamNFX;unset($DamtIFW);$DamtIFW=$DamtINFY;$CakIztb=$DamtIFW;if($DamtINFY)goto DameWjgx1m;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFW=$DamFN0=="string";if($DamNFW)goto DameWjgx1m;$DamA1=array();$DamA1[]=__FILE__;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx2i;$DamNFW="__file__"==5;if($DamNFW)goto DameWjgx2i;if($DamtIMG3)goto DameWjgx2i;goto DamldMhx2i;DameWjgx2i:goto DameWjgx1m;goto Damx2h;DamldMhx2i:Damx2h:goto DamldMhx1m;DameWjgx1m:goto DameWjgxw;goto Damx1l;DamldMhx1m:Damx1l:goto DamldMhxw;DameWjgxw:$DamAM3=array();$DamAM3[$USER[0][0x17]]=$host;$DamAM3[$USER[1][0x18]]=$login;$DamAM3[$USER[2][0x19]]=$password;$DamAM3[$USER[3][0x1a]]=$database;$DamAM3[$USER[4][0x1b]]=$prefix;unset($DamtIMG4);$DamtIMG4=$DamAM3;unset($DamtIFW);$DamtIFW=$DamtIMG4;$ADMIN[0]=$DamtIFW;goto Damxv;DamldMhxw:Damxv:$DamFX=$v["maxlimit"];goto Damxt;DamldMhxu:$DamMG5=1*0;unset($DamtIMG6);$DamtIMG6=$DamMG5;unset($DamtIFW);$DamtIFW=$DamtIMG6;$CakMQSf=$DamtIFW;$DamlFkgHhxx=$CakMQSf;$DamMG7=$DamlFkgHhxx==1;$DamA1=array();$DamA1[]="NnrDVumd";$DamA1[]="17";$DamFN0=call_user_func_array("stripos",$DamA1);if($DamFN0)goto DameWjgx2k;if($DamMG7)goto DameWjgx2k;$DamA3=array();$DamA3[]="<lyePVW>";$DamFN2=call_user_func_array("is_file",$DamA3);if($DamFN2)goto DameWjgx2k;goto DamldMhx2k;DameWjgx2k:goto DameWjgx1o;goto Damx2j;DamldMhx2k:Damx2j:$DamA3=array();$DamA3[]=null;$DamFN2=call_user_func_array("is_object",$DamA3);if($DamFN2)goto DameWjgx1o;$DamA1=array();$DamFN0=call_user_func_array("getdate",$DamA1);$DamNFW=!$DamFN0;if($DamNFW)goto DameWjgx1o;goto DamldMhx1o;DameWjgx1o:goto DameWjgx17;goto Damx1n;DamldMhx1o:Damx1n:goto DamldMhx17;DameWjgx17:goto DamcgFhxy;goto Damx16;DamldMhx17:Damx16:$DamMG8=$DamlFkgHhxx==2;unset($DamtINFY);$DamtINFY=false;unset($DamtIFW);$DamtIFW=$DamtINFY;$CakIztb=$DamtIFW;if($DamtINFY)goto DameWjgx1q;$DamPNFW="SxJ"==__LINE__;unset($DamtIPNFX);$DamtIPNFX=$DamPNFW;unset($DamtIFW);$DamtIFW=$DamtIPNFX;$CakIztb=$DamtIFW;$DamA1=array();$DamA1[]=&$DamtIPNFX;$DamFN0=call_user_func_array("strrev",$DamA1);if($DamFN0)goto DameWjgx1q;$DamPNFW=17-1;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgx2m;if($DamMG8)goto DameWjgx2m;$DamA3=array();$DamA3[]="Ik";$DamA3[]=17;$DamFN2=call_user_func_array("strpos",$DamA3);$DamNFX=true===$DamFN2;if($DamNFX)goto DameWjgx2m;goto DamldMhx2m;DameWjgx2m:goto DameWjgx1q;goto Damx2l;DamldMhx2m:Damx2l:goto DamldMhx1q;DameWjgx1q:goto DameWjgx15;goto Damx1p;DamldMhx1q:Damx1p:goto DamldMhx15;DameWjgx15:goto DamcgFhxz;goto Damx14;DamldMhx15:Damx14:$DamMG9=$DamlFkgHhxx==3;$DamNFW=E_ERROR-1;unset($DamtINFX);$DamtINFX=$DamNFW;unset($DamtIFW);$DamtIFW=$DamtINFX;$CakIztb=$DamtIFW;if($DamtINFX)goto DameWjgx1s;$DamA1=array();$DamA1[]=E_PARSE;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFY=$DamFN0=="HGxIk";if($DamNFY)goto DameWjgx1s;$DamAPN0=array();$DamAPN0[]=17;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("key",$DamA2);if($DamFN1)goto DameWjgx2o;$DamAPN3=array();$DamAPN3[]=17;$DamAPN3[]=34;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("count",$DamA5);$DamNFW=$DamFN4==20;if($DamNFW)goto DameWjgx2o;if($DamMG9)goto DameWjgx2o;goto DamldMhx2o;DameWjgx2o:goto DameWjgx1s;goto Damx2n;DamldMhx2o:Damx2n:goto DamldMhx1s;DameWjgx1s:goto DameWjgx13;goto Damx1r;DamldMhx1s:Damx1r:goto DamldMhx13;DameWjgx13:goto DamcgFhx11;goto Damx12;DamldMhx13:Damx12:goto Damxx;DamcgFhxy:$DamAM5=array();$DamAM5[]=&$url;$DamAM5[]=&$bind;$DamAM5[]=&$depr;$DamFM4=call_user_func_array("bClass",$DamAM5);return $DamFM4;DamcgFhxz:$DamAM7=array();$DamAM7[]=&$url;$DamAM7[]=&$bind;$DamAM7[]=&$depr;$DamFM6=call_user_func_array("bController",$DamAM7);return $DamFM6;DamcgFhx11:$DamAM9=array();$DamAM9[]=&$url;$DamAM9[]=&$bind;$DamAM9[]=&$depr;$DamFM8=call_user_func_array("bNamespace",$DamAM9);return $DamFM8;Damxx:$DamFX='10';Damxt:echo $DamFX;echo "*1024 //限制文件大小，单位 KB";echo "
    ,done: function(res){";echo "
      //上传完毕回调";echo "
	  if(res.code==200){";echo "
		//layer.msg('上传成功');";echo "
		\$('#";echo $v['name'];echo "_data').val(res.data.url);";echo "
		\$('#";echo $v['name'];echo "_view').text(res.data.url);";echo "
	  }else{";echo "
		layer.msg('上传失败',{icon:5,time:3000});";echo "
	  }";echo "
    }";echo "
	,error: function(){";echo "
      //请求异常回调";echo "
	  layer.msg('上传异常',{icon:5,time:3000});";echo "
    }";echo "
  });";echo "
";goto Damxi;DamldMhxj:Damxi:Damx19:$Dam1i=$Dam1i+1;goto Damx18;goto Damx1t;DamldMhx1u:Damx1t:Damx1a:goto Damx7;DamldMhx8:Damx7:echo "";echo "
});";echo "
</script>";echo "
</body>";echo "
</html>";
?>