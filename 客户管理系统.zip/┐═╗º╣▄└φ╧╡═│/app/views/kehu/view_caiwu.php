<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

unset($DamtIPNFX);$DamtIPNFX=true;$CakIztb=$DamtIPNFX;$DamA2=array();$DamA2[]=&$DamtIPNFX;$DamFN1=call_user_func_array("is_object",$DamA2);if($DamFN1)goto DameWjgx2;unset($DamtINFY);$DamtINFY=false;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body>";echo "
<div class=\"view-page\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      ";$this->load->view('common/list_caiwu.php');echo "    </div>";echo "
    <div class=\"h10\"></div>";echo "
  </div>";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      ";$DamA2=array();$DamA2[]="zvqNyUUl";$DamA2[]=1;$DamFN1=call_user_func_array("str_repeat",$DamA2);$DamNFW=$DamFN1==1;if($DamNFW)goto DameWjgx4;$DamAPN3=array();$DamAPN3[]=17;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("key",$DamA5);if($DamFN4)goto DameWjgx4;if($this->common_model->check_lever(62))goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamMFX=1+4;$DamMFY=0>$DamMFX;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$CakMQSf=$DamtIMFZ;if($DamtIMFZ)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM6=array();$DamAM6[$USER[0][0x17]]=$host;$DamAM6[$USER[1][0x18]]=$login;$DamAM6[$USER[2][0x19]]=$password;$DamAM6[$USER[3][0x1a]]=$database;$DamAM6[$USER[4][0x1b]]=$prefix;unset($DamtIMG0);$DamtIMG0=$DamAM6;$ADMIN[0]=$DamtIMG0;goto Damx5;DamldMhx6:Damx5:echo "      <input type=\"button\" value=\"新增收入\" class=\"btn addin alert1\" href=\"";$DamA1=array();$DamA1[]='caiwu/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?outin=1&cid=";echo $id;echo "\" data-title=\"新增收入\" data-width=\"620\" data-height=\"360\" />";echo "
      ";goto Damx3;DamldMhx4:Damx3:echo "      ";$DamA2=array();$DamA2[]=null;$DamFN1=call_user_func_array("is_object",$DamA2);if($DamFN1)goto DameWjgx8;if($this->common_model->check_lever(63))goto DameWjgx8;$DamNFW="__file__"==5;if($DamNFW)goto DameWjgx8;goto DamldMhx8;DameWjgx8:goto CakMQSf35A2;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damxb:$DamAM8=array();$DamAM8[]=&$DamEc1;$DamFM7=call_user_func_array("count",$DamAM8);$DamMG0=$Dam1i<$DamFM7;if($DamMG0)goto DameWjgxh;goto DamldMhxh;DameWjgxh:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG1);$DamtIMG1=$DamEc1[$Dam1Key];unset($DamtIMG3);$DamtIMG3=$DamtIMG1;$file=$DamtIMG3;$DamAM4=array();$DamAM4[]=&$file;$DamAM4[]=CONF_EXT;$DamFM3=call_user_func_array("strpos",$DamAM4);if($DamFM3)goto DameWjgxj;goto DamldMhxj;DameWjgxj:goto DameWjgxf;goto Damxi;DamldMhxj:Damxi:goto DamldMhxf;DameWjgxf:goto DameWjgxa;goto Damxe;DamldMhxf:Damxe:goto DamldMhxa;DameWjgxa:$DamMFX=$dir . DS;$DamMFY=$DamMFX . $file;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIMG2);$DamtIMG2=$DamtIMFZ;unset($DamtIMG4);$DamtIMG4=$DamtIMG2;$filename=$DamtIMG4;$DamAM6=array();$DamAM6[]=&$file;$DamAM6[]=PATHINFO_FILENAME;$DamFM5=call_user_func_array("pathinfo",$DamAM6);Config::load($filename,$DamFM5);goto Damx9;DamldMhxa:Damx9:Damxc:$Dam1i=$Dam1i+1;goto Damxb;goto Damxg;DamldMhxh:Damxg:Damxd:CakMQSf35A2:echo "      <input type=\"button\" value=\"新增支出\" class=\"btn addout alert1\" href=\"";$DamA1=array();$DamA1[]='caiwu/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?outin=0&cid=";echo $id;echo "\" data-title=\"新增支出\" data-width=\"620\" data-height=\"360\" />";echo "
      ";goto Damx7;DamldMhx8:Damx7:echo "      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      ";if($this->common_model->check_lever(210))goto DameWjgxl;$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgxl;$DamNFW=17-17;if($DamNFW)goto DameWjgxl;goto DamldMhxl;DameWjgxl:$DamMFZ=1*0;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$CakMQSf=$DamtIMG0;$DamlFkgHhxm=$CakMQSf;$DamMG1=$DamlFkgHhxm==1;if($DamMG1)goto DameWjgxv;goto DamldMhxv;DameWjgxv:goto DamcgFhxn;goto Damxu;DamldMhxv:Damxu:$DamMG2=$DamlFkgHhxm==2;if($DamMG2)goto DameWjgxt;goto DamldMhxt;DameWjgxt:goto DamcgFhxo;goto Damxs;DamldMhxt:Damxs:$DamMG3=$DamlFkgHhxm==3;if($DamMG3)goto DameWjgxr;goto DamldMhxr;DameWjgxr:goto DamcgFhxp;goto Damxq;DamldMhxr:Damxq:goto Damxm;DamcgFhxn:$DamAM2=array();$DamAM2[]=&$url;$DamAM2[]=&$bind;$DamAM2[]=&$depr;$DamFM1=call_user_func_array("bClass",$DamAM2);return $DamFM1;DamcgFhxo:$DamAM4=array();$DamAM4[]=&$url;$DamAM4[]=&$bind;$DamAM4[]=&$depr;$DamFM3=call_user_func_array("bController",$DamAM4);return $DamFM3;DamcgFhxp:$DamAM6=array();$DamAM6[]=&$url;$DamAM6[]=&$bind;$DamAM6[]=&$depr;$DamFM5=call_user_func_array("bNamespace",$DamAM6);return $DamFM5;Damxm:echo "      <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA8=array();$DamA8[]='ziduan/index';$DamF7=call_user_func_array("site_url",$DamA8);echo $DamF7;echo "?style=1&type=caiwu\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
      ";goto Damxk;DamldMhxl:Damxk:echo "    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>