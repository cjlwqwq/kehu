<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamPNFX=17+2;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_string",$DamA2);if($DamFN1)goto DameWjgx2;$DamA4=array();$DamA4[]=17;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFY=0==$DamFN3;if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body>";echo "
<div class=\"view-page\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      ";$this->load->view('common/list_dingdan.php');echo "    </div>";echo "
    <div class=\"h10\"></div>";echo "
  </div>";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      ";$DamNFW=$_GET=="nhTjPx";if($DamNFW)goto DameWjgx4;if($this->common_model->check_lever(32))goto DameWjgx4;$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf35A4;$DamAM3=array();$DamAM3[]=&$rules;$DamFM2=call_user_func_array("is_array",$DamAM3);if($DamFM2)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf35A4:goto Damx5;DamldMhx6:goto CakMQSf35A6;$DamMFZ=$path . EXT;$DamAM5=array();$DamAM5[]=&$DamMFZ;$DamFM4=call_user_func_array("is_file",$DamAM5);if($DamFM4)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG0=$path . EXT;$DamMG1=include $DamMG0;goto Damx9;DamldMhxa:Damx9:CakMQSf35A6:Damx5:echo "      <input type=\"button\" value=\"新增\" class=\"btn adddo alert1\" href=\"";$DamA1=array();$DamA1[]='dingdan/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $id;echo "\" data-title=\"新增\" data-width=\"620\" data-height=\"500\" />";echo "
      ";goto Damx3;DamldMhx4:Damx3:echo "      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      ";$DamA2=array();$DamA2[]="FzrBkhof";$DamA2[]="17";$DamFN1=call_user_func_array("strspn",$DamA2);if($DamFN1)goto DameWjgxc;if($this->common_model->check_lever(210))goto DameWjgxc;$DamA4=array();$DamA4[]=17;$DamFN3=call_user_func_array("md5",$DamA4);$DamNFW=$DamFN3=="wOCcEI";if($DamNFW)goto DameWjgxc;goto DamldMhxc;DameWjgxc:goto CakMQSf35A8;$DamMFX=$R4vP4 . DS;unset($DamtIMFY);$DamtIMFY=$DamMFX;$R4vP5=$DamtIMFY;$DamAM5=array();unset($DamtIMFZ);$DamtIMFZ=$DamAM5;$R4vA5=$DamtIMFZ;unset($DamtIMG0);$DamtIMG0=$request;$R4vA5[]=$DamtIMG0;$DamAM7=array();$DamAM7[]=&$R4vA5;$DamAM7[]=&$R4vA4;$DamFM6=call_user_func_array("call_user_func_array",$DamAM7);unset($DamtIMG1);$DamtIMG1=$DamFM6;$R4vC3=$DamtIMG1;CakMQSf35A8:goto CakMQSf35AA;$DamAM8=array();unset($DamtIMG2);$DamtIMG2=$DamAM8;$R4vA1=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=&$dispatch;$R4vA1[]=&$DamtIMG3;$DamAM9=array();unset($DamtIMG4);$DamtIMG4=$DamAM9;$R4vA2=$DamtIMG4;$DamAM11=array();$DamAM11[]=&$R4vA2;$DamAM11[]=&$R4vA1;$DamFM10=call_user_func_array("call_user_func_array",$DamAM11);unset($DamtIMG5);$DamtIMG5=$DamFM10;$R4vC0=$DamtIMG5;CakMQSf35AA:echo "      <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA13=array();$DamA13[]='ziduan/index';$DamF12=call_user_func_array("site_url",$DamA13);echo $DamF12;echo "?style=1&type=dingdan\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
      ";goto Damxb;DamldMhxc:Damxb:echo "    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>