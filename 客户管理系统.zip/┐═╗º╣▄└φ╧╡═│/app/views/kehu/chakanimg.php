<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="Ik";$DamA2[]=17;$DamFN1=call_user_func_array("strpos",$DamA2);$DamNFX=true===$DamFN1;if($DamNFX)goto DameWjgx2;$DamA4=array();$DamA4[]=17;$DamFN3=call_user_func_array("gettype",$DamA4);$DamNFY=$DamFN3=="string";if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";echo "
<html xmlns=\"http://www.w3.org/1999/xhtml\">";echo "
<head>";echo "
<meta name=\"renderer\" content=\"webkit|ie-comp|ie-stand\">";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<link href=\"/themes/default/css/common.css\" rel=\"stylesheet\" type=\"text/css\">";echo "
<script>";echo "
var common_getarea  = \"";$DamA1=array();$DamA1[]='common/getarea';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\";";echo "
var common_gettrade = \"";$DamA1=array();$DamA1[]='common/gettrade';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\";";echo "
var common_kehu_check  = \"";$DamA1=array();$DamA1[]='common/kehu_check';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\";";echo "
</script>";echo "
<script language=\"javascript\" src=\"/themes/default/js/Common.js\"></script>";echo "
<script language=\"javascript\" src=\"/themes/default/js/jquery-1.11.2.min.js\"></script>";echo "
<script language=\"javascript\" src=\"/themes/default/js/tips.js\"></script>";echo "
<script src=\"/themes/default/js/jquery.artDialog.js?skin=default\"></script>";echo "
<link href=\"/themes/default/css/jquery.vtip.css\" rel=\"stylesheet\" type=\"text/css\">";echo "
<script src=\"/themes/default/js/jquery.vtip.js\"></script>";echo "
<script type=\"text/javascript\"  src=\"/theme/layer/layer.js\"></script>";echo "
<style>";echo "
body { overflow-y:hidden }";echo "
</style>";echo "
</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  ";echo "
  ";$DamA1=array();$DamA1[]=&$imgall;$DamF0=call_user_func_array("htmlspecialchars_decode",$DamA1);echo $DamF0;echo "  <div class=\"h50b\"></div>";echo "
  <div class=\"fixed_bg_B\">";echo "
    <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";echo "
      <tr>";echo "
        <td valign=\"top\" class=\"td_n Bottom_pd \"><input type=\"submit\" id=\"submit\" class=\"btn2 btnbaoc\" value=\"保存\">";echo "
          <input name=\"Back\" type=\"button\" id=\"Back\" class=\"btn2 btnguanb\" value=\"关闭\" onClick=\"art.dialog.close();parent.layclose();\"></td>";echo "
      </tr>";echo "
    </table>";echo "
  </div>";echo "
  <script src=\"/themes/default/WdatePicker.js\"></script> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>