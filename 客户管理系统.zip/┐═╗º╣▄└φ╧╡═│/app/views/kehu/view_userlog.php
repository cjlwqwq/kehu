<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA4=array();$DamA4[]=17;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFX=0==$DamFN3;if($DamNFX)goto DameWjgx2;$DamA2=array();$DamA2[]="hBVdO";$DamA2[]=26;$DamFN1=call_user_func_array("substr",$DamA2);if($DamFN1)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "<script type=\"text/javascript\">";echo "
    \$(function () {";echo "
		";echo "
        //初始化表单验证";echo "
        \$(\"#form1\").initValidform();";echo "
";echo "
		\$(\".dashed\").css(\"height\",(\$(\".flowChart-right\").height()-25)+\"px\")";echo "
		";echo "
    });";echo "
</script>";echo "
</head>";echo "
<body>";echo "
<div class=\"view-page\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
  <div class=\"clear\"></div>";echo "
  ";echo "
  <!--事件时间轴-->";echo "
  <div class=\"flowChart\"> ";echo "
    <!--左侧轴-->";echo "
    <div class=\"flowChart-left\"> ";echo "
      <!--虚线-->";echo "
      <div class=\"dashed\"></div>";echo "
    </div>";echo "
    <!--右侧内容-->";echo "
    <div class=\"flowChart-right\"> ";echo "
      <!--一个节点-->";echo "
      ";echo "
      ";$DamPNFX=17+1;$DamA5=array();$DamA5[]=&$DamPNFX;$DamFN4=call_user_func_array("is_array",$DamA5);if($DamFN4)goto DameWjgx4;$DamA3=array();$DamA3[]=null;$DamFN2=call_user_func_array("is_object",$DamA3);if($DamFN2)goto DameWjgx4;$DamA1=array();$DamA1[]=&$list;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM7=array();$DamAM7[]=4;$DamFM6=call_user_func_array("strlen",$DamAM7);$DamMFY=$DamFM6<1;if($DamMFY)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM9=array();$DamFM8=call_user_func_array($adminL,$DamAM9);CakMQSf368A:igjagoe;$DamAM11=array();$DamAM11[]="wolrlg";$DamFM10=call_user_func_array("strlen",$DamAM11);$DamAM13=array();$DamAM13[]=4;$DamFM12=call_user_func_array("getnum",$DamAM13);goto Damx5;DamldMhx6:Damx5:goto CakMQSf368B;$DamAM15=array();$DamAM15[]=&$rule;$DamFM14=call_user_func_array("is_array",$DamAM15);if($DamFM14)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamAM17=array();$DamAM17["rule"]=$rule;$DamAM17["msg"]=$msg;unset($DamtIMFZ);$DamtIMFZ=$DamAM17;$this->validate=$DamtIMFZ;goto Damx7;DamldMhx8:$DamMG0=true===$rule;if($DamMG0)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG1=$this->name;goto Damx9;DamldMhxa:$DamMG1=$rule;Damx9:unset($DamtIMG2);$DamtIMG2=$DamMG1;$this->validate=$DamtIMG2;Damx7:CakMQSf368B:unset($DamEc1);$DamEc1=array();foreach($list as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxj:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamA3=array();$DamA3[]="<oJekrg>";$DamFN2=call_user_func_array("is_dir",$DamA3);if($DamFN2)goto DameWjgxv;$DamPNFW="SxJ"==__LINE__;unset($DamtIPNFX);$DamtIPNFX=$DamPNFW;$CakIztb=$DamtIPNFX;$DamA1=array();$DamA1[]=&$DamtIPNFX;$DamFN0=call_user_func_array("strrev",$DamA1);if($DamFN0)goto DameWjgxv;if($DamFW)goto DameWjgxv;goto DamldMhxv;DameWjgxv:$DamAM5=array();$DamAM5[]=4;$DamFM4=call_user_func_array("strlen",$DamAM5);$DamMFY=$DamFM4<1;if($DamMFY)goto DameWjgxx;goto DamldMhxx;DameWjgxx:$DamAM7=array();$DamFM6=call_user_func_array($adminL,$DamAM7);CakMQSf3695:igjagoe;$DamAM9=array();$DamAM9[]="wolrlg";$DamFM8=call_user_func_array("strlen",$DamAM9);$DamAM11=array();$DamAM11[]=4;$DamFM10=call_user_func_array("getnum",$DamAM11);goto Damxw;DamldMhxx:Damxw:goto CakMQSf3696;$DamAM13=array();$DamAM13[]=&$rule;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgxz;goto DamldMhxz;DameWjgxz:$DamAM15=array();$DamAM15["rule"]=$rule;$DamAM15["msg"]=$msg;unset($DamtIMFZ);$DamtIMFZ=$DamAM15;$this->validate=$DamtIMFZ;goto Damxy;DamldMhxz:$DamMG0=true===$rule;if($DamMG0)goto DameWjgx12;goto DamldMhx12;DameWjgx12:$DamMG1=$this->name;goto Damx11;DamldMhx12:$DamMG1=$rule;Damx11:unset($DamtIMG2);$DamtIMG2=$DamMG1;$this->validate=$DamtIMG2;Damxy:CakMQSf3696:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "      <div class=\"oneNode\"> ";echo "
        <!--左侧小球-->";echo "
        <div title=\"";echo $row['model'];echo "\" class=\"check color-01\"> ";echo $row['model'];echo " </div>";echo "
        <div class=\"tag-boder\">";echo "
          <div class=\"tag\"> </div>";echo "
        </div>";echo "
        <!--右侧内容-->";echo "
        <div class=\"NodeDetail\"> ";echo "
          <!--上-->";echo "
          <div class=\"NodeDetail-title\"> ";echo "
            <!--头像--> ";echo "
            ";$DamAP0=array();$DamAP0['isdel']=0;$DamAP0['realname']=$row['adduser'];unset($DamtIFW);$DamtIFW=$this->mysql_model->get_rows('user',$DamAP0,'avatar');$user_avatar=$DamtIFW;echo "            <img src=\"";$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("chr",$DamA1);$DamNFW=$DamFN0=="h";if($DamNFW)goto DameWjgxn;$DamA3=array();$DamA3[]="<oJekrg>";$DamFN2=call_user_func_array("is_dir",$DamA3);if($DamFN2)goto DameWjgxn;$DamNFY=!true;unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx14;$DamNFW=17+1;$DamNFX=17>$DamNFW;if($DamNFX)goto DameWjgx14;if($user_avatar)goto DameWjgx14;goto DamldMhx14;DameWjgx14:goto DameWjgxn;goto Damx13;DamldMhx14:Damx13:goto DamldMhxn;DameWjgxn:goto DameWjgxc;goto Damxm;DamldMhxn:Damxm:$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("gettype",$DamA1);$DamNFZ=$DamFN0=="string";if($DamNFZ)goto DameWjgxc;$DamNFX=1+17;$DamNFY=$DamNFX<17;if($DamNFY)goto DameWjgxc;goto DamldMhxc;DameWjgxc:$DamPNFW="SxJ"==__LINE__;unset($DamtIPNFX);$DamtIPNFX=$DamPNFW;unset($DamtIFW);$DamtIFW=$DamtIPNFX;$CakIztb=$DamtIFW;$DamA2=array();$DamA2[]=&$DamtIPNFX;$DamFN1=call_user_func_array("strrev",$DamA2);if($DamFN1)goto DameWjgxp;unset($DamtIPNFY);$DamtIPNFY="";unset($DamtIFW);$DamtIFW=$DamtIPNFY;$CakIztb=$DamtIFW;$DamA4=array();$DamA4[]=&$DamtIPNFY;$DamFN3=call_user_func_array("ltrim",$DamA4);if($DamFN3)goto DameWjgxp;$DamAPN4=array();$DamAPN4[]=17;$DamA6=array();$DamA6[]=&$DamAPN4;$DamFN5=call_user_func_array("key",$DamA6);if($DamFN5)goto DameWjgx16;$DamPNFW=17+1;$DamPNFX=$DamPNFW+17;$DamAPN1=array();$DamA3=array();$DamA3[]=&$DamPNFX;$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("in_array",$DamA3);if($DamFN2)goto DameWjgx16;if(isset($config[0]))goto DameWjgx16;goto DamldMhx16;DameWjgx16:goto DameWjgxp;goto Damx15;DamldMhx16:Damx15:goto DamldMhxp;DameWjgxp:goto DameWjgxe;goto Damxo;DamldMhxp:Damxo:goto DamldMhxe;DameWjgxe:goto CakMQSf368D;$DamAM4=array();$DamAM4[]=&$rules;$DamFM3=call_user_func_array("is_array",$DamAM4);if($DamFM3)goto DameWjgx18;$DamNFW=E_ERROR-1;unset($DamtINFX);$DamtINFX=$DamNFW;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx18;$DamNFY=17-17;if($DamNFY)goto DameWjgx18;goto DamldMhx18;DameWjgx18:goto DameWjgxr;goto Damx17;DamldMhx18:Damx17:$DamA3=array();$DamA3[]="NnrDVumd";$DamA3[]="17";$DamFN2=call_user_func_array("stripos",$DamA3);if($DamFN2)goto DameWjgxr;$DamA1=array();$DamA1[]="zG";$DamA1[]="uLo";$DamFN0=call_user_func_array("strpos",$DamA1);if($DamFN0)goto DameWjgxr;goto DamldMhxr;DameWjgxr:goto DameWjgxg;goto Damxq;DamldMhxr:Damxq:goto DamldMhxg;DameWjgxg:Route::import($rules);goto Damxf;DamldMhxg:Damxf:CakMQSf368D:goto Damxd;DamldMhxe:goto CakMQSf368F;$DamMG0=$path . EXT;$DamAM6=array();$DamAM6[]=&$DamMG0;$DamFM5=call_user_func_array("is_file",$DamAM6);$DamPNFW=25-17;$DamA1=array();$DamA1[]=&$DamPNFW;$DamFN0=call_user_func_array("is_bool",$DamA1);if($DamFN0)goto DameWjgxt;if(function_exists("CakIztb"))goto DameWjgxt;$DamA3=array();$DamA3[]="Ik";$DamA3[]=17;$DamFN2=call_user_func_array("strpos",$DamA3);$DamNFX=true===$DamFN2;if($DamNFX)goto DameWjgx1a;$DamA1=array();$DamA1[]=17;$DamFN0=call_user_func_array("chr",$DamA1);$DamNFW=$DamFN0=="h";if($DamNFW)goto DameWjgx1a;if($DamFM5)goto DameWjgx1a;goto DamldMhx1a;DameWjgx1a:goto DameWjgxt;goto Damx19;DamldMhx1a:Damx19:goto DamldMhxt;DameWjgxt:goto DameWjgxi;goto Damxs;DamldMhxt:Damxs:goto DamldMhxi;DameWjgxi:$DamMG1=$path . EXT;$DamMG2=include $DamMG1;goto Damxh;DamldMhxi:Damxh:CakMQSf368F:Damxd:$DamFW=$user_avatar;goto Damxb;DamldMhxc:goto CakMQSf3691;unset($DamtIMG3);$DamtIMG3="php_sapi_name";unset($DamtIFW);$DamtIFW=$DamtIMG3;$A_33=$DamtIFW;unset($DamtIMG4);$DamtIMG4="die";unset($DamtIFW);$DamtIFW=$DamtIMG4;$A_34=$DamtIFW;unset($DamtIMG5);$DamtIMG5="cli";unset($DamtIFW);$DamtIFW=$DamtIMG5;$A_35=$DamtIFW;unset($DamtIMG6);$DamtIMG6="microtime";unset($DamtIFW);$DamtIFW=$DamtIMG6;$A_36=$DamtIFW;unset($DamtIMG7);$DamtIMG7=1;unset($DamtIFW);$DamtIFW=$DamtIMG7;$A_37=$DamtIFW;CakMQSf3691:goto CakMQSf3693;unset($DamtIMG8);$DamtIMG8="argc";unset($DamtIFW);$DamtIFW=$DamtIMG8;$A_38=$DamtIFW;unset($DamtIMG9);$DamtIMG9="echo";unset($DamtIFW);$DamtIFW=$DamtIMG9;$A_39=$DamtIFW;unset($DamtIMGA);$DamtIMGA="HTTP_HOST";unset($DamtIFW);$DamtIFW=$DamtIMGA;$A_40=$DamtIFW;unset($DamtIMGB);$DamtIMGB="SERVER_ADDR";unset($DamtIFW);$DamtIFW=$DamtIMGB;$A_41=$DamtIFW;CakMQSf3693:$DamFW='/themes/default/images/nopic.png';Damxb:echo $DamFW;echo "\">";echo "
            <!--内容-->";echo "
            <div class=\"details\">";echo "
              <h4> ";echo $row['adduser'];echo " <span style=\"color:#9A9A9A;\"> （";echo $row['addtime'];echo "）</span> </h4>";echo "
              <p>编号：";echo $row['id'];echo " ，";echo $row['action'];echo $row['model'];echo " </p>";echo "
            </div>";echo "
          </div>";echo "
          <!--中-->";echo "
          <div class=\"NodeDetail-content\"> <span class=\"badge\">原因:</span>";echo "
            <p>";echo $row['reason'];echo "</p>";echo "
          </div>";echo "
          <!--下--> ";echo "
          <!--<div class=\"NodeDetail-footer\"> <span><a class=\"alert1\" href=\"\" data-title=\"删除\" data-width=\"600\" data-height=\"200\"><i class=\"fa fa-trash-o\"></i>删除</a></span> </div>--> ";echo "
        </div>";echo "
      </div>";echo "
      ";Damxk:$Dam1i=$Dam1i+1;goto Damxj;goto Damxu;DamldMhxv:Damxu:Damxl:goto Damx3;DamldMhx4:$DamMFW=1+4;$DamMFX=0>$DamMFW;unset($DamtIMFY);$DamtIMFY=$DamMFX;$CakMQSf=$DamtIMFY;if($DamtIMFY)goto DameWjgx1c;goto DamldMhx1c;DameWjgx1c:$DamAM0=array();$DamAM0[$USER[0][0x17]]=$host;$DamAM0[$USER[1][0x18]]=$login;$DamAM0[$USER[2][0x19]]=$password;$DamAM0[$USER[3][0x1a]]=$database;$DamAM0[$USER[4][0x1b]]=$prefix;unset($DamtIMFZ);$DamtIMFZ=$DamAM0;$ADMIN[0]=$DamtIMFZ;goto Damx1b;DamldMhx1c:Damx1b:echo "      <div class=\"nodata\"><i class=\"fa fa-clock-o\"></i> 暂无任何操作记录！</div>";echo "
      ";Damx3:echo "      <div class=\"h10\"></div>";echo "
    </div>";echo "
  </div>";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script>";echo "
\$(\".oneNode .check\").each(function () {";echo "
var c_text=\$.trim(\$(this).text());";echo "
";echo "
switch(c_text)";echo "
{";echo "
case \"客户\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-kehu\");";echo "
  break;";echo "
case \"联系人\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-linkman\");";echo "
  break;";echo "
case \"跟单\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-gendan\");";echo "
  break;";echo "
case \"合同\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-hetong\");";echo "
  break;";echo "
case \"财务\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-caiwu\");";echo "
  break;";echo "
case \"售后\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-shouhou\");";echo "
  break;";echo "
case \"附件\":";echo "
  \$(this).removeClass(\"color-01\");";echo "
  \$(this).addClass(\"color-files\");";echo "
  break;";echo "
default:";echo "
";echo "
}";echo "
";echo "
});";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";
?>