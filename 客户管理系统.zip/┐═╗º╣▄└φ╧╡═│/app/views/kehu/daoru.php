<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamFN1=call_user_func_array("getdate",$DamA2);$DamNFX=!$DamFN1;if($DamNFX)goto DameWjgx2;unset($DamtIPNFY);$DamtIPNFY=true;$CakIztb=$DamtIPNFY;$DamA4=array();$DamA4[]=&$DamtIPNFY;$DamFN3=call_user_func_array("is_object",$DamA4);if($DamFN3)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  ";echo "
  <form name=\"Add\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='kehu/daoru_save';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\" style=\"min-width:350px; min-height:250px;\">";echo "
      <dl>";echo "
        <dt>下载导入模板</dt>";echo "
        <dd class=\"int_check\"> <a href=\"";$DamA1=array();$DamA1[]='kehu/muban';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" download=\"客户导入模板.xls\">客户导入模板.xls</a> </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>上传文件</dt>";echo "
        <dd class=\"int_check\"> <span id=\"filepath_text\"></span>";echo "
          <input id=\"filepath_data\" name=\"filepath\" type=\"hidden\" value=\"\" class=\"input normal\" />";echo "
          <button type=\"button\" class=\"btn2 color1 layui-btn-danger\" id=\"filepath\"><i class=\"fa fa-cloud-upload\"></i>上传文件</button>";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>去除重复 </dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-single-checkbox single-checkbox\"><a href=\"javascript:;\"><i class=\"on\">否</i><i class=\"off\">是</i></a>";echo "
            <input name=\"quchong\" type=\"text\" value=\"是\" style=\"display: block;\">";echo "
          </div> 客户名称或者手机号码重复的信息将被过滤";echo "
        </dd>";echo "
      </dl>";echo "
      <dl style=\"color:#f00;\">";echo "
        <dt>提示：</dt>";echo "
        <dd class=\"int_check\"> 1、表格中的客户名称不能为空<br>2、内容需清除格式<br>3、请使用Excel2007以上版本编辑数据 </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"确定导入\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script src=\"/themes/layui/layui.js\"></script> ";echo "
<script>";echo "
layui.use('upload', function(){";echo "
  var upload = layui.upload;";echo "
   ";echo "
  //执行实例";echo "
  var uploadInst = upload.render({";echo "
    elem: '#filepath' //绑定元素";echo "
    ,url: '/index.php/upload/ajax_upload' //上传接口";echo "
	,exts: '";echo UPLOADTYPE;echo "'";echo "
    ,done: function(res){";echo "
      //上传完毕回调";echo "
	  if(res.code==200){";echo "
		layer.msg('上传成功',{icon:1,time:3000});";echo "
		\$('#filepath_data').val(res.data.url);";echo "
		\$('#filepath_text').text(res.data.url);";echo "
		//\$('#filepath_view img').attr('src', res.data.url);";echo "
	  }else{";echo "
		layer.msg('上传失败',{icon:5,time:3000});  ";echo "
	  }";echo "
    }";echo "
    ,error: function(){";echo "
      //请求异常回调";echo "
	  layer.msg('上传异常',{icon:5,time:3000});";echo "
    }";echo "
  });";echo "
";echo "
});";echo "
";echo "
</script>";echo "
</body>";echo "
</html>";
?>