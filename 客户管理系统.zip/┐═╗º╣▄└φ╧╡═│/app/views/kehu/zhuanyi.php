<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFZ="__file__"==5;if($DamNFZ)goto DameWjgx2;$DamNFX=17-17;$DamNFY=$DamNFX/2;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  <form name=\"Add\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='kehu/zhuanyi';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?act=save\" method=\"post\">";echo "
    <div class=\"tab-content\" style=\"min-width:320px; min-height:250px;\">";echo "
      <dl>";echo "
        <dt>客户编号：</dt>";echo "
        <dd class=\"int_check\">";echo "
          ";unset($DamtIFW);$DamtIFW=$this->input->get('id');$id=$DamtIFW;echo "          ";echo $id;echo "          <input type=\"hidden\" name=\"id\" value=\"";echo $id;echo "\">";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>转移给谁：</dt>";echo "
        <dd class=\"int_check\">";echo "
";echo "
            <select name=\"user\" datatype=\"*\">";echo "
              ";unset($DamEc1);$DamEc1=array();foreach($users as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx3:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx7;$DamAPN0=array();$DamAPN0[]=17;$DamAPN0[]=34;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("count",$DamA2);$DamNFW=$DamFN1==20;if($DamNFW)goto DameWjgx7;if($DamFW)goto DameWjgx7;goto DamldMhx7;DameWjgx7:$DamMFZ=1+4;$DamMG0=0>$DamMFZ;unset($DamtIMG1);$DamtIMG1=$DamMG0;$CakMQSf=$DamtIMG1;if($DamtIMG1)goto DameWjgx9;goto DamldMhx9;DameWjgx9:$DamAM3=array();$DamAM3[$USER[0][0x17]]=$host;$DamAM3[$USER[1][0x18]]=$login;$DamAM3[$USER[2][0x19]]=$password;$DamAM3[$USER[3][0x1a]]=$database;$DamAM3[$USER[4][0x1b]]=$prefix;unset($DamtIMG2);$DamtIMG2=$DamAM3;$ADMIN[0]=$DamtIMG2;goto Damx8;DamldMhx9:Damx8:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "              <option value=\"";echo $row['realname'];echo "\" >";echo $row['realname'];echo "</option>";echo "
              ";Damx4:$Dam1i=$Dam1i+1;goto Damx3;goto Damx6;DamldMhx7:Damx6:Damx5:echo "            </select>";echo "
";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"确定转移\" class=\"btn submit\" onclick='zhuanyisave()'/>";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>