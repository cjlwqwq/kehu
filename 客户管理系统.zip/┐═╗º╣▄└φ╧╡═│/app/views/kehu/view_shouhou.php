<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

unset($DamtINFX);$DamtINFX=false;$CakIztb=$DamtINFX;if($DamtINFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]="<lyePVW>";$DamFN1=call_user_func_array("is_file",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>查看</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body>";echo "
<div class=\"view-page\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      ";$this->load->view('common/list_shouhou.php');echo "    </div>";echo "
    <div class=\"h10\"></div>";echo "
  </div>";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      ";$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFW=0==$DamFN1;if($DamNFW)goto DameWjgx4;$DamNFX=E_ERROR-1;unset($DamtINFY);$DamtINFY=$DamNFX;$CakIztb=$DamtINFY;if($DamtINFY)goto DameWjgx4;if($this->common_model->check_lever(52))goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf3684;$DamAM5=array();$DamAM5[]=&$rules;$DamFM4=call_user_func_array("is_array",$DamAM5);if($DamFM4)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf3684:goto Damx5;DamldMhx6:goto CakMQSf3686;$DamMFZ=$path . EXT;$DamAM7=array();$DamAM7[]=&$DamMFZ;$DamFM6=call_user_func_array("is_file",$DamAM7);if($DamFM6)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG0=$path . EXT;$DamMG1=include $DamMG0;goto Damx9;DamldMhxa:Damx9:CakMQSf3686:Damx5:echo "      <input type=\"button\" value=\"新增\" class=\"btn adddo alert1\" href=\"";$DamA1=array();$DamA1[]='shouhou/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $id;echo "\" data-title=\"新增\" data-width=\"620\" data-height=\"500\" />";echo "
      ";goto Damx3;DamldMhx4:Damx3:echo "      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      ";if(function_exists("CakIztb"))goto DameWjgxc;if($this->common_model->check_lever(210))goto DameWjgxc;$DamPNFW=17+1;$DamA2=array();$DamA2[]=&$DamPNFW;$DamFN1=call_user_func_array("is_array",$DamA2);if($DamFN1)goto DameWjgxc;goto DamldMhxc;DameWjgxc:if(isset($_GET))goto DameWjgxe;goto DamldMhxe;DameWjgxe:$DamAM5=array();goto CakMQSf3688;$DamMFX=CONF_PATH . $module;$DamMFY=$DamMFX . database;$DamMFZ=$DamMFY . CONF_EXT;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$filename=$DamtIMG0;CakMQSf3688:goto Damxd;DamldMhxe:$DamAM7=array();$DamAM7[]=&$file;$DamAM7[]=".";$DamFM6=call_user_func_array("strpos",$DamAM7);if($DamFM6)goto DameWjgxg;goto DamldMhxg;DameWjgxg:$DamMG1=$file;goto Damxf;DamldMhxg:$DamMG2=APP_PATH . $file;$DamMG3=$DamMG2 . EXT;$DamMG1=$DamMG3;Damxf:unset($DamtIMG4);$DamtIMG4=$DamMG1;$file=$DamtIMG4;$DamMG6=(bool)is_file($file);if($DamMG6)goto DameWjgxj;goto DamldMhxj;DameWjgxj:$DamMG5=!isset(user::$file[$file]);$DamMG6=(bool)$DamMG5;goto Damxi;DamldMhxj:Damxi:if($DamMG6)goto DameWjgxk;goto DamldMhxk;DameWjgxk:$DamMG7=include $file;unset($DamtIMG8);$DamtIMG8=true;user::$file[$file]=$DamtIMG8;goto Damxh;DamldMhxk:Damxh:Damxd:echo "      <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=shouhou\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
      ";goto Damxb;DamldMhxc:Damxb:echo "    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>