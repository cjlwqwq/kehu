<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamPNFX=17+1;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_array",$DamA2);if($DamFN1)goto DameWjgx2;$DamPNFY=25-17;$DamA4=array();$DamA4[]=&$DamPNFY;$DamFN3=call_user_func_array("is_bool",$DamA4);if($DamFN3)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='hetong/shenhe';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 审核状态 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-multi-radio\"> <span>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"合同有效\" datatype=\"*\" errormsg=\"请选择状态！\" ";$DamFW=$shenhe=='合同有效';unset($DamtIPNFY);$DamtIPNFY="hJYsK";$CakIztb=$DamtIPNFY;$DamA1=array();$DamA1[]=&$DamtIPNFY;$DamFN0=call_user_func_array("strlen",$DamA1);$DamNFZ=!$DamFN0;if($DamNFZ)goto DameWjgx4;$DamPNG0=25-17;$DamA3=array();$DamA3[]=&$DamPNG0;$DamFN2=call_user_func_array("is_bool",$DamA3);if($DamFN2)goto DameWjgx4;if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf34BE;$DamAM6=array();$DamAM6[]=&$rules;$DamFM5=call_user_func_array("is_array",$DamAM6);if($DamFM5)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf34BE:goto Damx5;DamldMhx6:goto CakMQSf34C0;$DamMG1=$path . EXT;$DamAM8=array();$DamAM8[]=&$DamMG1;$DamFM7=call_user_func_array("is_file",$DamAM8);if($DamFM7)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMG2=$path . EXT;$DamMG3=include $DamMG2;goto Damx9;DamldMhxa:Damx9:CakMQSf34C0:Damx5:$DamFX='checked';goto Damx3;DamldMhx4:goto CakMQSf34C2;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damxd:$DamAM14=array();$DamAM14[]=&$DamEc1;$DamFM13=call_user_func_array("count",$DamAM14);$DamMG7=$Dam1i<$DamFM13;if($DamMG7)goto DameWjgxj;goto DamldMhxj;DameWjgxj:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG8);$DamtIMG8=$DamEc1[$Dam1Key];unset($DamtIMGA);$DamtIMGA=$DamtIMG8;$file=$DamtIMGA;$DamAM10=array();$DamAM10[]=&$file;$DamAM10[]=CONF_EXT;$DamFM9=call_user_func_array("strpos",$DamAM10);if($DamFM9)goto DameWjgxl;goto DamldMhxl;DameWjgxl:goto DameWjgxh;goto Damxk;DamldMhxl:Damxk:goto DamldMhxh;DameWjgxh:goto DameWjgxc;goto Damxg;DamldMhxh:Damxg:goto DamldMhxc;DameWjgxc:$DamMG4=$dir . DS;$DamMG5=$DamMG4 . $file;unset($DamtIMG6);$DamtIMG6=$DamMG5;unset($DamtIMG9);$DamtIMG9=$DamtIMG6;unset($DamtIMGB);$DamtIMGB=$DamtIMG9;$filename=$DamtIMGB;$DamAM12=array();$DamAM12[]=&$file;$DamAM12[]=PATHINFO_FILENAME;$DamFM11=call_user_func_array("pathinfo",$DamAM12);Config::load($filename,$DamFM11);goto Damxb;DamldMhxc:Damxb:Damxe:$Dam1i=$Dam1i+1;goto Damxd;goto Damxi;DamldMhxj:Damxi:Damxf:CakMQSf34C2:$DamFX='';Damx3:echo $DamFX;echo "/>";echo "
            <label>合同有效</label>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"合同无效\" ";$DamFW=$shenhe=='合同无效';$DamA3=array();$DamA3[]=null;$DamFN2=call_user_func_array("is_object",$DamA3);if($DamFN2)goto DameWjgxn;$DamPNFY=17-1;$DamA1=array();$DamA1[]=&$DamPNFY;$DamFN0=call_user_func_array("is_null",$DamA1);if($DamFN0)goto DameWjgxn;if($DamFW)goto DameWjgxn;goto DamldMhxn;DameWjgxn:goto CakMQSf34C4;$DamMFZ=$R4vP4 . DS;unset($DamtIMG0);$DamtIMG0=$DamMFZ;$R4vP5=$DamtIMG0;$DamAM4=array();unset($DamtIMG1);$DamtIMG1=$DamAM4;$R4vA5=$DamtIMG1;unset($DamtIMG2);$DamtIMG2=$request;$R4vA5[]=$DamtIMG2;$DamAM6=array();$DamAM6[]=&$R4vA5;$DamAM6[]=&$R4vA4;$DamFM5=call_user_func_array("call_user_func_array",$DamAM6);unset($DamtIMG3);$DamtIMG3=$DamFM5;$R4vC3=$DamtIMG3;CakMQSf34C4:goto CakMQSf34C6;$DamAM7=array();unset($DamtIMG4);$DamtIMG4=$DamAM7;$R4vA1=$DamtIMG4;unset($DamtIMG5);$DamtIMG5=&$dispatch;$R4vA1[]=&$DamtIMG5;$DamAM8=array();unset($DamtIMG6);$DamtIMG6=$DamAM8;$R4vA2=$DamtIMG6;$DamAM10=array();$DamAM10[]=&$R4vA2;$DamAM10[]=&$R4vA1;$DamFM9=call_user_func_array("call_user_func_array",$DamAM10);unset($DamtIMG7);$DamtIMG7=$DamFM9;$R4vC0=$DamtIMG7;CakMQSf34C6:$DamFX='checked';goto Damxm;DamldMhxn:$DamMG8=1*0;unset($DamtIMG9);$DamtIMG9=$DamMG8;$CakMQSf=$DamtIMG9;$DamlFkgHhxo=$CakMQSf;$DamMGA=$DamlFkgHhxo==1;if($DamMGA)goto DameWjgxx;goto DamldMhxx;DameWjgxx:goto DamcgFhxp;goto Damxw;DamldMhxx:Damxw:$DamMGB=$DamlFkgHhxo==2;if($DamMGB)goto DameWjgxv;goto DamldMhxv;DameWjgxv:goto DamcgFhxq;goto Damxu;DamldMhxv:Damxu:$DamMGC=$DamlFkgHhxo==3;if($DamMGC)goto DameWjgxt;goto DamldMhxt;DameWjgxt:goto DamcgFhxr;goto Damxs;DamldMhxt:Damxs:goto Damxo;DamcgFhxp:$DamAM12=array();$DamAM12[]=&$url;$DamAM12[]=&$bind;$DamAM12[]=&$depr;$DamFM11=call_user_func_array("bClass",$DamAM12);return $DamFM11;DamcgFhxq:$DamAM14=array();$DamAM14[]=&$url;$DamAM14[]=&$bind;$DamAM14[]=&$depr;$DamFM13=call_user_func_array("bController",$DamAM14);return $DamFM13;DamcgFhxr:$DamAM16=array();$DamAM16[]=&$url;$DamAM16[]=&$bind;$DamAM16[]=&$depr;$DamFM15=call_user_func_array("bNamespace",$DamAM16);return $DamFM15;Damxo:$DamFX='';Damxm:echo $DamFX;echo "/>";echo "
            <label>合同无效</label>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"待审\" ";$DamFW=$shenhe=='待审';$DamNFZ=E_ERROR-1;unset($DamtING0);$DamtING0=$DamNFZ;$CakIztb=$DamtING0;if($DamtING0)goto DameWjgxz;$DamAPN0=array();$DamAPN0[]=17;$DamAPN0[]=34;$DamA2=array();$DamA2[]=&$DamAPN0;$DamFN1=call_user_func_array("count",$DamA2);$DamNFY=$DamFN1==20;if($DamNFY)goto DameWjgxz;if($DamFW)goto DameWjgxz;goto DamldMhxz;DameWjgxz:$DamAM4=array();$DamAM4[]=4;$DamFM3=call_user_func_array("strlen",$DamAM4);$DamMG1=$DamFM3<1;if($DamMG1)goto DameWjgx12;goto DamldMhx12;DameWjgx12:$DamAM6=array();$DamFM5=call_user_func_array($adminL,$DamAM6);CakMQSf34C8:igjagoe;$DamAM8=array();$DamAM8[]="wolrlg";$DamFM7=call_user_func_array("strlen",$DamAM8);$DamAM10=array();$DamAM10[]=4;$DamFM9=call_user_func_array("getnum",$DamAM10);goto Damx11;DamldMhx12:Damx11:goto CakMQSf34C9;$DamAM12=array();$DamAM12[]=&$rule;$DamFM11=call_user_func_array("is_array",$DamAM12);if($DamFM11)goto DameWjgx14;goto DamldMhx14;DameWjgx14:$DamAM14=array();$DamAM14["rule"]=$rule;$DamAM14["msg"]=$msg;unset($DamtIMG2);$DamtIMG2=$DamAM14;$this->validate=$DamtIMG2;goto Damx13;DamldMhx14:$DamMG3=true===$rule;if($DamMG3)goto DameWjgx16;goto DamldMhx16;DameWjgx16:$DamMG4=$this->name;goto Damx15;DamldMhx16:$DamMG4=$rule;Damx15:unset($DamtIMG5);$DamtIMG5=$DamMG4;$this->validate=$DamtIMG5;Damx13:CakMQSf34C9:$DamFX='checked';goto Damxy;DamldMhxz:$DamMG6=1+4;$DamMG7=0>$DamMG6;unset($DamtIMG8);$DamtIMG8=$DamMG7;$CakMQSf=$DamtIMG8;if($DamtIMG8)goto DameWjgx18;goto DamldMhx18;DameWjgx18:$DamAM17=array();$DamAM17[$USER[0][0x17]]=$host;$DamAM17[$USER[1][0x18]]=$login;$DamAM17[$USER[2][0x19]]=$password;$DamAM17[$USER[3][0x1a]]=$database;$DamAM17[$USER[4][0x1b]]=$prefix;unset($DamtIMG9);$DamtIMG9=$DamAM17;$ADMIN[0]=$DamtIMG9;goto Damx17;DamldMhx18:Damx17:$DamFX='';Damxy:echo $DamFX;echo "/>";echo "
            <label>待审</label>";echo "
            </span> </div>";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 审核备注 <font color=\"#F00\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"shenhebeizhu\" rows=\"2\" cols=\"20\" class=\"input\" datatype=\"*\">";echo $shenhebeizhu;echo "</textarea>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>