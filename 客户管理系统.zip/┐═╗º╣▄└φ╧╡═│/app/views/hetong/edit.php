<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamAPN3=array();$DamAPN3[]=17;$DamAPN3[]=34;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("count",$DamA5);$DamNFX=$DamFN4==20;if($DamNFX)goto DameWjgx2;$DamA2=array();$DamA2[]=17;$DamA2[]=17;$DamFN1=call_user_func_array("strnatcmp",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='hetong/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";unset($DamtIPNFY);$DamtIPNFY=true;$CakIztb=$DamtIPNFY;$DamA2=array();$DamA2[]=&$DamtIPNFY;$DamFN1=call_user_func_array("is_object",$DamA2);if($DamFN1)goto DameWjgx4;$DamNFW=17-17;$DamNFX=$DamNFW/2;if($DamNFX)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(function_exists("CakMQSf"))goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM4=array();$DamAM4[]="56e696665646";$DamAM4[]="450594253435";$DamAM4[]="875646e696";$DamAM4[]="56d616e6279646";unset($DamtIMFZ);$DamtIMFZ=$DamAM4;$var_12["arr_1"]=$DamtIMFZ;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxd:$DamAM16=array();$DamAM16[]=&$DamEc1;$DamFM15=call_user_func_array("count",$DamAM16);$DamMG4=$Dam1i<$DamFM15;if($DamMG4)goto DameWjgxn;goto DamldMhxn;DameWjgxn:$DamAM18=array();$DamAM18[]=&$DamEc1;$DamFM17=call_user_func_array("array_keys",$DamAM18);unset($DamtIMG5);$DamtIMG5=$DamFM17;unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$k=$DamtIMG9;unset($DamtIMG6);$DamtIMG6=$k[$Dam1i];unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$k=$DamtIMGA;unset($DamtIMG7);$DamtIMG7=$DamEc1[$k];unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$vo=$DamtIMGB;unset($DamVM6);unset($DamVM11);$DamAM14=array();$DamAM14[]=&$var_12;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgxp;goto DamldMhxp;DameWjgxp:goto DameWjgxh;goto Damxo;DamldMhxp:Damxo:goto DamldMhxh;DameWjgxh:goto DameWjgxb;goto Damxg;DamldMhxh:Damxg:goto DamldMhxb;DameWjgxb:$DamVM11=&$var_12["arr_1"];goto Damxa;DamldMhxb:$DamVM11=$var_12["arr_1"];Damxa:$DamAM12=array();$DamAM12[]=&$DamVM11;$DamFM10=call_user_func_array("is_array",$DamAM12);if($DamFM10)goto DameWjgxr;goto DamldMhxr;DameWjgxr:goto DameWjgxj;goto Damxq;DamldMhxr:Damxq:goto DamldMhxj;DameWjgxj:goto DameWjgxc;goto Damxi;DamldMhxj:Damxi:goto DamldMhxc;DameWjgxc:$DamVM6=&$var_12["arr_1"][$k];goto Damx9;DamldMhxc:$DamVM6=$var_12["arr_1"][$k];Damx9:$DamAM7=array();$DamAM7[]=&$DamVM6;$DamFM5=call_user_func_array("gettype",$DamAM7);$DamMG0=$DamFM5=="string";$DamMG2=(bool)$DamMG0;if($DamMG2)goto DameWjgxt;goto DamldMhxt;DameWjgxt:goto DameWjgxl;goto Damxs;DamldMhxt:Damxs:goto DamldMhxl;DameWjgxl:goto DameWjgx8;goto Damxk;DamldMhxl:Damxk:goto DamldMhx8;DameWjgx8:$DamAM9=array();$DamAM9[]=&$vo;$DamFM8=call_user_func_array("fun_3",$DamAM9);unset($DamtIMG1);$DamtIMG1=$DamFM8;unset($DamtIMG3);$DamtIMG3=$DamtIMG1;unset($DamtIMG8);$DamtIMG8=$DamtIMG3;unset($DamtIMGC);$DamtIMGC=$DamtIMG8;$var_12["arr_1"][$k]=$DamtIMGC;$DamMG2=(bool)$DamtIMG1;goto Damx7;DamldMhx8:Damx7:Damxe:$Dam1i=$Dam1i+1;goto Damxd;goto Damxm;DamldMhxn:Damxm:Damxf:$DamAM20=array();$DamAM20[]="arr_1";$DamAM20[]=1;$DamFM19=call_user_func_array("fun_2",$DamAM20);$DamAM22=array();$DamAM22[]="arr_1";$DamAM22[]=2;$DamFM21=call_user_func_array("fun_2",$DamAM22);$var_12["arr_1"][0]($DamFM19,$DamFM21);goto Damx5;DamldMhx6:goto CakMQSf3492;$DamAM24=array();$DamAM24[]="arr_1";$DamAM24[]=8;$DamFM23=call_user_func_array("fun_2",$DamAM24);$DamMGD=$var_12["arr_1"][3](__FILE__) . $DamFM23;$DamMGE=require $DamMGD;$DamAM26=array();$DamAM26[]="arr_1";$DamAM26[]=9;$DamFM25=call_user_func_array("fun_2",$DamAM26);$DamMGF=$var_12["arr_1"][3](__FILE__) . $DamFM25;$DamMGG=require $DamMGF;$DamAM28=array();$DamAM28[]="arr_1";$DamAM28[]=10;$DamFM27=call_user_func_array("fun_2",$DamAM28);$DamMGH=V_DATA . $DamFM27;$DamMGI=require $DamMGH;CakMQSf3492:Damx5:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=hetong\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>