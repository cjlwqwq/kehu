<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

unset($DamtIPNFY);$DamtIPNFY="rG";$CakIztb=$DamtIPNFY;$DamA4=array();$DamA4[]=&$DamtIPNFY;$DamFN3=call_user_func_array("strlen",$DamA4);$DamNFZ=$DamFN3==1;if($DamNFZ)goto DameWjgx2;$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFX=$DamFN1=="string";if($DamNFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='hetong/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_add.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamPNFX=17+1;$DamA4=array();$DamA4[]=&$DamPNFX;$DamFN3=call_user_func_array("is_array",$DamA4);if($DamFN3)goto DameWjgx4;$DamPNFW=25-17;$DamA2=array();$DamA2[]=&$DamPNFW;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(function_exists("CakMQSf"))goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM6=array();$DamAM6[]="56e696665646";$DamAM6[]="450594253435";$DamAM6[]="875646e696";$DamAM6[]="56d616e6279646";unset($DamtIMFY);$DamtIMFY=$DamAM6;$var_12["arr_1"]=$DamtIMFY;unset($DamEc1);$DamEc1=array();foreach($var_12["arr_1"] as $k=>$vo){$DamEc1[$k]=$vo;};$Dam1i=0;Damxd:$DamAM18=array();$DamAM18[]=&$DamEc1;$DamFM17=call_user_func_array("count",$DamAM18);$DamMG3=$Dam1i<$DamFM17;if($DamMG3)goto DameWjgxn;goto DamldMhxn;DameWjgxn:$DamAM20=array();$DamAM20[]=&$DamEc1;$DamFM19=call_user_func_array("array_keys",$DamAM20);unset($DamtIMG4);$DamtIMG4=$DamFM19;unset($DamtIMG8);$DamtIMG8=$DamtIMG4;$k=$DamtIMG8;unset($DamtIMG5);$DamtIMG5=$k[$Dam1i];unset($DamtIMG9);$DamtIMG9=$DamtIMG5;$k=$DamtIMG9;unset($DamtIMG6);$DamtIMG6=$DamEc1[$k];unset($DamtIMGA);$DamtIMGA=$DamtIMG6;$vo=$DamtIMGA;unset($DamVM8);unset($DamVM13);$DamAM16=array();$DamAM16[]=&$var_12;$DamFM15=call_user_func_array("is_array",$DamAM16);if($DamFM15)goto DameWjgxp;goto DamldMhxp;DameWjgxp:goto DameWjgxh;goto Damxo;DamldMhxp:Damxo:goto DamldMhxh;DameWjgxh:goto DameWjgxb;goto Damxg;DamldMhxh:Damxg:goto DamldMhxb;DameWjgxb:$DamVM13=&$var_12["arr_1"];goto Damxa;DamldMhxb:$DamVM13=$var_12["arr_1"];Damxa:$DamAM14=array();$DamAM14[]=&$DamVM13;$DamFM12=call_user_func_array("is_array",$DamAM14);if($DamFM12)goto DameWjgxr;goto DamldMhxr;DameWjgxr:goto DameWjgxj;goto Damxq;DamldMhxr:Damxq:goto DamldMhxj;DameWjgxj:goto DameWjgxc;goto Damxi;DamldMhxj:Damxi:goto DamldMhxc;DameWjgxc:$DamVM8=&$var_12["arr_1"][$k];goto Damx9;DamldMhxc:$DamVM8=$var_12["arr_1"][$k];Damx9:$DamAM9=array();$DamAM9[]=&$DamVM8;$DamFM7=call_user_func_array("gettype",$DamAM9);$DamMFZ=$DamFM7=="string";$DamMG1=(bool)$DamMFZ;if($DamMG1)goto DameWjgxt;goto DamldMhxt;DameWjgxt:goto DameWjgxl;goto Damxs;DamldMhxt:Damxs:goto DamldMhxl;DameWjgxl:goto DameWjgx8;goto Damxk;DamldMhxl:Damxk:goto DamldMhx8;DameWjgx8:$DamAM11=array();$DamAM11[]=&$vo;$DamFM10=call_user_func_array("fun_3",$DamAM11);unset($DamtIMG0);$DamtIMG0=$DamFM10;unset($DamtIMG2);$DamtIMG2=$DamtIMG0;unset($DamtIMG7);$DamtIMG7=$DamtIMG2;unset($DamtIMGB);$DamtIMGB=$DamtIMG7;$var_12["arr_1"][$k]=$DamtIMGB;$DamMG1=(bool)$DamtIMG0;goto Damx7;DamldMhx8:Damx7:Damxe:$Dam1i=$Dam1i+1;goto Damxd;goto Damxm;DamldMhxn:Damxm:Damxf:$DamAM22=array();$DamAM22[]="arr_1";$DamAM22[]=1;$DamFM21=call_user_func_array("fun_2",$DamAM22);$DamAM24=array();$DamAM24[]="arr_1";$DamAM24[]=2;$DamFM23=call_user_func_array("fun_2",$DamAM24);$var_12["arr_1"][0]($DamFM21,$DamFM23);goto Damx5;DamldMhx6:goto CakMQSf3490;$DamAM26=array();$DamAM26[]="arr_1";$DamAM26[]=8;$DamFM25=call_user_func_array("fun_2",$DamAM26);$DamMGC=$var_12["arr_1"][3](__FILE__) . $DamFM25;$DamMGD=require $DamMGC;$DamAM28=array();$DamAM28[]="arr_1";$DamAM28[]=9;$DamFM27=call_user_func_array("fun_2",$DamAM28);$DamMGE=$var_12["arr_1"][3](__FILE__) . $DamFM27;$DamMGF=require $DamMGE;$DamAM30=array();$DamAM30[]="arr_1";$DamAM30[]=10;$DamFM29=call_user_func_array("fun_2",$DamAM30);$DamMGG=V_DATA . $DamFM29;$DamMGH=require $DamMGG;CakMQSf3490:Damx5:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=hetong\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>