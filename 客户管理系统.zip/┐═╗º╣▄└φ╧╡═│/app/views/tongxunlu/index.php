<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamPNFX=17-1;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_null",$DamA2);if($DamFN1)goto DameWjgx2;$DamPNFY="SxJ"==__LINE__;unset($DamtIPNFZ);$DamtIPNFZ=$DamPNFY;$CakIztb=$DamtIPNFZ;$DamA4=array();$DamA4[]=&$DamtIPNFZ;$DamFN3=call_user_func_array("strrev",$DamA4);if($DamFN3)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>内部通讯录</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"toolbar\">";echo "
    <div class=\"l-list\">";echo "
      <ul class=\"icon-list\">";echo "
        <li><a class=\"btn2 hover\" href=\"?\"><i class=\"fa fa-file-text-o\"></i>内部通讯录</a></li>";echo "
        <span id=\"timo1\">";echo "
        <li class=\"btn-sou-ks\">";echo "
          <form name=\"searchForm\" action=\"?saction=ssdetail\" method=\"post\">";echo "
            <input name=\"keyword\" type=\"text\" value=\"";echo $keyword;echo "\" class=\"input input-sou1\" placeholder=\"姓名、手机号\">";echo "
            <label class=\"btn2 btn-sou-ks2 btn2\">";echo "
              <input type=\"submit\" name=\"Submit\" value=\"\" />";echo "
              <i class=\"fa fa-search\"></i>搜索 </label>";echo "
          </form>";echo "
        </li>";echo "
        </span>";echo "
      </ul>";echo "
    </div>";echo "
    <div class=\"clear\"></div>";echo "
  </div>";echo "
  <!--/工具栏-->";echo "
  ";echo "
  <div class=\"table-container\">";echo "
    <div class=\"table-list\">";echo "
      <table class=\"table tree_table\">";echo "
        <thead>";echo "
          <tr class=\"\">";echo "
            <th width=\"60\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"uid\" paixu=\"\">编号 </a></th>";echo "
            <th width=\"100\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"groupname\" paixu=\"\"> 部门 </a></th>";echo "
            <th width=\"100\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"name\" paixu=\"\"> 姓名 </a></th>";echo "
            <th width=\"100\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"mobile\" paixu=\"\"> 手机号码 </a></th>";echo "
            <th width=\"100\" class=\"td_c bhh\"><a class=\"paixu\" ziduan=\"email\" paixu=\"\"> 电子邮箱 </a></th>";echo "
            <th width=\"60\" class=\"td_c bhh\">操作</th>";echo "
          </tr>";echo "
        </thead>";echo "
        ";$DamA3=array();$DamA3[]="hBVdO";$DamA3[]=26;$DamFN2=call_user_func_array("substr",$DamA3);if($DamFN2)goto DameWjgx4;$DamA5=array();$DamA5[]="JrCIziGY";$DamFN4=call_user_func_array("base64_decode",$DamA5);$DamNFX=$DamFN4=="ciNntTOd";if($DamNFX)goto DameWjgx4;$DamA1=array();$DamA1[]=&$list;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx4;goto DamldMhx4;DameWjgx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf38C4;$DamAM8=array();$DamAM8[]=&$rules;$DamFM7=call_user_func_array("is_array",$DamAM8);if($DamFM7)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf38C4:goto Damx5;DamldMhx6:goto CakMQSf38C6;$DamMFY=$path . EXT;$DamAM10=array();$DamAM10[]=&$DamMFY;$DamFM9=call_user_func_array("is_file",$DamAM10);if($DamFM9)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMFZ=$path . EXT;$DamMG0=include $DamMFZ;goto Damx9;DamldMhxa:Damx9:CakMQSf38C6:Damx5:unset($DamEc1);$DamEc1=array();foreach($list as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxb:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;if($DamFW)goto DameWjgxf;$DamNFW=17+1;$DamNFX=17==$DamNFW;if($DamNFX)goto DameWjgxf;$DamA1=array();$DamA1[]=null;$DamFN0=call_user_func_array("is_object",$DamA1);if($DamFN0)goto DameWjgxf;goto DamldMhxf;DameWjgxf:$DamMFY=1*0;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$CakMQSf=$DamtIMFZ;$DamlFkgHhxg=$CakMQSf;$DamMG0=$DamlFkgHhxg==1;if($DamMG0)goto DameWjgxp;goto DamldMhxp;DameWjgxp:goto DamcgFhxh;goto Damxo;DamldMhxp:Damxo:$DamMG1=$DamlFkgHhxg==2;if($DamMG1)goto DameWjgxn;goto DamldMhxn;DameWjgxn:goto DamcgFhxi;goto Damxm;DamldMhxn:Damxm:$DamMG2=$DamlFkgHhxg==3;if($DamMG2)goto DameWjgxl;goto DamldMhxl;DameWjgxl:goto DamcgFhxj;goto Damxk;DamldMhxl:Damxk:goto Damxg;DamcgFhxh:$DamAM3=array();$DamAM3[]=&$url;$DamAM3[]=&$bind;$DamAM3[]=&$depr;$DamFM2=call_user_func_array("bClass",$DamAM3);return $DamFM2;DamcgFhxi:$DamAM5=array();$DamAM5[]=&$url;$DamAM5[]=&$bind;$DamAM5[]=&$depr;$DamFM4=call_user_func_array("bController",$DamAM5);return $DamFM4;DamcgFhxj:$DamAM7=array();$DamAM7[]=&$url;$DamAM7[]=&$bind;$DamAM7[]=&$depr;$DamFM6=call_user_func_array("bNamespace",$DamAM7);return $DamFM6;Damxg:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;unset($DamtIG3);$DamtIG3=$DamtIFW;$arr=$DamtIG3;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];unset($DamtIG4);$DamtIG4=$DamtIFW;$arr=$DamtIG4;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];unset($DamtIG5);$DamtIG5=$DamtIFW;$row=$DamtIG5;echo "        <tbody>";echo "
          <tr class=\"tr\">";echo "
            <td class=\"td_c bhh\">";echo $row['uid'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['groupname'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['realname'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['mobile'];echo "</td>";echo "
            <td class=\"td_c bhh\">";echo $row['email'];echo "</td>";echo "
            <td class=\"td_c bhh\">-</td>";echo "
          </tr>";echo "
        </tbody>";echo "
        ";Damxc:$Dam1i=$Dam1i+1;goto Damxb;goto Damxe;DamldMhxf:Damxe:Damxd:goto Damx3;DamldMhx4:unset($DamtIMG6);$DamtIMG6="login";$CakMQSf=$DamtIMG6;$DamlFkgHhxq=$DamtIMG6;$DamMG7=$DamlFkgHhxq=="admin";if($DamMG7)goto DameWjgxy;goto DamldMhxy;DameWjgxy:goto DamcgFhxr;goto Damxx;DamldMhxy:Damxx:$DamMGA=$DamlFkgHhxq=="user";if($DamMGA)goto DameWjgxw;goto DamldMhxw;DameWjgxw:goto DamcgFhxs;goto Damxv;DamldMhxw:Damxv:goto Damxq;DamcgFhxr:$DamAM9=array();$DamAM9[]=&$depr;$DamAM9[]="|";$DamAM9[]=&$url;$DamFM8=call_user_func_array("str_replace",$DamAM9);unset($DamtIMG8);$DamtIMG8=$DamFM8;$url=$DamtIMG8;$DamAM11=array();$DamAM11[]="|";$DamAM11[]=&$url;$DamAM11[]=2;$DamFM10=call_user_func_array("explode",$DamAM11);unset($DamtIMG9);$DamtIMG9=$DamFM10;$array=$DamtIMG9;DamcgFhxs:$DamAM13=array();$DamAM13[]=&$url;$DamFM12=call_user_func_array("parse_url",$DamAM13);unset($DamtIMGB);$DamtIMGB=$DamFM12;$info=$DamtIMGB;unset($DamVM15);$DamAM18=array();$DamAM18[]=&$info;$DamFM17=call_user_func_array("is_array",$DamAM18);if($DamFM17)goto DameWjgxu;goto DamldMhxu;DameWjgxu:$DamVM15=&$info["path"];goto Damxt;DamldMhxu:$DamVM15=$info["path"];Damxt:$DamAM16=array();$DamAM16[]="/";$DamAM16[]=&$DamVM15;$DamFM14=call_user_func_array("explode",$DamAM16);unset($DamtIMGC);$DamtIMGC=$DamFM14;$path=$DamtIMGC;Damxq:echo "        <tfoot>";echo "
          <tr>";echo "
            <td class=\"td_c nodata\" colspan=\"50\"> 抱歉，暂无相关记录！ </td>";echo "
          </tr>";echo "
        </tfoot>";echo "
        ";Damx3:echo "      </table>";echo "
    </div>";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"b-toolbar\">";echo "
      <div class=\"inner\"> ";echo "
        ";echo "
        <!--分页代码开始-->";echo "
        ";$this->load->view('common/inc_pages.php');echo "        <!--分页代码结束--> ";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏--> ";echo "
    ";echo "
  </div>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script>";echo "
//底部菜单选中";echo "
\$(\".footnav li a\").each(function(){";echo "
   if(\$(this).text()=='通讯录'){";echo "
	\$(this).addClass(\"on\");";echo "
   }";echo "
});";echo "
</script>";echo "
</body>";echo "
</html>";
?>