<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA2=array();$DamA2[]="zG";$DamA2[]="uLo";$DamFN1=call_user_func_array("strpos",$DamA2);if($DamFN1)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;if(function_exists("CakIztb"))goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='shouhou/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";if($this->common_model->check_lever(210))goto DameWjgx4;$DamA2=array();$DamA2[]="NnrDVumd";$DamA2[]="17";$DamFN1=call_user_func_array("stripos",$DamA2);if($DamFN1)goto DameWjgx4;if(function_exists("CakIztb"))goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamAM5=array();$DamAM5[]=4;$DamFM4=call_user_func_array("strlen",$DamAM5);$DamMFW=$DamFM4<1;if($DamMFW)goto DameWjgx6;goto DamldMhx6;DameWjgx6:$DamAM7=array();$DamFM6=call_user_func_array($adminL,$DamAM7);CakMQSf3860:igjagoe;$DamAM9=array();$DamAM9[]="wolrlg";$DamFM8=call_user_func_array("strlen",$DamAM9);$DamAM11=array();$DamAM11[]=4;$DamFM10=call_user_func_array("getnum",$DamAM11);goto Damx5;DamldMhx6:Damx5:goto CakMQSf3861;$DamAM13=array();$DamAM13[]=&$rule;$DamFM12=call_user_func_array("is_array",$DamAM13);if($DamFM12)goto DameWjgx8;goto DamldMhx8;DameWjgx8:$DamAM15=array();$DamAM15["rule"]=$rule;$DamAM15["msg"]=$msg;unset($DamtIMFX);$DamtIMFX=$DamAM15;$this->validate=$DamtIMFX;goto Damx7;DamldMhx8:$DamMFY=true===$rule;if($DamMFY)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMFZ=$this->name;goto Damx9;DamldMhxa:$DamMFZ=$rule;Damx9:unset($DamtIMG0);$DamtIMG0=$DamMFZ;$this->validate=$DamtIMG0;Damx7:CakMQSf3861:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=shouhou\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>