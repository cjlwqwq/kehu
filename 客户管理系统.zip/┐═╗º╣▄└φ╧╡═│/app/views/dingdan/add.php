<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamPNFX=25-17;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamNFY=17-17;$DamNFZ=$DamNFY/2;if($DamNFZ)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='dingdan/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_add.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamPNFW=17+1;$DamA2=array();$DamA2[]=&$DamPNFW;$DamFN1=call_user_func_array("is_array",$DamA2);if($DamFN1)goto DameWjgx4;$DamAPN3=array();$DamAPN3[]=17;$DamAPN3[]=34;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("count",$DamA5);$DamNFX=$DamFN4==20;if($DamNFX)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:$DamMFY=1*0;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;$CakMQSf=$DamtIMFZ;$DamlFkgHhx5=$CakMQSf;$DamMG0=$DamlFkgHhx5==1;if($DamMG0)goto DameWjgxe;goto DamldMhxe;DameWjgxe:goto DamcgFhx6;goto Damxd;DamldMhxe:Damxd:$DamMG1=$DamlFkgHhx5==2;if($DamMG1)goto DameWjgxc;goto DamldMhxc;DameWjgxc:goto DamcgFhx7;goto Damxb;DamldMhxc:Damxb:$DamMG2=$DamlFkgHhx5==3;if($DamMG2)goto DameWjgxa;goto DamldMhxa;DameWjgxa:goto DamcgFhx8;goto Damx9;DamldMhxa:Damx9:goto Damx5;DamcgFhx6:$DamAM7=array();$DamAM7[]=&$url;$DamAM7[]=&$bind;$DamAM7[]=&$depr;$DamFM6=call_user_func_array("bClass",$DamAM7);return $DamFM6;DamcgFhx7:$DamAM9=array();$DamAM9[]=&$url;$DamAM9[]=&$bind;$DamAM9[]=&$depr;$DamFM8=call_user_func_array("bController",$DamAM9);return $DamFM8;DamcgFhx8:$DamAM11=array();$DamAM11[]=&$url;$DamAM11[]=&$bind;$DamAM11[]=&$depr;$DamFM10=call_user_func_array("bNamespace",$DamAM11);return $DamFM10;Damx5:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA13=array();$DamA13[]='ziduan/index';$DamF12=call_user_func_array("site_url",$DamA13);echo $DamF12;echo "?style=1&type=dingdan\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>