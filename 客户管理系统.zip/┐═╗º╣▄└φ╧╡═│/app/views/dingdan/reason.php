<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("strlen",$DamA2);$DamNFX=0==$DamFN1;if($DamNFX)goto DameWjgx2;$DamAPN3=array();$DamAPN3[]=17;$DamAPN3[]=34;$DamA5=array();$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("count",$DamA5);$DamNFY=$DamFN4==20;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<title>新增客户</title>";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  ";unset($DamtIFW);$DamtIFW=$this->input->get('id');$id=$DamtIFW;echo "  <form name=\"Add\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='dingdan/dels';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl style=\"display:none;\">";echo "
        <dt>客户编号 <font color=\"#F00\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $id;echo "          <input type=\"hidden\" name=\"id\" value=\"";echo $id;echo "\">";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 删除原因 <font color=\"#F00\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"reason\" rows=\"2\" cols=\"20\" class=\"input\" datatype=\"*\" ></textarea>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"确认删除\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>