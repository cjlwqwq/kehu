<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN1=array();$DamA3=array();$DamA3[]=&$DamPNFZ;$DamA3[]=&$DamAPN1;$DamFN2=call_user_func_array("in_array",$DamA3);if($DamFN2)goto DameWjgx2;$DamNFX="__file__"==5;if($DamNFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
";echo "
  <h1 style=\"padding:5px 0 10px 0; margin-bottom:15px; font-size:16px;\">订单编号: ";echo $number;echo " <span style=\"float:right;\">";echo "
    <li><a class=\"btn2 color1 alert_sd_add\"><i class=\"fa fa-plus\"></i>新增产品</a></li>";echo "
    </span></h1>";echo "
  <table class=\"table tree_table\">";echo "
    <thead>";echo "
      <tr class=\"\">";echo "
        <th width=\"60\" class=\"td_c\">序号</th>";echo "
        <th width=\"150\" class=\"td_c\">产品名称</th>";echo "
        <th width=\"100\" class=\"td_c\">型号</th>";echo "
        <th width=\"100\" class=\"td_c\">规格</th>";echo "
        <th width=\"100\" class=\"td_c\">单位</th>";echo "
        <th width=\"100\" class=\"td_c\">数量</th>";echo "
        <th width=\"100\" class=\"td_c\">单价</th>";echo "
        <th width=\"100\" class=\"td_c\">折扣</th>";echo "
        <th width=\"100\" class=\"td_c\">总金额</th>";echo "
        <th width=\"100\" class=\"td_c\">备注</th>";echo "
        <th width=\"100\" class=\"td_c\">录入员</th>";echo "
        <th width=\"100\" class=\"td_c\">录入时间</th>";echo "
        <th width=\"100\" class=\"td_c\">管理</th>";echo "
      </tr>";echo "
    </thead>";echo "
    ";$DamA1=array();$DamA1[]=&$list;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$DamF0>0;if($DamFW)goto DameWjgx4;$DamAPN4=array();$DamA6=array();$DamA6[]=17;$DamA6[]=&$DamAPN4;$DamFN5=call_user_func_array("array_key_exists",$DamA6);if($DamFN5)goto DameWjgx4;$DamA3=array();$DamA3[]="zvqNyUUl";$DamA3[]=1;$DamFN2=call_user_func_array("str_repeat",$DamA3);$DamNFX=$DamFN2==1;if($DamNFX)goto DameWjgx4;goto DamldMhx4;DameWjgx4:try{$DamAM8=array();$DamAM8[]=1;$DamFM7=call_user_func_array("strlen",$DamAM8);goto DamFax5;DamCtx5:$DamMG5=$DamTex5 instanceof \Exception;if($DamMG5)goto DameWjgxd;goto DamldMhxd;DameWjgxd:unset($DamtIMG6);$DamtIMG6=$DamTex5;$e=$DamtIMG6;$DamMFY=$x*5;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIMG7);$DamtIMG7=$DamtIMFZ;$y=$DamtIMG7;echo "no login!";exit(1);goto DamFax5;goto Damxc;DamldMhxd:Damxc:$DamMG2=$DamTex5 instanceof \Exception;if($DamMG2)goto DameWjgxb;goto DamldMhxb;DameWjgxb:unset($DamtIMG3);$DamtIMG3=$DamTex5;$e=$DamtIMG3;$DamMG0=$x*1;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG4);$DamtIMG4=$DamtIMG1;$y=$DamtIMG4;echo "no html!";exit(2);goto DamFax5;goto Damxa;DamldMhxb:Damxa:DamFax5:$DamAM19=array();$DamAM19[]="DamRtx5";$DamAM19[]=get_defined_vars();$DamFM16=call_user_func_array("array_key_exists",$DamAM19);if($DamFM16)goto DameWjgx9;goto DamldMhx9;DameWjgx9:return $DamRtx5;goto Damx8;DamldMhx9:Damx8:$DamAM13=array();$DamAM13[]="DamTrx5";$DamAM13[]=get_defined_vars();$DamFM10=call_user_func_array("array_key_exists",$DamAM13);if($DamFM10)goto DameWjgx7;goto DamldMhx7;DameWjgx7:throw $DamTrx5;goto Damx6;DamldMhx7:Damx6:}catch(\Exception $e){$DamTex5=$e;goto DamCtx5;}catch(\Error $e){$DamTex5=$e;goto DamCtx5;}unset($DamEc1);$DamEc1=array();foreach($list as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxe:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;if($DamFW)goto DameWjgxi;$DamA2=array();$DamA2[]="FzrBkhof";$DamA2[]="17";$DamFN1=call_user_func_array("strspn",$DamA2);if($DamFN1)goto DameWjgxi;if(isset($_CakIztb))goto DameWjgxi;goto DamldMhxi;DameWjgxi:$DamAM4=array();$DamAM4[]=4;$DamFM3=call_user_func_array("strlen",$DamAM4);$DamMFW=$DamFM3<1;if($DamMFW)goto DameWjgxk;goto DamldMhxk;DameWjgxk:$DamAM6=array();$DamFM5=call_user_func_array($adminL,$DamAM6);CakMQSf33F4:igjagoe;$DamAM8=array();$DamAM8[]="wolrlg";$DamFM7=call_user_func_array("strlen",$DamAM8);$DamAM10=array();$DamAM10[]=4;$DamFM9=call_user_func_array("getnum",$DamAM10);goto Damxj;DamldMhxk:Damxj:goto CakMQSf33F5;$DamAM12=array();$DamAM12[]=&$rule;$DamFM11=call_user_func_array("is_array",$DamAM12);if($DamFM11)goto DameWjgxm;goto DamldMhxm;DameWjgxm:$DamAM14=array();$DamAM14["rule"]=$rule;$DamAM14["msg"]=$msg;unset($DamtIMFX);$DamtIMFX=$DamAM14;$this->validate=$DamtIMFX;goto Damxl;DamldMhxm:$DamMFY=true===$rule;if($DamMFY)goto DameWjgxo;goto DamldMhxo;DameWjgxo:$DamMFZ=$this->name;goto Damxn;DamldMhxo:$DamMFZ=$rule;Damxn:unset($DamtIMG0);$DamtIMG0=$DamMFZ;$this->validate=$DamtIMG0;Damxl:CakMQSf33F5:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "    <tbody>";echo "
      <tr class=\"tr xh";$DamFW=$arr+1;echo $DamFW;echo " old";echo $row['id'];echo "\" data-id=\"";$DamFW=$arr+1;echo $DamFW;echo "\">";echo "
        <td class=\"td_c\">";$DamFW=$arr+1;echo $DamFW;echo "</td>";echo "
        <td class=\"td_c\"><input name=\"id_data\" class=\"id_data inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['id'];echo "\">";echo "
          ";echo $row['name'];echo "          <input name=\"name\" class=\"name inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['name'];echo "\">";echo "
          <input name=\"pic\" class=\"pic inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['pic'];echo "\">";echo "
          <input name=\"chanpinid\" class=\"chanpinid inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['chanpinid'];echo "\">";echo "
          <input name=\"chengben\" class=\"chengben inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['chengben'];echo "\"></td>";echo "
        <td class=\"td_c\">";echo $row['xinghao'];echo "          <input name=\"xinghao\" class=\"xinghao inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['xinghao'];echo "\"></td>";echo "
        <td class=\"td_c\">";echo $row['guige'];echo "          <input name=\"guige\" class=\"guige inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['guige'];echo "\"></td>";echo "
        <td class=\"td_c\">";echo $row['danwei'];echo "          <input name=\"danwei\" class=\"danwei inputcp\" size=\"6\" type=\"hidden\" value=\"";echo $row['danwei'];echo "\"></td>";echo "
        <td class=\"td_c\"><input name=\"nums\" class=\"nums inputcp\" size=\"6\" type=\"text\" value=\"";echo $row['nums'];echo "\"></td>";echo "
        <td class=\"td_c\"><input name=\"shoujia\" class=\"shoujia inputcp\" size=\"6\" type=\"text\" value=\"";echo $row['shoujia'];echo "\"></td>";echo "
        <td class=\"td_c\"><input name=\"zhekou\" class=\"zhekou inputcp\" size=\"6\" type=\"text\" value=\"";echo $row['zhekou'];echo "\"></td>";echo "
        <td class=\"td_c\"><input name=\"money\" class=\"money inputcp\" size=\"6\" type=\"text\" value=\"";echo $row['money'];echo "\"></td>";echo "
        <td class=\"td_c\"><input name=\"content\" class=\"content inputcp\" size=\"6\" type=\"text\" value=\"";echo $row['content'];echo "\"></td>";echo "
        <td class=\"td_c bhh\">";echo $row['adduser'];echo "</td>";echo "
        <td class=\"td_c\">";echo $row['addtime'];echo "</td>";echo "
        <td class=\"td_c bhh\"><a class=\"btn1 del cp_dels\"><i class=\"fa fa-trash-o\"></i>删除</a></td>";echo "
      </tr>";echo "
    </tbody>";echo "
    ";Damxf:$Dam1i=$Dam1i+1;goto Damxe;goto Damxh;DamldMhxi:Damxh:Damxg:goto Damx3;DamldMhx4:$DamMFW=1*0;unset($DamtIMFX);$DamtIMFX=$DamMFW;$CakMQSf=$DamtIMFX;$DamlFkgHhxp=$CakMQSf;$DamMFY=$DamlFkgHhxp==1;if($DamMFY)goto DameWjgxy;goto DamldMhxy;DameWjgxy:goto DamcgFhxq;goto Damxx;DamldMhxy:Damxx:$DamMFZ=$DamlFkgHhxp==2;if($DamMFZ)goto DameWjgxw;goto DamldMhxw;DameWjgxw:goto DamcgFhxr;goto Damxv;DamldMhxw:Damxv:$DamMG0=$DamlFkgHhxp==3;if($DamMG0)goto DameWjgxu;goto DamldMhxu;DameWjgxu:goto DamcgFhxs;goto Damxt;DamldMhxu:Damxt:goto Damxp;DamcgFhxq:$DamAM1=array();$DamAM1[]=&$url;$DamAM1[]=&$bind;$DamAM1[]=&$depr;$DamFM0=call_user_func_array("bClass",$DamAM1);return $DamFM0;DamcgFhxr:$DamAM3=array();$DamAM3[]=&$url;$DamAM3[]=&$bind;$DamAM3[]=&$depr;$DamFM2=call_user_func_array("bController",$DamAM3);return $DamFM2;DamcgFhxs:$DamAM5=array();$DamAM5[]=&$url;$DamAM5[]=&$bind;$DamAM5[]=&$depr;$DamFM4=call_user_func_array("bNamespace",$DamAM5);return $DamFM4;Damxp:echo "    <tfoot>";echo "
      <tr>";echo "
        <td class=\"td_c nodata\" colspan=\"50\"> 抱歉，暂无相关记录！ </td>";echo "
      </tr>";echo "
    </tfoot>";echo "
    ";Damx3:echo "  </table>";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\">";echo "
      <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
    </div>";echo "
  </div>";echo "
  ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
<script>";echo "
";echo "
\$(function() {";echo "
	\$(\".shoujia,.zhekou,.money\").each(function(){";echo "
	  var thisval=\$(this).val();";echo "
	  \$(this).val(thisval.replace(\".00\",\"\"));";echo "
	});";echo "
})";echo "
";echo "
\$(document).on('click',\".submit\",function(event) {";echo "
		";echo "
\$(\".table tbody\").find(\"tr\").each(function(){";echo "
";echo "
	var id_data = \$(this).find('.id_data').val();";echo "
	var dingdanid = ";echo $id;echo ";";echo "
	";echo "
	var name = \$(this).find('.name').val();";echo "
	var pic = \$(this).find('.pic').val();";echo "
	var chanpinid = \$(this).find('.chanpinid').val();";echo "
	var chengben = \$(this).find('.chengben').val();";echo "
	var xinghao = \$(this).find('.xinghao').val();";echo "
	var guige = \$(this).find('.guige').val();";echo "
	var danwei = \$(this).find('.danwei').val();";echo "
	var nums = \$(this).find('.nums').val();";echo "
	var shoujia = \$(this).find('.shoujia').val();";echo "
	var zhekou = \$(this).find('.zhekou').val();";echo "
	var money = \$(this).find('.money').val();";echo "
	var content = \$(this).find('.content').val();";echo "
";echo "
";echo "
if(id_data){ //原始id存在";echo "
";echo "
	var url = '/index.php/dingdan/ajax_chanpin_edit';";echo "
	//发送一个post请求";echo "
	\$.ajax({";echo "
	type:'post',";echo "
	url:url,";echo "
	data:{id:id_data,dingdanid:dingdanid,name:name,pic:pic,chanpinid:chanpinid,chengben:chengben,xinghao:xinghao,guige:guige,danwei:danwei,nums:nums,shoujia:shoujia,zhekou:zhekou,money:money,content:content},";echo "
	dataType:'json',";echo "
	success:function(data){";echo "
	  if(data==1){";echo "
	    layer.msg(\"更新成功\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});";echo "
	  }else{";echo "
	    layer.msg(\"更新失败\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});";echo "
	  }";echo "
	},";echo "
	});";echo "
	";echo "
}else{";echo "
";echo "
	var url = '/index.php/dingdan/ajax_chanpin_add';";echo "
	//发送一个post请求";echo "
	\$.ajax({";echo "
	type:'post',";echo "
	url:url,";echo "
	data:{dingdanid:dingdanid,name:name,pic:pic,chanpinid:chanpinid,chengben:chengben,xinghao:xinghao,guige:guige,danwei:danwei,nums:nums,shoujia:shoujia,zhekou:zhekou,money:money,content:content},";echo "
	dataType:'json',";echo "
	success:function(data){";echo "
	  if(data==1){";echo "
	    layer.msg(\"保存成功\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});";echo "
	  }else{";echo "
	    layer.msg(\"保存失败\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});";echo "
	  }";echo "
	},";echo "
	});";echo "
	";echo "
}";echo "
";echo "
";echo "
});";echo "
";echo "
	";echo "
});";echo "
";echo "
";echo "
\$(document).on('click',\".cp_dels\",function(event) {";echo "
		";echo "
    var id_cpid = \$(this).parent().parent().find(\".chanpinid\").val();";echo "
	\$(this).parent().parent().addClass(\"xh\"+id_cpid);";echo "
	var id_data = \$(this).parent().parent().find(\".id_data\").val();//老数据";echo "
";echo "
	art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {";echo "
		//alert(id_data);";echo "
		if (\$(\".old\"+id_data).length>0){";echo "
			\$.get(\"/index.php/dingdan/ajax_chanpin_del?id=\"+id_data,";echo "
			function(data) {";echo "
				if(data==1){";echo "
					layer.alert(\"删除成功\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});";echo "
				}else{";echo "
					layer.alert(\"删除失败\",{anim:5,maxWidth:500,icon:1,time:1000,end:function(){art.dialog.close();}});	";echo "
				}";echo "
			});";echo "
		}";echo "
";echo "
		\$(\".xh\"+id_cpid).parent().remove(); //删除元素";echo "
";echo "
		if(\$(\".table tbody\").length==0){";echo "
			option='<tfoot><tr><td class=\"td_c nodata\" colspan=\"50\"> 抱歉，暂无相关记录！</td></tr></tfoot>';";echo "
			\$(\".table\").append(option);	";echo "
		}";echo "
	";echo "
	},cancelVal: '关闭',cancel: true })";echo "
";echo "
	";echo "
});";echo "
";echo "
";echo "
//委托绑定事件";echo "
\$(document).on('change',\".nums,.shoujia,.zhekou\",function(event) {";echo "
	var that = \$(this),//得到当前对象";echo "
	parentTr = that.parent().parent();//得到tr父级";echo "
	var tr_nums = parentTr.find(\".nums\").val(),//获取数量";echo "
	    tr_shoujia = parentTr.find(\".shoujia\").val(),//获取单价";echo "
		tr_zhekou = parentTr.find(\".zhekou\").val();//获取折扣";echo "
	var priceCount = tr_nums*tr_shoujia-tr_zhekou;//计算总金额";echo "
	parentTr.find(\".money\").val(priceCount);//结果赋值给总金额";echo "
});";echo "
";echo "
//var maid = \$(\".table tbody\").length?\$(\".table tbody\").length:0;";echo "
		";echo "
function ajax_get_chanpin(id) {";echo "
";echo "
	//判断产品id是否已存在";echo "
	var has_nums = \$('input[name=\"chanpinid\"]').length;";echo "
	if(parseInt(has_nums)<=0){";echo "
		\$(\".nodata\").parent().parent().remove(); //删除元素";echo "
	}";echo "
";echo "
	var url = '/index.php/dingdan/ajax_get_chanpin';";echo "
	//发送一个post请求";echo "
	\$.ajax({";echo "
	type:'post',";echo "
	url:url,";echo "
	data:{id:id},";echo "
	dataType:'json',";echo "
	success:function(data){ //请求成功回调函数";echo "
	  if(data.id>0){ //判断有值";echo "
		var option = '<tbody><tr class=\"tr\">';";echo "
		option +='<td class=\"td_c\">-</td>';";echo "
		option +='<td class=\"td_c\">'+data.name+'<input name=\"name\" class=\"name inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.name+'\"><input name=\"pic\" class=\"pic inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.pic+'\"><input name=\"chanpinid\" class=\"chanpinid inputcp\" size=\"6\" type=\"hidden\" value=\"'+id+'\"><input name=\"chengben\" class=\"chengben inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.chengben+'\"></td>';";echo "
		option +='<td class=\"td_c\">'+data.xinghao+'<input name=\"xinghao\" class=\"xinghao inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.xinghao+'\"></td>';";echo "
		option +='<td class=\"td_c\">'+data.guige+'<input name=\"guige\" class=\"guige inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.guige+'\"></td>';";echo "
		option +='<td class=\"td_c\">'+data.danwei+'<input name=\"danwei\" class=\"danwei inputcp\" size=\"6\" type=\"hidden\" value=\"'+data.danwei+'\"></td>';";echo "
		option +='<td class=\"td_c\"><input name=\"nums\" class=\"nums inputcp\" size=\"6\" type=\"text\" value=\"1\"></td>';";echo "
		option +='<td class=\"td_c\"><input name=\"shoujia\" class=\"shoujia inputcp\" size=\"6\" type=\"text\" value=\"'+data.shoujia+'\"></td>';";echo "
		option +='<td class=\"td_c\"><input name=\"zhekou\" class=\"zhekou inputcp\" size=\"6\" type=\"text\" value=\"0\"></td>';";echo "
		option +='<td class=\"td_c\"><input name=\"money\" class=\"money inputcp\" size=\"6\" type=\"text\" value=\"'+data.shoujia+'\"></td>';";echo "
		option +='<td class=\"td_c\"><input name=\"content\" class=\"content inputcp\" size=\"6\" type=\"text\" value=\"\"></td>';";echo "
		option +='<td class=\"td_c bhh\">'+data.adduser+'</td>';";echo "
		option +='<td class=\"td_c\">'+data.addtime+'</td>';";echo "
		option +='<td class=\"td_c bhh\"><a class=\"btn1 del cp_dels\"><i class=\"fa fa-trash-o\"></i>删除</a></td>';";echo "
		option = option+'</tr></tbody>';";echo "
	  }else{";echo "
		var option = '<tbody><tr class=\"tr\">';";echo "
		option = option+'</tr></tbody>';";echo "
	  }";echo "
	    ";echo "
      \$(\".table\").append(option);";echo "
";echo "
	}//";echo "
	});";echo "
";echo "
};";echo "
";echo "
//获取上一个页面返回值id 以,号分隔";echo "
function ChoseOK(ids){";echo "
";echo "
	var strs= new Array(); //定义一数组 ";echo "
	strs=ids.split(\",\"); //字符分割";echo "
";echo "
	\$('input[name=\"chanpinid\"]').each(function(){";echo "
		var hasid=\$(this).val();";echo "
		if(parseInt(hasid)){";echo "
		  layer.msg('已存在'+hasid);";echo "
		  strs.splice(jQuery.inArray(parseInt(hasid),strs),1);//删除id值";echo "
		}";echo "
	})";echo "
	";echo "
	//console.log(strs);";echo "
	 ";echo "
	for (i=0;i<strs.length ;i++ ) ";echo "
	{ ";echo "
	    ajax_get_chanpin(strs[i]);";echo "
	} ";echo "
";echo "
}";echo "
";echo "
";echo "
/*function table_set_xuhao(){";echo "
  //\$('table tr:not(:first)').remove();";echo "
        var len = \$('.table tbody').length;";echo "
        for(var i = 1;i<len;i++){";echo "
            \$('.table tbody tr:eq('+i+') td:first').text(i);";echo "
			\$('.table tbody tr:eq('+i+')').attr(\"data-id\",i);";echo "
        }";echo "
}*/";echo "
";echo "
";echo "
\$(document).on('click',\".alert_sd_add\",function(event) {";echo "
	";echo "
var sum = 0;";echo "
\$('input[name=\"chanpinid\"]').each(function(){";echo "
sum += ','+parseInt(\$(this).val());";echo "
})";echo "
";echo "
\$.dialog.open('";$DamA1=array();$DamA1[]='common/choose_chanpin';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?ids='+sum, {title: '新增产品', width:1250,height:620,fixed:true,lock:false}); ";echo "
	";echo "
});";echo "
";echo "
</script>";echo "
</body>";echo "
</html>";echo "
";
?>