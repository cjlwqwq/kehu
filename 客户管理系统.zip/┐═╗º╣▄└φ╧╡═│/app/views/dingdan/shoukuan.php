<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamPNFZ=17+1;$DamA2=array();$DamA2[]=&$DamPNFZ;$DamFN1=call_user_func_array("trim",$DamA2);$DamNG0=$DamFN1==17;if($DamNG0)goto DameWjgx2;$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";echo "
<html xmlns=\"http://www.w3.org/1999/xhtml\">";echo "
<head>";echo "
<meta name=\"renderer\" content=\"webkit|ie-comp|ie-stand\">";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  <form name=\"Save\" action=\"";$DamA1=array();$DamA1[]='dingdan/shoukuan';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\" onSubmit=\"return CheckInput();\">";echo "
    <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";echo "
      <tr>";echo "
        <td valign=\"top\" class=\"td_n pdl10 pdr10 pdt10\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" CLASS=\"table_1\">";echo "
            <col width=\"100\" />";echo "
            <col  />";echo "
            <tr class=\"tr_t\">";echo "
              <td class=\"td_l\" COLSPAN=\"2\"><B>新增到款</B></td>";echo "
            </tr>";echo "
            <tr>";echo "
              <td class=\"td_l_r title\"><font color=\"#FF0000\">*</font> 到款金额</td>";echo "
              <td class=\"td_c\"><input name=\"revenue\" type=\"text\" id=\"hRevenue\" class=\"input\" size=\"10\" value=\"0\" onFocus=\"if (value =='0'){value =''}\"onblur=\"if (value ==''){value='0'}\" />";echo "
                元</td>";echo "
            </tr>";echo "
            <tr>";echo "
              <td class=\"td_l_r title\">详情备注</td>";echo "
              <td class=\"td_c\" style=\"padding:5px 10px;\"><textarea name=\"content\" rows=\"4\" id=\"eContent\" class=\"input\" style=\"height:50px;width:95%;\"></textarea></td>";echo "
            </tr>";echo "
          </table></td>";echo "
      </tr>";echo "
    </table>";echo "
    <div class=\"h50b\"></div>";echo "
    <div class=\"fixed_bg_B\">";echo "
      <table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";echo "
        <tr>";echo "
          <td valign=\"top\" class=\"td_n Bottom_pd \"><input type=\"submit\"  class=\"btn2 btnbaoc\" value=\"保存\" >";echo "
            <input name=\"Back\" type=\"button\" id=\"Back\" class=\"btn2 btnguanb\" value=\"关闭\" onClick=\"art.dialog.close();\"></td>";echo "
        </tr>";echo "
      </table>";echo "
    </div>";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>