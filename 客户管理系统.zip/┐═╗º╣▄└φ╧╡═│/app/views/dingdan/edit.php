<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA4=array();$DamA4[]="FzrBkhof";$DamA4[]="17";$DamFN3=call_user_func_array("strspn",$DamA4);if($DamFN3)goto DameWjgx2;$DamPNFX=17-1;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_null",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='dingdan/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";$DamA2=array();$DamA2[]="zG";$DamA2[]="uLo";$DamFN1=call_user_func_array("strpos",$DamA2);if($DamFN1)goto DameWjgx4;$DamNFW=17-17;if($DamNFW)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf33F7;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx7:$DamAM8=array();$DamAM8[]=&$DamEc1;$DamFM7=call_user_func_array("count",$DamAM8);$DamMG0=$Dam1i<$DamFM7;if($DamMG0)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG1);$DamtIMG1=$DamEc1[$Dam1Key];unset($DamtIMG3);$DamtIMG3=$DamtIMG1;$file=$DamtIMG3;$DamAM4=array();$DamAM4[]=&$file;$DamAM4[]=CONF_EXT;$DamFM3=call_user_func_array("strpos",$DamAM4);if($DamFM3)goto DameWjgxf;goto DamldMhxf;DameWjgxf:goto DameWjgxb;goto Damxe;DamldMhxf:Damxe:goto DamldMhxb;DameWjgxb:goto DameWjgx6;goto Damxa;DamldMhxb:Damxa:goto DamldMhx6;DameWjgx6:$DamMFX=$dir . DS;$DamMFY=$DamMFX . $file;unset($DamtIMFZ);$DamtIMFZ=$DamMFY;unset($DamtIMG2);$DamtIMG2=$DamtIMFZ;unset($DamtIMG4);$DamtIMG4=$DamtIMG2;$filename=$DamtIMG4;$DamAM6=array();$DamAM6[]=&$file;$DamAM6[]=PATHINFO_FILENAME;$DamFM5=call_user_func_array("pathinfo",$DamAM6);Config::load($filename,$DamFM5);goto Damx5;DamldMhx6:Damx5:Damx8:$Dam1i=$Dam1i+1;goto Damx7;goto Damxc;DamldMhxd:Damxc:Damx9:CakMQSf33F7:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=dingdan\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>