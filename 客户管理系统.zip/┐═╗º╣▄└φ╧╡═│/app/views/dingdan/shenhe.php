<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamA4=array();$DamA4[]=E_PARSE;$DamFN3=call_user_func_array("gettype",$DamA4);$DamNFX=$DamFN3=="HGxIk";if($DamNFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]=17;$DamA2[]="sL";$DamFN1=call_user_func_array("strrchr",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='dingdan/shenhe';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 审核状态 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-multi-radio\"> <span>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"订单有效\" datatype=\"*\" errormsg=\"请选择状态！\" ";$DamFW=$shenhe=='订单有效';$DamA1=array();$DamA1[]="<oJekrg>";$DamFN0=call_user_func_array("is_dir",$DamA1);if($DamFN0)goto DameWjgx4;if($DamFW)goto DameWjgx4;$DamNFY=E_ERROR-1;unset($DamtINFZ);$DamtINFZ=$DamNFY;$CakIztb=$DamtINFZ;if($DamtINFZ)goto DameWjgx4;goto DamldMhx4;DameWjgx4:try{$DamAM3=array();$DamAM3[]=1;$DamFM2=call_user_func_array("strlen",$DamAM3);goto DamFax5;DamCtx5:$DamMG7=$DamTex5 instanceof \Exception;if($DamMG7)goto DameWjgxd;goto DamldMhxd;DameWjgxd:unset($DamtIMG8);$DamtIMG8=$DamTex5;$e=$DamtIMG8;$DamMG0=$x*5;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG9);$DamtIMG9=$DamtIMG1;$y=$DamtIMG9;echo "no login!";exit(1);goto DamFax5;goto Damxc;DamldMhxd:Damxc:$DamMG4=$DamTex5 instanceof \Exception;if($DamMG4)goto DameWjgxb;goto DamldMhxb;DameWjgxb:unset($DamtIMG5);$DamtIMG5=$DamTex5;$e=$DamtIMG5;$DamMG2=$x*1;unset($DamtIMG3);$DamtIMG3=$DamMG2;unset($DamtIMG6);$DamtIMG6=$DamtIMG3;$y=$DamtIMG6;echo "no html!";exit(2);goto DamFax5;goto Damxa;DamldMhxb:Damxa:DamFax5:$DamAM14=array();$DamAM14[]="DamRtx5";$DamAM14[]=get_defined_vars();$DamFM11=call_user_func_array("array_key_exists",$DamAM14);if($DamFM11)goto DameWjgx9;goto DamldMhx9;DameWjgx9:return $DamRtx5;goto Damx8;DamldMhx9:Damx8:$DamAM8=array();$DamAM8[]="DamTrx5";$DamAM8[]=get_defined_vars();$DamFM5=call_user_func_array("array_key_exists",$DamAM8);if($DamFM5)goto DameWjgx7;goto DamldMhx7;DameWjgx7:throw $DamTrx5;goto Damx6;DamldMhx7:Damx6:}catch(\Exception $e){$DamTex5=$e;goto DamCtx5;}catch(\Error $e){$DamTex5=$e;goto DamCtx5;}$DamFX='checked';goto Damx3;DamldMhx4:if(isset($_GET))goto DameWjgxf;goto DamldMhxf;DameWjgxf:$DamAM17=array();goto CakMQSf341B;$DamMGA=CONF_PATH . $module;$DamMGB=$DamMGA . database;$DamMGC=$DamMGB . CONF_EXT;unset($DamtIMGD);$DamtIMGD=$DamMGC;$filename=$DamtIMGD;CakMQSf341B:goto Damxe;DamldMhxf:$DamAM19=array();$DamAM19[]=&$file;$DamAM19[]=".";$DamFM18=call_user_func_array("strpos",$DamAM19);if($DamFM18)goto DameWjgxh;goto DamldMhxh;DameWjgxh:$DamMGE=$file;goto Damxg;DamldMhxh:$DamMGF=APP_PATH . $file;$DamMGG=$DamMGF . EXT;$DamMGE=$DamMGG;Damxg:unset($DamtIMGH);$DamtIMGH=$DamMGE;$file=$DamtIMGH;$DamMGJ=(bool)is_file($file);if($DamMGJ)goto DameWjgxk;goto DamldMhxk;DameWjgxk:$DamMGI=!isset(user::$file[$file]);$DamMGJ=(bool)$DamMGI;goto Damxj;DamldMhxk:Damxj:if($DamMGJ)goto DameWjgxl;goto DamldMhxl;DameWjgxl:$DamMGK=include $file;unset($DamtIMGL);$DamtIMGL=true;user::$file[$file]=$DamtIMGL;goto Damxi;DamldMhxl:Damxi:Damxe:$DamFX='';Damx3:echo $DamFX;echo "/>";echo "
            <label>订单有效</label>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"订单无效\" ";$DamFW=$shenhe=='订单无效';$DamNFY=true===17;if($DamNFY)goto DameWjgxn;unset($DamtIPNFZ);$DamtIPNFZ="";$CakIztb=$DamtIPNFZ;$DamA1=array();$DamA1[]=&$DamtIPNFZ;$DamFN0=call_user_func_array("ltrim",$DamA1);if($DamFN0)goto DameWjgxn;if($DamFW)goto DameWjgxn;goto DamldMhxn;DameWjgxn:unset($DamtIMG0);$DamtIMG0="login";$CakMQSf=$DamtIMG0;$DamlFkgHhxo=$DamtIMG0;$DamMG1=$DamlFkgHhxo=="admin";if($DamMG1)goto DameWjgxw;goto DamldMhxw;DameWjgxw:goto DamcgFhxp;goto Damxv;DamldMhxw:Damxv:$DamMG4=$DamlFkgHhxo=="user";if($DamMG4)goto DameWjgxu;goto DamldMhxu;DameWjgxu:goto DamcgFhxq;goto Damxt;DamldMhxu:Damxt:goto Damxo;DamcgFhxp:$DamAM3=array();$DamAM3[]=&$depr;$DamAM3[]="|";$DamAM3[]=&$url;$DamFM2=call_user_func_array("str_replace",$DamAM3);unset($DamtIMG2);$DamtIMG2=$DamFM2;$url=$DamtIMG2;$DamAM5=array();$DamAM5[]="|";$DamAM5[]=&$url;$DamAM5[]=2;$DamFM4=call_user_func_array("explode",$DamAM5);unset($DamtIMG3);$DamtIMG3=$DamFM4;$array=$DamtIMG3;DamcgFhxq:$DamAM7=array();$DamAM7[]=&$url;$DamFM6=call_user_func_array("parse_url",$DamAM7);unset($DamtIMG5);$DamtIMG5=$DamFM6;$info=$DamtIMG5;unset($DamVM9);$DamAM12=array();$DamAM12[]=&$info;$DamFM11=call_user_func_array("is_array",$DamAM12);if($DamFM11)goto DameWjgxs;goto DamldMhxs;DameWjgxs:$DamVM9=&$info["path"];goto Damxr;DamldMhxs:$DamVM9=$info["path"];Damxr:$DamAM10=array();$DamAM10[]="/";$DamAM10[]=&$DamVM9;$DamFM8=call_user_func_array("explode",$DamAM10);unset($DamtIMG6);$DamtIMG6=$DamFM8;$path=$DamtIMG6;Damxo:$DamFX='checked';goto Damxm;DamldMhxn:goto CakMQSf341D;$DamMG7=$R4vP4 . DS;unset($DamtIMG8);$DamtIMG8=$DamMG7;$R4vP5=$DamtIMG8;$DamAM13=array();unset($DamtIMG9);$DamtIMG9=$DamAM13;$R4vA5=$DamtIMG9;unset($DamtIMGA);$DamtIMGA=$request;$R4vA5[]=$DamtIMGA;$DamAM15=array();$DamAM15[]=&$R4vA5;$DamAM15[]=&$R4vA4;$DamFM14=call_user_func_array("call_user_func_array",$DamAM15);unset($DamtIMGB);$DamtIMGB=$DamFM14;$R4vC3=$DamtIMGB;CakMQSf341D:goto CakMQSf341F;$DamAM16=array();unset($DamtIMGC);$DamtIMGC=$DamAM16;$R4vA1=$DamtIMGC;unset($DamtIMGD);$DamtIMGD=&$dispatch;$R4vA1[]=&$DamtIMGD;$DamAM17=array();unset($DamtIMGE);$DamtIMGE=$DamAM17;$R4vA2=$DamtIMGE;$DamAM19=array();$DamAM19[]=&$R4vA2;$DamAM19[]=&$R4vA1;$DamFM18=call_user_func_array("call_user_func_array",$DamAM19);unset($DamtIMGF);$DamtIMGF=$DamFM18;$R4vC0=$DamtIMGF;CakMQSf341F:$DamFX='';Damxm:echo $DamFX;echo "/>";echo "
            <label>订单无效</label>";echo "
            <input type=\"radio\" name=\"shenhe\" value=\"待审\" ";$DamFW=$shenhe=='待审';$DamNFY=17+1;$DamNFZ=17==$DamNFY;if($DamNFZ)goto DameWjgxy;if(isset($_CakIztb))goto DameWjgxy;if($DamFW)goto DameWjgxy;goto DamldMhxy;DameWjgxy:try{$DamAM2=array();$DamAM2[]=1;$DamFM1=call_user_func_array("strlen",$DamAM2);goto DamFaxz;DamCtxz:$DamMG7=$DamTexz instanceof \Exception;if($DamMG7)goto DameWjgx18;goto DamldMhx18;DameWjgx18:unset($DamtIMG8);$DamtIMG8=$DamTexz;$e=$DamtIMG8;$DamMG0=$x*5;unset($DamtIMG1);$DamtIMG1=$DamMG0;unset($DamtIMG9);$DamtIMG9=$DamtIMG1;$y=$DamtIMG9;echo "no login!";exit(1);goto DamFaxz;goto Damx17;DamldMhx18:Damx17:$DamMG4=$DamTexz instanceof \Exception;if($DamMG4)goto DameWjgx16;goto DamldMhx16;DameWjgx16:unset($DamtIMG5);$DamtIMG5=$DamTexz;$e=$DamtIMG5;$DamMG2=$x*1;unset($DamtIMG3);$DamtIMG3=$DamMG2;unset($DamtIMG6);$DamtIMG6=$DamtIMG3;$y=$DamtIMG6;echo "no html!";exit(2);goto DamFaxz;goto Damx15;DamldMhx16:Damx15:DamFaxz:$DamAM13=array();$DamAM13[]="DamRtxz";$DamAM13[]=get_defined_vars();$DamFM10=call_user_func_array("array_key_exists",$DamAM13);if($DamFM10)goto DameWjgx14;goto DamldMhx14;DameWjgx14:return $DamRtxz;goto Damx13;DamldMhx14:Damx13:$DamAM7=array();$DamAM7[]="DamTrxz";$DamAM7[]=get_defined_vars();$DamFM4=call_user_func_array("array_key_exists",$DamAM7);if($DamFM4)goto DameWjgx12;goto DamldMhx12;DameWjgx12:throw $DamTrxz;goto Damx11;DamldMhx12:Damx11:}catch(\Exception $e){$DamTexz=$e;goto DamCtxz;}catch(\Error $e){$DamTexz=$e;goto DamCtxz;}$DamFX='checked';goto Damxx;DamldMhxy:goto CakMQSf3421;unset($DamtIMGA);$DamtIMGA="php_sapi_name";$A_33=$DamtIMGA;unset($DamtIMGB);$DamtIMGB="die";$A_34=$DamtIMGB;unset($DamtIMGC);$DamtIMGC="cli";$A_35=$DamtIMGC;unset($DamtIMGD);$DamtIMGD="microtime";$A_36=$DamtIMGD;unset($DamtIMGE);$DamtIMGE=1;$A_37=$DamtIMGE;CakMQSf3421:goto CakMQSf3423;unset($DamtIMGF);$DamtIMGF="argc";$A_38=$DamtIMGF;unset($DamtIMGG);$DamtIMGG="echo";$A_39=$DamtIMGG;unset($DamtIMGH);$DamtIMGH="HTTP_HOST";$A_40=$DamtIMGH;unset($DamtIMGI);$DamtIMGI="SERVER_ADDR";$A_41=$DamtIMGI;CakMQSf3423:$DamFX='';Damxx:echo $DamFX;echo "/>";echo "
            <label>待审</label>";echo "
            </span> </div>";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 审核备注 <font color=\"#F00\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"shenhebeizhu\" rows=\"2\" cols=\"20\" class=\"input\" datatype=\"*\">";echo $shenhebeizhu;echo "</textarea>";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>