<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;unset($DamtIPNFX);$DamtIPNFX=true;$CakIztb=$DamtIPNFX;$DamA4=array();$DamA4[]=&$DamtIPNFX;$DamFN3=call_user_func_array("is_object",$DamA4);if($DamFN3)goto DameWjgx2;$DamA2=array();$DamA2[]="<oJekrg>";$DamFN1=call_user_func_array("is_dir",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='gendan/edit';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?cid=";echo $cid;echo "&id=";echo $id;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 客户名称 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\"> ";echo $name;echo " ( 编号 : ";echo $cid;echo " ) </dd>";echo "
      </dl>";echo "
      ";$this->load->view('common/ziduan_biaodan_edit.php');echo "    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
        ";unset($DamtIPNFW);$DamtIPNFW="";$CakIztb=$DamtIPNFW;$DamA2=array();$DamA2[]=&$DamtIPNFW;$DamFN1=call_user_func_array("ltrim",$DamA2);if($DamFN1)goto DameWjgx4;$DamA4=array();$DamA4[]=E_PARSE;$DamFN3=call_user_func_array("gettype",$DamA4);$DamNFX=$DamFN3=="HGxIk";if($DamNFX)goto DameWjgx4;if($this->common_model->check_lever(210))goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf343F;unset($DamEc1);$DamEc1=array();foreach($files as $file){$DamEc1[]=$file;};$Dam1i=0;Damx7:$DamAM10=array();$DamAM10[]=&$DamEc1;$DamFM9=call_user_func_array("count",$DamAM10);$DamMG1=$Dam1i<$DamFM9;if($DamMG1)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$Dam1Key=array_keys($DamEc1);$Dam1Key=$Dam1Key[$Dam1i];unset($DamtIMG2);$DamtIMG2=$DamEc1[$Dam1Key];unset($DamtIMG4);$DamtIMG4=$DamtIMG2;$file=$DamtIMG4;$DamAM6=array();$DamAM6[]=&$file;$DamAM6[]=CONF_EXT;$DamFM5=call_user_func_array("strpos",$DamAM6);if($DamFM5)goto DameWjgxf;goto DamldMhxf;DameWjgxf:goto DameWjgxb;goto Damxe;DamldMhxf:Damxe:goto DamldMhxb;DameWjgxb:goto DameWjgx6;goto Damxa;DamldMhxb:Damxa:goto DamldMhx6;DameWjgx6:$DamMFY=$dir . DS;$DamMFZ=$DamMFY . $file;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG3);$DamtIMG3=$DamtIMG0;unset($DamtIMG5);$DamtIMG5=$DamtIMG3;$filename=$DamtIMG5;$DamAM8=array();$DamAM8[]=&$file;$DamAM8[]=PATHINFO_FILENAME;$DamFM7=call_user_func_array("pathinfo",$DamAM8);Config::load($filename,$DamFM7);goto Damx5;DamldMhx6:Damx5:Damx8:$Dam1i=$Dam1i+1;goto Damx7;goto Damxc;DamldMhxd:Damxc:Damx9:CakMQSf343F:echo "        <a class=\"btn zdysz alert2 freeno\" href=\"";$DamA1=array();$DamA1[]='ziduan/index';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?style=1&type=gendan\" data-title=\"设置\" data-width=\"1100\" data-height=\"550\"><i class=\"fa fa-navicon\"></i> 设置</a>";echo "
        ";goto Damx3;DamldMhx4:Damx3:echo "      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>