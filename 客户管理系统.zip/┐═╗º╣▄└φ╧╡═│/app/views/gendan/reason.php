<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamPNFX=25-17;$DamA2=array();$DamA2[]=&$DamPNFX;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamPNFY=17+1;$DamPNFZ=$DamPNFY+17;$DamAPN3=array();$DamA5=array();$DamA5[]=&$DamPNFZ;$DamA5[]=&$DamAPN3;$DamFN4=call_user_func_array("in_array",$DamA5);if($DamFN4)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";echo "
<html xmlns=\"http://www.w3.org/1999/xhtml\">";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏-->";echo "
  <form name=\"Save\" action=\"";$DamA1=array();$DamA1[]='gendan/reason';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "?id=";echo $id;echo "\" method=\"post\" onSubmit=\"return CheckInput();\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 删除原因 <font color=\"#F00\">*</font> </dt>";echo "
        <dd class=\"int_check\">";echo "
          <textarea name=\"reason\" rows=\"2\" cols=\"20\" class=\"input\" datatype=\"*\" ></textarea>";echo "
          <span class=\"Validform_checktip\"></span> </dd>";echo "
      </dl>";echo "
    </div>";echo "
    <!--工具栏--> ";echo "
    <!--<div class=\"h30\"></div>-->";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
    ";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";echo "
";
?>