<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17+1;$DamNFY=E_STRICT==$DamNFX;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamNFZ=17-17;$DamNG0=$DamNFZ/2;if($DamNG0)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>管理页面</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\">";echo "
";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
";echo "
  <div class=\"tab-content\" style=\"min-width:350px; min-height:250px;\">";echo "
    <div style=\" text-align:center; padding-top:120px;\"> <a href=\"";$DamA1=array();$DamA1[]='gendan/daochu_do';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\">点击下载导出数据.xls</a> </div>";echo "
  </div>";echo "
  ";echo "
  <!--工具栏-->";echo "
  <div class=\"h30\"></div>";echo "
  <div class=\"page-footer\">";echo "
    <div class=\"btn-wrap\"> ";echo "
      <!--<input type=\"submit\" value=\"确定\" class=\"btn\" onclick='zhuanyisave()'/>-->";echo "
      <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();parent.layclose();\" />";echo "
    </div>";echo "
  </div>";echo "
  <!--/工具栏--> ";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>