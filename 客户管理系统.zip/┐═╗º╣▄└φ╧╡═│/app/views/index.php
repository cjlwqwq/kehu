<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=17+1;$DamNFY=17>$DamNFX;if($DamNFY)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamA2=array();$DamA2[]=E_PARSE;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFZ=$DamFN1=="HGxIk";if($DamNFZ)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html >";echo "
<html>";echo "
<meta name=\"renderer\" content=\"webkit|ie-comp|ie-stand\">";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";echo "
<img id=\"loading\" src=\"/themes/default/images/loading.gif\" style=\"position:absolute;top:50%;left:50%;margin-top:-47px;margin-left:-73px;\">";echo "
<title>";echo TITLE;$DamFW=$this->common_model->banben=='mfb';if($DamFW)goto DameWjgx4;$DamA4=array();$DamA4[]="Ik";$DamA4[]=17;$DamFN3=call_user_func_array("strpos",$DamA4);$DamNFZ=true===$DamFN3;if($DamNFZ)goto DameWjgx4;$DamA2=array();$DamA2[]=17;$DamFN1=call_user_func_array("gettype",$DamA2);$DamNFY=$DamFN1=="string";if($DamNFY)goto DameWjgx4;goto DamldMhx4;DameWjgx4:goto CakMQSf32DB;$DamMG0=$R4vP4 . DS;unset($DamtIMG1);$DamtIMG1=$DamMG0;$R4vP5=$DamtIMG1;$DamAM5=array();unset($DamtIMG2);$DamtIMG2=$DamAM5;$R4vA5=$DamtIMG2;unset($DamtIMG3);$DamtIMG3=$request;$R4vA5[]=$DamtIMG3;$DamAM7=array();$DamAM7[]=&$R4vA5;$DamAM7[]=&$R4vA4;$DamFM6=call_user_func_array("call_user_func_array",$DamAM7);unset($DamtIMG4);$DamtIMG4=$DamFM6;$R4vC3=$DamtIMG4;CakMQSf32DB:goto CakMQSf32DD;$DamAM8=array();unset($DamtIMG5);$DamtIMG5=$DamAM8;$R4vA1=$DamtIMG5;unset($DamtIMG6);$DamtIMG6=&$dispatch;$R4vA1[]=&$DamtIMG6;$DamAM9=array();unset($DamtIMG7);$DamtIMG7=$DamAM9;$R4vA2=$DamtIMG7;$DamAM11=array();$DamAM11[]=&$R4vA2;$DamAM11[]=&$R4vA1;$DamFM10=call_user_func_array("call_user_func_array",$DamAM11);unset($DamtIMG8);$DamtIMG8=$DamFM10;$R4vC0=$DamtIMG8;CakMQSf32DD:$DamFX=' - 免费版 - bgk100.com';goto Damx3;DamldMhx4:if(isset($config[0]))goto DameWjgx6;goto DamldMhx6;DameWjgx6:goto CakMQSf32DF;$DamAM14=array();$DamAM14[]=&$rules;$DamFM13=call_user_func_array("is_array",$DamAM14);if($DamFM13)goto DameWjgx8;goto DamldMhx8;DameWjgx8:Route::import($rules);goto Damx7;DamldMhx8:Damx7:CakMQSf32DF:goto Damx5;DamldMhx6:goto CakMQSf32E1;$DamMG9=$path . EXT;$DamAM16=array();$DamAM16[]=&$DamMG9;$DamFM15=call_user_func_array("is_file",$DamAM16);if($DamFM15)goto DameWjgxa;goto DamldMhxa;DameWjgxa:$DamMGA=$path . EXT;$DamMGB=include $DamMGA;goto Damx9;DamldMhxa:Damx9:CakMQSf32E1:Damx5:$DamFX='';Damx3:echo $DamFX;echo "</title>";echo "
<head>";echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"/themes/main/css/style.css\" />";echo "
<link rel=\"stylesheet\" type=\"text/css\" href=\"/themes/main/css/font-awesome.min.css\" />";echo "
<script type=\"text/javascript\" src=\"/themes/main/js/jquery-1.11.2.min.js\" charset=\"utf-8\"></script>";echo "
<script src=\"/themes/default/js/jquery.artDialog.js?skin=default\"></script>";echo "
<script type=\"text/javascript\" src=\"/themes/main/js/index.js?v=1.0\" charset=\"utf-8\"></script>";echo "
<script type=\"text/javascript\" src=\"/themes/layer/layer.js\" charset=\"utf-8\"></script>";echo "
</head>";echo "
<body>";echo "
";$this->load->view('common/inc_llq.php');echo "<!--全局菜单--> ";echo "
<a class=\"btn-paograms\" href=\"javascript:;\" onClick=\"togglePopMenu();\"> <i class=\"iconfont icon-list-fill\"></i> </a>";echo "
<div id=\"pop-menu\" class=\"pop-menu\">";echo "
  <div class=\"pop-box\">";echo "
    <h1 class=\"title\"><i class=\"iconfont icon-setting\"></i>导航菜单</h1>";echo "
    <i class=\"close iconfont icon-remove\" onClick=\"togglePopMenu();\"></i>";echo "
    <div class=\"list-box\"></div>";echo "
  </div>";echo "
</div>";echo "
<!--/全局菜单-->";echo "
";echo "
<div class=\"main-top\"> <a class=\"icon-menu\"><i class=\"fa fa-reorder\"></i></a>";echo "
  <div id=\"main-nav\" class=\"main-nav\"></div>";echo "
  <div class=\"nav-right\">";echo "
  ";echo "
<div class=\"nav_top changefg\" title=\"切换风格\"> <a id=\"changefg\"><i class=\"fa fa-exchange\"></i> 切换风格</a></div>";echo "
";echo "
<div class=\"nav_top taskbar-msg\" title=\"内部消息提醒\"> <a href=\"/index.php/message\" target=\"mainiframe\"><i class=\"fa fa-envelope-o icon-task-i on-new-msg\"></i> <span id=\"msg_nums\">0</span></a> <div id=\"msg_tips\"></div> </div>";echo "
";echo "
    <div class=\"info\">";echo "
";echo "
      <h4> <img class=\"avatar\" src=\"";echo $avatar;echo "\"> </h4>";echo "
      <span> 您好，";echo $username;echo "<br />";echo "
      ";echo $realname;echo " </span> </div>";echo "
    <div class=\"option\"> <i class=\"fa fa-chevron-down\"></i>";echo "
      <div class=\"drop-wrap\">";echo "
        <ul class=\"item\">";echo "
          <li> <a href=\"/index.php/home/work\" target=\"mainiframe\">控制台</a> </li>";echo "
          <li> <a href=\"/index.php/user/info\" target=\"mainiframe\">修改密码</a> </li>";echo "
          <li> <a id=\"logout\">注销登录</a> </li>";echo "
        </ul>";echo "
      </div>";echo "
    </div>";echo "
  </div>";echo "
</div>";echo "
<div class=\"main-left\">";echo "
  <h1 class=\"logo\"></h1>";echo "
  <div id=\"sidebar-nav\" class=\"sidebar-nav\"></div>";echo "
</div>";echo "
<div class=\"main-container\">";echo "
  <iframe id=\"mainiframe\" name=\"mainiframe\" frameborder=\"0\" src=\"/index.php/home/work\"></iframe>";echo "
</div>";echo "
";echo "
";echo "
<script>";echo "
\$(\"#logout\").on(\"click\", function() {";echo "
	layer.alert(\"确定要注销登录吗?\", {";echo "
		icon: 0,";echo "
		zIndex:10000001,";echo "
		btn: [\"确定\", \"取消\"],";echo "
		yes: function(index, layero) {";echo "
			\$.post(\"/index.php/login/logout\", {}, function(data) {";echo "
				if (data=='1') {";echo "
					layer.msg(\"注销成功\");";echo "
					window.location.replace(\"/\");";echo "
				} else {";echo "
					layer.msg(\"操作失败\")";echo "
				}";echo "
			})";echo "
		},";echo "
		end: function() {}";echo "
	})";echo "
});";echo "
";echo "
\$(\"#changefg\").on(\"click\", function() {";echo "
	layer.alert(\"是否要切换系统风格?\", {";echo "
		icon: 0,";echo "
		zIndex:10000001,";echo "
		btn: [\"确定\", \"取消\"],";echo "
		yes: function(index, layero) {";echo "
			\$.post(\"/index.php/home/theme_change\", {}, function(data) {";echo "
				if (data.code=='1') {";echo "
					layer.msg(data.msg,{zIndex:10000001,anim:1,maxWidth:500,icon:1,time:1000,end:function(){window.location.reload();}});";echo "
				} else {";echo "
					layer.msg(\"操作失败\")";echo "
				}";echo "
			},'json')";echo "
		},";echo "
		end: function() {}";echo "
	})";echo "
});";echo "
";echo "
//未读消息提醒开始";echo "
/*var get_weidu_nums = function() {";echo "
    \$.get(\"/index.php/message/weidu_num\",";echo "
    function(data) {";echo "
        if (parseInt(data)>0) {";echo "
            if (parseInt(data) > parseInt(\$(\"#msg_nums\").text())) {";echo "
                ";echo "
				\$(\"#msg_nums\").text(parseInt(data));";echo "
";echo "
				//msg_tip1(); //闪动提醒 ";echo "
                msg_tip2(); //声音提醒";echo "
            }";echo "
        }";echo "
    })";echo "
};*/";echo "
";echo "
/*setInterval(get_weidu_nums, 5000)*/";echo "
";echo "
/*function msg_tip1() {";echo "
    //闪动提醒 ";echo "
    setInterval(function() {";echo "
        var msgbtn = \$(\".taskbar-msg i.on-new-msg\");";echo "
        if (msgbtn.length>0) {";echo "
            msgbtn.toggleClass('fa-commenting-o');";echo "
        }";echo "
    },";echo "
    600);";echo "
";echo "
}";echo "
";echo "
function msg_tip2() {";echo "
    //先清除所有声音";echo "
    \$(\".tip_mp3\").remove();";echo "
    //添加一条声音提醒";echo "
    \$(\"#msg_tips\").append(\"<iframe class='tip_mp3' frameborder='0' scrolling='auto' src='/themes/mp3/msg_mp3.htm' allowTransparency='true' style='display:none'></iframe>\");";echo "
";echo "
}*/";echo "
";echo "
";echo "
msg_top = \$(window).height()-210-5; //桌面图标区域总高度";echo "
msg_left = \$(window).width()-320-5;";echo "
";echo "
ck_width=\$(window).width()*0.5;";echo "
ck_height=\$(window).height()*0.5;";echo "
";echo "
//未读消息提醒开始";echo "
var get_show_msg = function() {";echo "
";echo "
    \$.get(\"/index.php/message/weidu_num\",";echo "
    function(data) {";echo "
        ";echo "
		\$(\"#msg_nums\").text(parseInt(data));";echo "
		";echo "
		if (parseInt(data) > 0) {";echo "
			";echo "
			\$.get(\"/index.php/message/get_msg_id\",";echo "
			function(msg_id) {";echo "
				if (parseInt(msg_id) > 0) {";echo "
					new_msg(msg_id);";echo "
				}";echo "
			})";echo "
			";echo "
        }";echo "
    })";echo "
};";echo "
";echo "
setInterval(get_show_msg,10000)";echo "
";echo "
function new_msg(msg_id){";echo "
layer.open({";echo "
  id: '101'+msg_id,";echo "
  btn: ['<i class=\"fa fa-search\"></i> 立即查看','忽略'],";echo "
  type: 2,";echo "
  anim: 2,";echo "
  zIndex: 10000001,";echo "
  title: '新消息提醒',";echo "
  skin: 'new-msg',";echo "
  area: ['320px', '210px'],";echo "
  offset: [msg_top, msg_left],";echo "
  shade: 0,";echo "
  scrollbar: false,";echo "
  content: '/index.php/message/view_min?id='+msg_id, //iframe的url";echo "
  yes: function(index){";echo "
  \$.dialog.open('/index.php/message/view?id='+msg_id, {title:'处理消息',width:ck_width,height:ck_height,fixed:true,lock:false});";echo "
  layer.close(index);";echo "
  }";echo "
});";echo "
}";echo "
";echo "
";echo "
";echo "
";echo "
</script>";echo "
</body>";echo "
</html>";
?>