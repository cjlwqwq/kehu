<?php
/*
严禁反编译、逆向等任何形式的侵权行为，违者将追究法律责任
技术支持 www.bgk100.com  qq15225660
*/

$DamNFX=$_GET=="nhTjPx";if($DamNFX)goto DameWjgx2;$DamFW=!defined('BASEPATH');if($DamFW)goto DameWjgx2;$DamPNFY=25-17;$DamA2=array();$DamA2[]=&$DamPNFY;$DamFN1=call_user_func_array("is_bool",$DamA2);if($DamFN1)goto DameWjgx2;goto DamldMhx2;DameWjgx2:exit('No direct script access allowed');goto Damx1;DamldMhx2:Damx1:echo "<!DOCTYPE html>";echo "
<html>";echo "
<head>";echo "
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />";echo "
<meta name=\"viewport\" content=\"width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no\" />";echo "
<meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />";echo "
<title>数据操作</title>";echo "
";$this->load->view('common/inc_styles.php');echo "</head>";echo "
";echo "
<body class=\"mainbody\">";echo "
<div class=\"mian-page-div\"> ";echo "
  ";echo "
  <!--导航栏-->";echo "
  ";$this->load->view('common/inc_head.php');echo "  <!--/导航栏--> ";echo "
  ";echo "
  <!--内容-->";echo "
  <form name=\"Save\" id=\"form1\" action=\"";$DamA1=array();$DamA1[]='user/add';$DamF0=call_user_func_array("site_url",$DamA1);echo $DamF0;echo "\" method=\"post\">";echo "
    <div class=\"tab-content\">";echo "
      <dl>";echo "
        <dt> 登录账号 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"username\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 姓名 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"realname\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"*\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 登录密码 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"userpwd\" type=\"password\" class=\"input normal\" datatype=\"*6-20\" nullmsg=\"请设置密码\" errormsg=\"密码范围在6-20位之间\" value=\"\" />";echo "
          <span class=\"Validform_checktip\">*登录的密码，至少6位</span></dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 确认密码 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"confirmpwd\" type=\"password\" class=\"input normal\" datatype=\"*\" recheck=\"userpwd\" nullmsg=\"请再输入一次密码\" errormsg=\"两次输入的密码不一致\" value=\"\" />";echo "
          <span class=\"Validform_checktip\">*再次输入密码</span></dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 所属部门 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
";echo "
            <select name='groupid' datatype=\"*\" errormsg=\"请选择所属部门\">";echo "
              <option value=\"\">请选择所属部门...</option>";echo "
              ";unset($DamEc1);$DamEc1=array();foreach($select_group as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damx3:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamNFW=17-17;$DamNFX=$DamNFW/2;if($DamNFX)goto DameWjgx7;if($DamFW)goto DameWjgx7;$DamA1=array();$DamA1[]="JrCIziGY";$DamFN0=call_user_func_array("base64_decode",$DamA1);$DamNFY=$DamFN0=="ciNntTOd";if($DamNFY)goto DameWjgx7;goto DamldMhx7;DameWjgx7:if(isset($config[0]))goto DameWjgx9;goto DamldMhx9;DameWjgx9:goto CakMQSf38C8;$DamAM4=array();$DamAM4[]=&$rules;$DamFM3=call_user_func_array("is_array",$DamAM4);if($DamFM3)goto DameWjgxb;goto DamldMhxb;DameWjgxb:Route::import($rules);goto Damxa;DamldMhxb:Damxa:CakMQSf38C8:goto Damx8;DamldMhx9:goto CakMQSf38CA;$DamMFZ=$path . EXT;$DamAM6=array();$DamAM6[]=&$DamMFZ;$DamFM5=call_user_func_array("is_file",$DamAM6);if($DamFM5)goto DameWjgxd;goto DamldMhxd;DameWjgxd:$DamMG0=$path . EXT;$DamMG1=include $DamMG0;goto Damxc;DamldMhxd:Damxc:CakMQSf38CA:Damx8:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "              <option value=\"";echo $row['id'];echo "\">";echo $row['name'];echo "</option>";echo "
              ";Damx4:$Dam1i=$Dam1i+1;goto Damx3;goto Damx6;DamldMhx7:Damx6:Damx5:echo "            </select>";echo "
";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 部门主管</dt>";echo "
        <dd class=\"int_check\">";echo "
          <div class=\"rule-single-checkbox single-checkbox\"><a href=\"javascript:;\"><i class=\"on\">否</i><i class=\"off\">是</i></a>";echo "
            <input name=\"iszhuguan\" type=\"text\" value=\"否\" style=\"display:block;\">";echo "
          </div>";echo "
          <span class=\"Validform_checktip\">部门主管可以管理本部门所有客户</span> </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>权限角色 <font color=\"#f00;\">*</font> </dt>";echo "
        <dd class=\"int_check\">";echo "
";echo "
            <select name='roleid' datatype=\"*\" errormsg=\"请选择权限角色\">";echo "
              <option value=\"\">请选择权限角色...</option>";echo "
              <option value=\"0\">超级管理员</option>";echo "
              ";unset($DamEc1);$DamEc1=array();foreach($select_role as $arr=>$row){$DamEc1[$arr]=$row;};$Dam1i=0;Damxe:$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("count",$DamA1);$DamFW=$Dam1i<$DamF0;$DamPNFX="SxJ"==__LINE__;unset($DamtIPNFY);$DamtIPNFY=$DamPNFX;$CakIztb=$DamtIPNFY;$DamA3=array();$DamA3[]=&$DamtIPNFY;$DamFN2=call_user_func_array("strrev",$DamA3);if($DamFN2)goto DameWjgxi;if($DamFW)goto DameWjgxi;$DamA1=array();$DamA1[]="Ik";$DamA1[]=17;$DamFN0=call_user_func_array("strpos",$DamA1);$DamNFW=true===$DamFN0;if($DamNFW)goto DameWjgxi;goto DamldMhxi;DameWjgxi:try{$DamAM5=array();$DamAM5[]=1;$DamFM4=call_user_func_array("strlen",$DamAM5);goto DamFaxj;DamCtxj:$DamMG6=$DamTexj instanceof \Exception;if($DamMG6)goto DameWjgxr;goto DamldMhxr;DameWjgxr:unset($DamtIMG7);$DamtIMG7=$DamTexj;$e=$DamtIMG7;$DamMFZ=$x*5;unset($DamtIMG0);$DamtIMG0=$DamMFZ;unset($DamtIMG8);$DamtIMG8=$DamtIMG0;$y=$DamtIMG8;echo "no login!";exit(1);goto DamFaxj;goto Damxq;DamldMhxr:Damxq:$DamMG3=$DamTexj instanceof \Exception;if($DamMG3)goto DameWjgxp;goto DamldMhxp;DameWjgxp:unset($DamtIMG4);$DamtIMG4=$DamTexj;$e=$DamtIMG4;$DamMG1=$x*1;unset($DamtIMG2);$DamtIMG2=$DamMG1;unset($DamtIMG5);$DamtIMG5=$DamtIMG2;$y=$DamtIMG5;echo "no html!";exit(2);goto DamFaxj;goto Damxo;DamldMhxp:Damxo:DamFaxj:$DamAM16=array();$DamAM16[]="DamRtxj";$DamAM16[]=get_defined_vars();$DamFM13=call_user_func_array("array_key_exists",$DamAM16);if($DamFM13)goto DameWjgxn;goto DamldMhxn;DameWjgxn:return $DamRtxj;goto Damxm;DamldMhxn:Damxm:$DamAM10=array();$DamAM10[]="DamTrxj";$DamAM10[]=get_defined_vars();$DamFM7=call_user_func_array("array_key_exists",$DamAM10);if($DamFM7)goto DameWjgxl;goto DamldMhxl;DameWjgxl:throw $DamTrxj;goto Damxk;DamldMhxl:Damxk:}catch(\Exception $e){$DamTexj=$e;goto DamCtxj;}catch(\Error $e){$DamTexj=$e;goto DamCtxj;}$DamA1=array();$DamA1[]=&$DamEc1;$DamF0=call_user_func_array("array_keys",$DamA1);unset($DamtIFW);$DamtIFW=$DamF0;$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$arr[$Dam1i];$arr=$DamtIFW;unset($DamtIFW);$DamtIFW=$DamEc1[$arr];$row=$DamtIFW;echo "              <option value=\"";echo $row['id'];echo "\">";echo $row['name'];echo "</option>";echo "
              ";Damxf:$Dam1i=$Dam1i+1;goto Damxe;goto Damxh;DamldMhxi:Damxh:Damxg:echo "            </select>";echo "
";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>客户数量限制</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"maxnum\" type=\"text\" class=\"input normal\" value=\"0\" onfocus=\"if (value =='0'){value =''}\" onblur=\"if (value ==''){value='0'}\" />";echo "
          <span class=\"Validform_checktip\">0为不限制</span> </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt> 手机 <font color=\"#f00;\">*</font></dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"mobile\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"m\" errormsg=\"手机号格式错误\" />";echo "
        </dd>";echo "
      </dl>";echo "
      <dl>";echo "
        <dt>电子邮箱</dt>";echo "
        <dd class=\"int_check\">";echo "
          <input name=\"email\" type=\"text\" value=\"\" class=\"input normal\" datatype=\"e\" ignore=\"ignore\" errormsg=\"邮箱格式错误\" />";echo "
        </dd>";echo "
      </dl>";echo "
    </div>";echo "
    ";echo "
    <!--/内容--> ";echo "
    ";echo "
    <!--工具栏-->";echo "
    <div class=\"h30\"></div>";echo "
    <div class=\"page-footer\">";echo "
      <div class=\"btn-wrap\">";echo "
        <input type=\"submit\" value=\"提交保存\" class=\"btn submit\" />";echo "
        <input type=\"button\" value=\"关闭\" class=\"btn close\" onclick=\"art.dialog.close();\" />";echo "
      </div>";echo "
    </div>";echo "
    <!--/工具栏-->";echo "
  </form>";echo "
  <!--底部-->";echo "
  ";$this->load->view('common/inc_foot.php');echo "  <!--/底部--> ";echo "
  ";echo "
</div>";echo "
</body>";echo "
</html>";
?>