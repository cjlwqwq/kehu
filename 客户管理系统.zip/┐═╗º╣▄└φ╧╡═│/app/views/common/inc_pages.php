<?php if($this->common_model->is_mobile()==1){ //手机端?>
<?php echo $this->lib_page->showpage_m()?>
<?php }else{?>
<div class="pagepostion">
  <ul class="pagination">
    <?php echo $this->lib_page->showpage()?> 
    <script language='javascript'>function getValue(obj){if (document.getElementById("geturl").value!="") {location.href="?page="+escape(document.getElementById("geturl").value)+""}}</script>
    <input class="pagenum" id="geturl" value="<?php echo $this->lib_page->nowPage?>">
    <li class="last"><a href='javascript:void(0);' onclick="getValue(geturl.value)">跳转</a></li>
  </ul>
</div>
<?php }?>
