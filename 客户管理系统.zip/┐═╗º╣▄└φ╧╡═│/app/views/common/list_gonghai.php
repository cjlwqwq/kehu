<table class="table tree_table">
  <thead>
    <tr class="">
      <th width="40" class="td_c bhh no-m">折叠</th>
      <th width="40" class="td_c bhh">选择</th>
      <th width="60" class="td_c bhh no-m"><a class="paixu" ziduan="id" paixu=""> 编号 </a></th>
      <th width="100" class="td_c bhh"> <?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"){//客户名称?>
        <a class="paixu" ziduan="<?php echo $n['name']?>" paixu=""> <?php echo $n['title']?> </a>
        <?php }}?>
      </th>
      <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <th width="100" class="td_c bhh head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--普通字段结束-->
      <?php }?>
      <?php	
}}}
?>
      <th width="100" class="td_c bhh"><a class="paixu <?php if ($pai=='squser'&&$xu=='desc'){?>on_desc<?php }elseif($pai=='squser'&&$xu=='asc'){?>on_asc<?php }?>" href="?id=<?php echo $id?>&pai=squser&xu=<?php if ($pai=='squser'&&$xu=='desc'){?>asc<?php }elseif($pai=='squser'&&$xu=='asc'){?>desc<?php }?>">申请人 </a></th>
      <th width="100" class="td_c bhh"><a class="paixu <?php if ($pai=='sqtime'&&$xu=='desc'){?>on_desc<?php }elseif($pai=='sqtime'&&$xu=='asc'){?>on_asc<?php }?>" href="?id=<?php echo $id?>&pai=sqtime&xu=<?php if ($pai=='sqtime'&&$xu=='desc'){?>asc<?php }elseif($pai=='sqtime'&&$xu=='asc'){?>desc<?php }?>">申请时间 </a></th>
      <th width="60" class="td_c bhh">操作</th>
    </tr>
  </thead>
  <?php 
 if (count($list)>0) {
 foreach($list as $arr=>$row) {?>
  <tbody>
    <tr class="tr">
      <td class="td_c no-m"><span class="zmdi fa fa-chevron-circle-down"></span></td>
      <td class="td_c"><span class="checkall pretty primary">
        <input type="checkbox" class="aids" value="<?php echo $row['id']?>"/>
        <label><i class="mdi mdi-check"></i></label>
        </span></td>
      <td class="td_c bhh no-m"><?php echo $row['id']?></td>
      <td class="td_l body-name" nowrap><?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"){//客户名称?>
        <a class="cid<?php echo $row['id']?>" id="cid<?php echo $row['id']?>" onClick="Views('view_gendan',<?php echo $row['id']?>,'<?php echo $row['name']?>')"> <?php echo $row['chengjiao']=='是' ? '<span class="btn1 chengjiao"> 成交 </span>' : '' ; echo $row['name']?> </a>
        <?php if($row['isshare']=='是'&&$row['nowuser']==$this->session->userdata('realname')){?>
        <span title="我共享给别人的客户"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
        <?php }else if($row['isshare']=='是'&&$row['nowuser']!=$this->session->userdata('realname')){?>
        <span title="别人共享给我的客户"><i class="fabtn fa fa-share-alt-square fa-flip-horizontal" style="background-color:#4dd0a4;"></i></span>
        <?php }?>
        <?php }}?></td>
      <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <td class="td_c lb_teshu zd_<?php echo $v['type']?> body-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"><?php echo $row[$v['name']];?></td>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"><?php
//时间字段转化
if($v['type']=='datetime'){
    if($row[$v['name']]=='0000-00-00 00:00:00'||empty($row[$v['name']])){
		echo '';	
	}else{
		switch ($v['content'])
		{
		case "yyyy-MM-dd":
			 echo date("Y-m-d",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm":
			 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm:ss":
			 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
			 break;
		default:
			 echo $row[$v['name']];
		}
	}
}else{
echo $row[$v['name']];	
}
?></td>
      <!--普通字段结束-->
      <?php }?>
      <?php }}}?>
      <td class="td_c bhh"><?php echo $row['squser']?></td>
      <td class="td_c bhh"><?php echo empty($row['sqtime']) ? '' : date("Y-m-d",strtotime($row['sqtime']));?></td>
      <td class="td_c bhh"><?php if(!empty($row["squser"])&&!empty($row["sqtime"])){?>
        <?php if($row["squser"]==$this->session->userdata('realname')){?>
        已申请
        <?php }else{?>
        他人申请
        <?php }?>
        <?php }else{?>
        <?php if ($this->common_model->check_lever(75)){?>
        <a class="btn1 color1 alert1" href="<?php echo site_url('gonghai/shenqing')?>?id=<?php echo $row['id']?>" data-title="申请" data-width="620" data-height="360"><i class="fa fa-plus-circle"></i>申请</a>
        <?php }?>
        <?php }?>
        <?php if($this->uri->segment(1)=='kehu'){?>
        <?php if ($this->common_model->check_lever(73)){?>
        <a class="btn1 edit alert1" href="<?php echo site_url('kehu/edit')?>?id=<?php echo $row['id']?>" data-title="编辑" data-width="620" data-height="550"><i class="fa fa-edit"></i>编辑</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(74)){?>
        <a class="btn1 del" onClick="art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('kehu/del')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-trash-o"></i>删除</a>
        <?php }?>
        <?php }elseif($this->uri->segment(1)=='gonghai'){?>
        <?php if ($this->common_model->check_lever(73)){?>
        <a class="btn1 edit alert1" href="<?php echo site_url('kehu/edit')?>?id=<?php echo $row['id']?>" data-title="编辑" data-width="620" data-height="550"><i class="fa fa-edit"></i>编辑</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(74)){?>
        <a class="btn1 del" onClick="art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('kehu/del')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-trash-o"></i>删除</a>
        <?php }?>
        <?php }elseif($this->uri->segment(1)=='huishouzhan'){?>

        <?php }?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">录入时间：<?php echo $row['addtime']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">更新时间：<?php echo $row['updtime']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">录入人员：<?php echo $row['adduser']?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;现业务员：<?php echo $row['nowuser']?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;共享人员：<?php echo $row['share_users']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">详细备注：<?php echo $row['content']?></td>
    </tr>
  </tbody>
  <?php 
 }} else {
?>    <tfoot>
      <tr>
        <td class="td_c nodata" colspan="50"> 抱歉，暂无相关记录！ </td>
      </tr>
    </tfoot>
  <?php }?>
</table>
<script>
  $(".z_linkman").show();
  $(".z_mobile").show();
  $(".z_qq").show();
  $(".z_email").show();
  $(".z_content").show();
</script> 
 