<?php if($this->common_model->is_mobile()==1){ //手机端?>

<div style="height:60px;line-height:60px;clear:both;"></div>
<footer class="footer" id="footer">
  <ul class="footnav box-flex">
    <li><a href="/"><i class="fa fa-home"></i>首页</a></li>
    <li><a href="<?php echo site_url('kehu/index')?>"><i class="fa fa-users"></i>客户</a></li>
    <li><a href="<?php echo site_url('tongxunlu/index')?>"><i class="fa fa-address-book-o"></i>通讯录</a></li>
    <li><a href="<?php echo site_url('message/index')?>"><i class="fa fa-commenting"></i>消息</a></li>
    <li><a href="<?php echo site_url('user/info')?>"><i class="fa fa-user-o"></i>我的</a></li>
  </ul>
</footer>


<script>

var zong_width=($(window).width()-10-10);
var dan_width=zong_width/3;

$(".icon-list").css("width",($(window).width()-5)+"px");

$(".icon-list li").css("width",dan_width+"px");


//展开高级搜索
$(".sousuo-gj .input").css("min-width","80px");
$(".sousuo-gj .input").css("width",(($(window).width()-100-20))+"px");
$(".sousuo-gj input.rule-date-input").css("min-width","105px");
$(".sousuo-gj input.rule-date-input").css("width",(($(window).width()-100-38)/2)+"px");


if($("#timo1 .btn-sou-gj").length>0) 
{ 

$(" #timo1 .btn-sou-ks").css("width","50px");
$(".icon-list #timo1 li.btn-sou-gj").css("width","90px");
$(".icon-list #timo1 li.btn-sou-input").css("width",($(window).width()-70-90-20)+"px");


}else{

$(" #timo1 .btn-sou-ks").css("width","70px");
$(".icon-list #timo1 li.btn-sou-input").css("width",($(window).width()-90-15)+"px");
	
}



if($("#timo2").length>0){  

	$("#timo2").append('<li><a class="btn2" href="/"><i class="fa fa-home"></i>返回主页</a></li>');  
	$("#timo2 li").removeAttr("style");
	
	$('.m_menu').click(function(){
		$("#timo2").toggle('slow');
	});  
	
}else{
	$(".m_right a .fa").removeClass("fa-bars");
	$(".m_right a .fa").addClass("fa-home");
	$('.m_menu').click(function(){
	self.location="/";
	}); 
}


$('.m_search').click(function(){
	$("#timo1").toggle('slow');
});

</script>

<?php }else{ //pc端?>



<script>


$(".sousuo-gj input.rule-date-input").css("max-width","150px");
$(".sousuo-gj input.rule-date-input").css("min-width","105px");
$(".sousuo-gj input.rule-date-input").css("width",(($(window).width()/3-32-100-15)/2)+"px");


function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}

function changeURLArg(url,arg,arg_val){ 
   var pattern=arg+'=([^&]*)'; 
   var replaceText=arg+'='+arg_val; 
   if(url.match(pattern)){ 
	   var tmp='/('+ arg+'=)([^&]*)/gi'; 
	   tmp=url.replace(eval(tmp),replaceText); 
	   return tmp; 
   }else{ 
	   if(url.match('[\?]')){ 
		   return url+'&'+replaceText; 
	   }else{ 
		   return url+'?'+replaceText; 
	   } 
  } 
   return url+'\n'+arg+'\n'+arg_val; 
}

$("th a.paixu").each(function(){
    $(this).append('<span><i class="fa fa-caret-up"></i><i class="fa fa-caret-down"></i></span>');
	var url_pai = GetQueryString("pai");
	var url_xu = GetQueryString("xu");
	var data_pai = $(this).attr('ziduan');
	if(url_pai==data_pai){
	$(this).attr('paixu', url_xu);
	$(this).addClass('on_'+url_xu);
	}
});

$("th a.paixu").click(function(){
    var ziduan_name = $(this).attr('ziduan');
	var ziduan_paixu = $(this).attr('paixu');
	if(ziduan_paixu=='desc'){
		new_xu = 'asc';
	}else{
		new_xu = 'desc';
	}
	var old_url_full = $('.pagination .shouye a').attr('href');
	var new_url_full = changeURLArg(old_url_full,'pai',ziduan_name);
	new_url_full = changeURLArg(new_url_full,'xu',new_xu);
	self.location.href = new_url_full;

});


</script>

<?php }?>

<!--公用-->
<script>
$(function(){
	

<?php if($this->input->get('cid', TRUE)>0){?>
$("#headmenu").hide();
$(".b-toolbar").hide();
<?php }?>


$(".search-toggle").click(function(){
  $(".sousuo-gj").toggle();
});

	
//免费版链接处理
var banben="<?php echo $this->common_model->banben?>";
if(banben=="mfb"){
$(".freeno a , a.freeno").each(function(){
var newurl="/themes/free.htm";
$(this).attr("href",newurl);
$(this).attr("data-title","免费版不支持");
$(this).attr("data-width","590");
$(this).attr("data-height","480");
$(this).removeAttr("onclick");
});
}
})
//关闭后返回提示并刷新
<?php if(SUCCESSTIP==1){ //提示?>
function close_reload(tips){
layer.msg(tips,{anim:5,maxWidth:500,icon:1,time:1000,end:function(){location.reload()}})
}
<?php }else{?>
function close_reload(tips){
location.reload();
}
<?php }?>
</script>