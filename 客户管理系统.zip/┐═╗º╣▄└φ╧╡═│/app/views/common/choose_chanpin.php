<?php if(!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1,maximum-scale=1">
<!--设备的缩放-->
<meta name="format-detection" content="telephone=no" >
<!--禁止自动识别数字为手机号码-->
<meta name="apple-mobile-web-app-capable" content="yes">
<!--去掉苹果工具栏和菜单栏-->
<meta name="apple-touch-fullscreen" content="yes">
<!--全屏-->

<title>管理页面</title>
<?php $this->load->view('common/inc_styles.php');?>
</head>

<body class="mainbody">
<div class="mian-page-div"> 
  
  <!--导航栏-->
  <?php $this->load->view('common/inc_head.php');?>
  <!--/导航栏--> 
  
  <!--工具栏-->
  <div class="toolbar">
    <div class="l-list">
      <ul class="icon-list">
        <li><a class="btn2 <?php echo $timetype=='' ? 'hover' : ''?>" href="?"><i class="fa fa-list"></i>所有产品</a></li>
        <span id="timo1">
        <form name="searchForm" action="?sou=soufast" method="post">
          <li class="btn-sou-input">
            <input name="keyword" type="text" value="<?php echo $keyword?>" class="input input-sou1" placeholder="产品名称、备注">
          </li>
          <label class="btn2 color4 btn-sou-ks">
            <input type="submit" name="Submit" value="" />
            <i class="fa fa-search"></i>搜索 </label>
        </form>
        </span>
      </ul>
    </div>
    <div class="clear"></div>
  </div>
  <!--/工具栏--> 
  
  <!--列表-->
  <div class="table-container">
    <form method="post">
      <div class="table-list">
        <table class="table tree_table">
          <thead>
            <tr class="">
              <th nowrap class="td_c">选择</th>
              <th width="60" nowrap><a class="paixu" ziduan="id" paixu=""> 编号 </a></th>
              <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
              <?php if($v['lb_teshu']==1){//特殊字段?>
              <!--特殊字段开始-->
              <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
              <!--特殊字段结束-->
              <?php }else{//普通字段?>
              <!--普通字段结束-->
              <th width="100" class="td_c bhh head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
              
              <!--普通字段结束-->
              <?php }?>
              <?php			
}}}
?>
            </tr>
          </thead>
          <?php 
	$arr_ids = explode(',',$ids);
	if (count($list)>0) {
	foreach($list as $arr=>$row) {?>
          <tbody>
            <tr class="tr" <?php if(in_array($row['id'],$arr_ids)){ echo 'style="background-color:#FFFED9"'; } ?>>
              <td class="td_c"><span class="checkall pretty primary">
                <input type="checkbox" class="aids" value="<?php echo $row['id']?>" <?php if(in_array($row['id'],$arr_ids)){ echo 'checked'; } ?>/>
                <label><i class="mdi mdi-check"></i></label>
                </span></td>
              <td class="td_c"><?php echo $row['id']?></td>
              <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
              <?php if($v['lb_teshu']==1){//特殊字段?>
              
              <!--产品：缩略图-->
              <?php if($v['name']=='pic'){?>
              <td class="td_c lb_teshu zd_<?php echo $v['type']?>"><span id="<?php echo $v['name']?>_view" class="picview"><img src="<?php echo $row[$v['name']];?>"></span></td>
              <?php }else{?>
              <!--end-->
              
              <td class="td_c lb_teshu zd_<?php echo $v['type']?>"><?php echo $row[$v['name']];?></td>
              <?php }?>
              <?php }else{//普通字段?>
              <!--普通字段结束-->
              <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?>"><?php
//时间字段转化
if($v['type']=='datetime'){
    if($row[$v['name']]=='0000-00-00 00:00:00'||empty($row[$v['name']])){
		echo '';	
	}else{
		switch ($v['content'])
		{
		case "yyyy-MM-dd":
			 echo date("Y-m-d",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm":
			 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm:ss":
			 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
			 break;
		default:
			 echo $row[$v['name']];
		}
	}
}else{
echo $row[$v['name']];	
}
?></td>
              <!--普通字段结束-->
              <?php }?>
              <?php			
}}}
?>
            </tr>
          </tbody>
          <?php 
 }} else {
?>
          <tfoot>
            <tr>
              <td class="td_c nodata" colspan="50"> 抱歉，暂无相关记录！ </td>
            </tr>
          </tfoot>
          <?php }?>
        </table>
      </div>
      <!--工具栏-->
      <div class="b-toolbar">
        <div class="inner">
          <ul class="icon-list2">
            <li style="line-height:30px;padding-right:5px;"> <span class="checkall pretty primary">
              <input type="checkbox" class="checkall" value="" id="checkall"/>
              <label><i class="mdi mdi-check"></i> 全选</label>
              </span> </li>
            <li><a class="btn2 color4 col-del" onclick="chooses();"><i class="fa fa-check"></i>确认选择并返回</a></li>
          </ul>
          <!--分页代码开始-->
          <?php $this->load->view('common/inc_pages.php');?>
          <!--分页代码结束--> 
        </div>
        <div class="clear"></div>
      </div>
      <!--/工具栏-->
      
    </form>
  </div>
  
  <!--/列表-->  <!--底部-->
  <?php $this->load->view('common/inc_foot.php');?>
  <!--/底部--> 
  
</div>  
<script>
	
//单选
$(".aids").click(function(){
	if($(this).prop('checked')){
		$(this).parents('tr').css('background-color','#FFFED9');
	}else{
		$(this).parents('tr').css('background-color','');
	}
});

//单选新增
$(".check_td").click(function(){
	if($(this).parents('tr').find(".aids").prop('checked')){
		$(this).parents('tr').css('background-color','');
		$(this).parents('tr').find(".aids").attr("checked",false);
	}else{
		$(this).parents('tr').css('background-color','#FFFED9');
		$(this).parents('tr').find(".aids").attr("checked",true);
	}
});

//多选
$("#checkall").click(function(){
	if($(this).is(':checked')==true){
		//全部添加选中并添加消背景
		$(".aids").prop('checked', true).parents('tr').css('background-color','#FFFED9');
	}
	else{
		//全部取消选中并取消背景
		$(".aids").prop('checked', false).parents('tr').css('background-color','');
	}
});

function getids() {
	var arrchk = $("input.aids:checked");
	var id="";
	$(arrchk).each(function(){
		if (id=="") {
			  id+=this.value
		} else {
			  id+=","+this.value
		}                   
	}); 
	return id; 
} 

function chooses() {
	
   if (!getids()) {
	   layer.msg('未选中数据');
       return false;
   }

   $.dialog.open.origin.ChoseOK(getids());art.dialog.close();
   
};

</script>
</body>
</html>