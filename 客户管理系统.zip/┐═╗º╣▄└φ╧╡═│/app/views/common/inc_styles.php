<?php if(!defined('BASEPATH')) exit('No direct script access allowed');?>
<?php if($this->common_model->is_mobile()==1){ //手机端?>
<meta name="viewport" content="width=device-width, initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="stylesheet" type="text/css" href="/themes/default/css/style_m.css" />
<link rel="stylesheet" type="text/css" href="/themes/default/css/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="/themes/default/css/materialdesignicons.min.css"/>
<link type="text/css" rel="stylesheet" href="/themes/default/css/pretty.min.css">
<link type="text/css" rel="stylesheet" href="/themes/layui/css/layui.css" />
<script src="/themes/default/js/jquery-1.11.2.min.js"></script>
<script src="/themes/default/js/validform_v5.3.2_min.js"></script>
<script src="/themes/default/js/dialog-plus-min.js"></script>
<script src="/themes/default/js/common_m.js"></script>
<script src="/themes/default/js/WdatePicker/WdatePicker.js"></script>
<script src="/themes/layer/layer.js"></script>
<script src="/themes/default/js/table-ul.js"></script>
<script type="text/javascript">
$(function () {
	//初始化表单验证
	$("#form1").initValidform();
	//表格显示
	$(".table-list").settable();
	
	
    /*弹出窗口封装代码*/
    /*$(".alert1").on("click",
    function() {
        var width = $(this).data("width") ? $(this).data("width") : 900,
        //获得宽度
        height = $(this).data("height") ? $(this).data("height") : 400 //获得高度
        height = $(document).height() < height ? '80%': height;
        url = $(this).attr("href") //获得打开URL
        title = $(this).data("title"); //获得标题	
        $.dialog.open(url, {
            title: title,
            width: '100%',
            height: '100%',
            fixed: true,
            lock: false,
            id: window.name,
			close: function () {
			$("body").css("overflow","auto");
            }
        });
		$("body").css("overflow","hidden");
        return false;
    })*/

    /*弹出窗口封装代码*/
    $(".alert2").on("click",
    function() {

        var width = $(this).data("width") ? $(this).data("width") : 900,
        //获得宽度
        height = $(this).data("height") ? $(this).data("height") : 400 //获得高度
        height = $(document).height() < height ? '80%': height;
        url = $(this).attr("href") //获得打开URL
        title = $(this).data("title"); //获得标题	
        anim = $(this).data("anim");
        chkall = $(this).data("chkall");

        if (chkall == "1") {
            if ($(".checkall input:checked").size() < 1) {
                layer.msg('未选中数据');
                return false;
            }
        }

        $.dialog.open(url, {
            title: title,
            width: '100%',
            height: '100%',
            fixed: true,
            lock: false,
            id: window.name
        });
        return false;
    })

	
	
});
</script>
<?php }else{ //PC端 ?>
<link rel="stylesheet" type="text/css" href="/themes/default/css/style.css?v=2.0" />
<link rel="stylesheet" type="text/css" href="/themes/default/css/font-awesome.min.css" />
<link type="text/css" rel="stylesheet" href="/themes/default/css/materialdesignicons.min.css"/>
<link type="text/css" rel="stylesheet" href="/themes/default/css/pretty.min.css">
<link type="text/css" rel="stylesheet" href="/themes/layui/css/layui.css" />
<script src="/themes/default/js/jquery-1.11.2.min.js"></script>
<script src="/themes/default/js/validform_v5.3.2_min.js"></script>
<script src="/themes/default/js/dialog-plus-min.js"></script>
<script src="/themes/default/js/common.js"></script>
<script src="/themes/default/js/WdatePicker/WdatePicker.js"></script>
<script src="/themes/default/js/jquery.artDialog.js?skin=default"></script>
<script src="/themes/layer/layer.js"></script>
<script type="text/javascript">
$(function () {
	//初始化表单验证
	$("#form1").initValidform();

    /*弹出窗口封装代码*/
    $(".alert1").on("click",
    function() {
        var width = $(this).data("width") ? $(this).data("width") : 900,
        //获得宽度
        height = $(this).data("height") ? $(this).data("height") : 400 //获得高度
        height = $(document).height() < height ? '80%': height;
        url = $(this).attr("href") //获得打开URL
        title = $(this).data("title"); //获得标题	
        $.dialog.open(url, {
            title: title,
            width: width,
            height: height,
            fixed: true,
            lock: false,
            id: window.name,
			close: function () {
			
            }
        });
        return false;
    })

    /*弹出窗口封装代码*/
    $(".alert2").on("click",
    function() {

        var width = $(this).data("width") ? $(this).data("width") : 900,
        //获得宽度
        height = $(this).data("height") ? $(this).data("height") : 400 //获得高度
        height = $(document).height() < height ? '80%': height;
        url = $(this).attr("href") //获得打开URL
        title = $(this).data("title"); //获得标题	
        anim = $(this).data("anim");
        chkall = $(this).data("chkall");

        if (chkall == "1") {
            if ($(".checkall input:checked").size() < 1) {
                layer.msg('未选中数据');
                return false;
            }
        }

        $.dialog.open(url, {
            title: title,
            width: width,
            height: height,
            fixed: true,
            lock: false,
            id: window.name
        });
        return false;
    })
	
	
	
});
</script>
<?php }?>

