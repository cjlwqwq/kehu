<link rel="stylesheet" type="text/css" href="/themes/default/css/llq.css" />
<div style="display: none" id="browser_ie">
  <div class=brower_info>
    <div class=notice_info>
      <p>你的浏览器版本过低，可能导致页面不能正常访问！<br>
        为了你能正常使用系统功能，请升级您的浏览器。</p>
    </div>
    <div class=browser_list> <span> <a href="https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=02049043_69_pg&wd=%E6%90%9C%E7%8B%97%E6%B5%8F%E8%A7%88%E5%99%A8&oq=%2526lt%253B60%25E6%25B5%258F%25E8%25A7%2588%25E5%2599%25A8&rsv_pq=e4bd1e01000995ca&rsv_t=1400tQHsp75aW1vXMTDlqjswNFdaWBy104nRGlLIuuxjZi68Z392U%2F9zdXBJzPglycbOAk0&rqlang=cn&rsv_enter=1&inputT=1510&rsv_sug3=4&rsv_sug1=4&rsv_sug7=100&rsv_sug2=0&rsv_sug4=1511" target=_blank> <img src="/themes/default/images/llq/01.png"><br>
      搜狗 </a> </span> <span><a href="https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=02049043_69_pg&wd=360%E6%B5%8F%E8%A7%88%E5%99%A8&oq=chrome%2520%25E6%25B5%258F%25E8%25A7%2588%25E5%2599%25A8&rsv_pq=ab1aef5f000a1139&rsv_t=3ca1BKN7Lvd49bt1glan%2F2tuvA1ZTTCtbFpbNre0M%2Fkf%2B5S4NHsc8YsjQ2xd0%2BQY%2B4E4AGI&rqlang=cn&rsv_enter=1&rsv_sug3=2&rsv_sug1=2&rsv_sug7=100&bs=chrome%20%E6%B5%8F%E8%A7%88%E5%99%A8" target=_blank><img
            src="/themes/default/images/llq/02.png"><br>
      360 </a></span> <span><a href="https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&tn=02049043_69_pg&wd=chrome%E6%B5%8F%E8%A7%88%E5%99%A8&oq=chrome%2520%25E6%25B5%258F%25E8%25A7%2588%25E5%2599%25A8&rsv_pq=c45d0a2100096dc1&rsv_t=5ecdy5aEl6aEQglzXH%2FRcNY%2F2CFz1GMT2FBGFxUOSX48GIm5n%2Fw4yFwV6Zkq0RlMIkn6fsU&rqlang=cn&rsv_enter=1&inputT=310&rsv_sug3=6&rsv_sug1=6&rsv_sug7=100&rsv_sug2=0&rsv_sug4=1084" target=_blank><img
            src="/themes/default/images/llq/04.png"><br>
      chrome </a></span> <span><a href="https://support.microsoft.com/zh-cn/help/17621/internet-explorer-downloads" target=_blank><img
            src="/themes/default/images/llq/03.png"><br>
      ie9及以上 </a></span> </div>
    <div class="clearxx"></div>
    <div class="tipxx">请注意使用浏览器极速模式：</div>
    <img src="/themes/default/images/jisu.jpg" width="700px;" style="border:1px solid #ddd;"> </div>
</div>
<SCRIPT>
$(function(){
if (!$.support.leadingWhitespace) {
	$("#browser_ie").show();
	$(".logo_box").hide();
}
})
</SCRIPT>