<table class="table tree_table">
  <thead>
    <tr class="">
      <th width="40" class="td_c bhh no-m">折叠</th>
      <th width="40" class="td_c bhh">选择</th>
      <th width="40" class="td_c bhh no-m"> <a class="paixu" ziduan="id" paixu=""> 编号 </a> </th>
      <th width="100" class="td_l bhh"> <?php foreach($ziduan_xitong as $arr=>$v) {
        if($v["name"]=="name"){//客户名称?>
        <a class="paixu head-<?php echo $v['name']?>" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a>
        <?php }}?>
      </th>
      <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu head-<?php echo $v['name']?>" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <th width="100" class="td_c bhh head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--普通字段结束-->
      <?php }?>
      <?php	
}}}
?>
      <th width="60" class="td_c bhh">操作</th>
    </tr>
  </thead>
  <?php 
 if (count($list)>0) {
 foreach($list as $arr=>$row) {?>
  <tbody>
    <tr class="tr">
      <td class="td_c no-m"><span class="zmdi fa fa-chevron-circle-down"></span></td>
      <td class="td_c"><span class="checkall pretty primary">
        <input type="checkbox" class="aids" value="<?php echo $row['id']?>"/>
        <label><i class="mdi mdi-check"></i></label>
        </span></td>
      <td class="td_c bhh no-m"><?php echo $row['id']?></td>
      <td class="td_l body-name"><?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"){//客户名称?>
        <a class="cid<?php echo $row['id']?>" id="cid<?php echo $row['id']?>" onClick="Views('view_gendan',<?php echo $row['id']?>,'<?php echo $row['name']?>')"> <?php echo $row['chengjiao']=='是' ? '<span class="btn1 chengjiao"> 成交 </span>' : '' ; echo $row['name']?> </a>
        <?php if($this->session->userdata('roleid')==0&&$row['isshare']=='是'){?>
        <span class="sharebtn" title="共享类客户" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $row['share_users']?>"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
        <?php }else{?>
        <?php if($row['isshare']=='是'&&$row['nowuser']==$this->session->userdata('realname')){?>
        <span class="sharebtn" title="我共享给别人" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $row['share_users']?>"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
        <?php }else if($row['isshare']=='是'&&$row['nowuser']!=$this->session->userdata('realname')&&in_array($this->session->userdata('realname'),explode(",",$row['share_users']))){?>
        <span class="sharebtn" title="别人共享给我" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $row['share_users']?>"><i class="fabtn fa fa-share-alt-square fa-flip-horizontal" style="background-color:#4dd0a4;"></i></span>
        <?php }?>
        <?php }?>
        <span> <i class="fa fa-fax fabtn color6" id="telbtn" cid="<?php echo $row['id']?>" mobile="<?php echo $row['mobile']?>" title="拨打电话"></i> <i class="fa fa-envelope-o fabtn color5 alert1" href="<?php echo site_url('sms/send')?>?mobile=<?php echo $row['mobile']?>" data-title="发送短信" data-width="660" data-height="350"  title="发送短信"></i> </span>
        <?php }}?></td>
      <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <td class="td_c lb_teshu zd_<?php echo $v['type']?> body-<?php echo $v['name']?>"><?php echo $row[$v['name']];?></td>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>">
	  
<?php
//时间字段转化
if($v['type']=='datetime'){
    if($row[$v['name']]=='0000-00-00 00:00:00'||empty($row[$v['name']])){
		echo '';	
	}else{
		switch ($v['content'])
		{
		case "yyyy-MM-dd":
			 echo date("Y-m-d",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm":
			 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm:ss":
			 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
			 break;
		default:
			 echo $row[$v['name']];
		}
	}
}else{
echo $row[$v['name']];	
}
?>

</td>
      <!--普通字段结束-->
      <?php }?>
      <?php }}}?>
      <td class="td_c bhh"><?php if($this->uri->segment(1)=='kehu'){?>
        <?php if ($this->common_model->check_lever(3)){?>
        <a class="btn1 edit alert1" href="<?php echo site_url('kehu/edit')?>?id=<?php echo $row['id']?>" data-title="编辑" data-width="620" data-height="550"><i class="fa fa-edit"></i>编辑</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(4)){?>
        <a class="btn1 del alert1" href="<?php echo site_url('kehu/dels')?>?id=<?php echo $row['id']?>" data-title="删除" data-width="620" data-height="350"><i class="fa fa-trash-o"></i>删除</a>
        <?php }?>
        <?php }elseif($this->uri->segment(1)=='gonghai'){?>
        <?php }elseif($this->uri->segment(1)=='huishouzhan'){?>
        <?php if ($this->common_model->check_lever(82)){?>
        <a class="btn1 edit" onClick="art.dialog({content: '是否将该客户还原到员业务员名下？',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('huishouzhan/restore')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-reply"></i>还原</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(83)){?>
        <a class="btn1 del" onClick="art.dialog({content: '是否确定彻底删除？<BR>彻底删除包括：【客户管理、联系人、跟单、订单、合同<BR>售后、收支、附件等所有相关记录】',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('huishouzhan/del')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-trash-o"></i>彻底删除</a>
        <?php }?>
        <?php }?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">录入时间：<?php echo $row['addtime']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">更新时间：<?php echo $row['updtime']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">录入人员：<?php echo $row['adduser']?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;现业务员：<?php echo $row['nowuser']?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;共享人员：<?php echo $row['share_users']?></td>
    </tr>
    <tr class="table-hide no-m">
      <td></td>
      <td class="td_l" colspan="16">详细备注：<?php echo $row['content']?></td>
    </tr>
  </tbody>
  <?php 
 }} else {
?>
  <tfoot>
    <tr>
      <td class="td_c nodata" colspan="50"> 抱歉，暂无相关记录！ </td>
    </tr>
  </tfoot>
  <?php }?>
</table>
<script>
$('#telbtn').on('click',function(){

	<?php if($this->sqm = $this->mysql_model->get_rows('config', array('isdel' => 0, 'name' => 'call_open'), 'value')=='1'){?>
	
	parent.OnGetConnectedState();//检测通话状态
	
	var device_state = parent.get_device_state();
	
	if(device_state=='1'){
	var cid = $(this).attr('cid');
	var mobile = $(this).attr('mobile');
	if(mobile==null){
	layer.alert("手机号码不能为空");
	}else{
	layer.confirm(mobile, {
	  title: '是否立即拨号？',
	  btn: ['拨号','取消'] //按钮
	}, function(index, layero){
	  parent.OnDailout(cid,mobile);
	  layer.close(index);
	}, function(){
	  
	});	
	}
	}else{
	layer.alert("未检测到呼叫设备！");
	}
	
	<?php }else{?>
	
	layer.alert("未检测到呼叫设备！");
	
	<?php }?>
	
	
});

$('.sharebtn').on('click',function(){

var nowuser = $(this).attr('nowuser');
var share_users = $(this).attr('share_users');
layer.alert("共享者："+nowuser+"<br>共享给："+share_users);
	
});

</script> 
