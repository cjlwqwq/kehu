<?php if(!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,minimum-scale=1,maximum-scale=1">
<!--设备的缩放-->
<meta name="format-detection" content="telephone=no" >
<!--禁止自动识别数字为手机号码-->
<meta name="apple-mobile-web-app-capable" content="yes">
<!--去掉苹果工具栏和菜单栏-->
<meta name="apple-touch-fullscreen" content="yes">
<!--全屏-->

<title>管理页面</title>
<?php $this->load->view('common/inc_styles.php');?>
<style>
.table th a{ color:#333;}
</style>
</head>

<body class="mainbody">
<div class="mian-page-div"> 
  
  <!--导航栏-->
  <?php $this->load->view('common/inc_head.php');?>
  <!--/导航栏--> 
  
  <!--工具栏-->
  <div class="toolbar">
    <div class="l-list">
      <ul class="icon-list">
        <li><a class="btn2 <?php echo $timetype=='' ? 'hover' : ''?>" href="?"><i class="fa fa-list"></i>所有客户</a></li>
        <li><a class="btn2 <?php echo $timetype=='d' ? 'hover' : ''?>" href="?timetype=d"><i class="fa fa-clock-o"></i>今日新增</a></li>
        <li><a class="btn2 <?php echo $timetype=='w' ? 'hover' : ''?>" href="?timetype=w"><i class="fa fa-clock-o"></i>本周新增</a></li>
        <li><a class="btn2 <?php echo $timetype=='m' ? 'hover' : ''?>" href="?timetype=m"><i class="fa fa-clock-o"></i>本月新增</a></li>
        <?php if ($this->common_model->check_lever(33)){?>
        <li><a class="btn2 color1 alert1" href="<?php echo site_url('kehu/add')?>" data-title="新增客户" data-width="620" data-height="550"><i class="fa fa-plus"></i>新增客户</a></li>
        <?php }?>
        <span id="timo2" style="display:none;">
        <li class="m-no"><a class="btn2 btn-primary tree_table_all_open waves-effect" href="javascript:;" id="zksqAll" data-target="#contents"><i class="fa fa-caret-down"></i>全部展开</a></li>
        <li><a class="btn2" href="javascript:location.reload();"><i class="fa fa-refresh"></i>刷新</a></li>
        <?php if ($this->common_model->check_lever(6)){?>
        <li class="m-no"><a class="btn2 alert1" href="<?php echo site_url('kehu/daoru')?>" data-title="客户导入" data-width="620" data-height="350"><i class="fa fa-sign-in"></i>导入</a></li>
        <?php }?>
        <?php if ($this->common_model->check_lever(7)){?>
        <li class="m-no"><a class="btn2 alert1" href="<?php echo site_url('kehu/daochu')?>" data-title="数据导出" data-width="620" data-height="350"><i class="fa fa-sign-out"></i>导出</a></li>
        <?php }?>
        <?php if ($this->common_model->check_lever(210)){?>
        <li class="m-no"><a class="btn2 color10 alert1" href="<?php echo site_url('ziduan/index')?>?style=1&type=kehu" data-title="字段设置" data-width="1100" data-height="550"><i class="fa fa-navicon"></i>字段设置</a></li>
        <?php }?>
        </span> <span id="timo1">
        <form name="searchForm" action="?sou=soufast" method="post">
          <li class="btn-sou-input">
            <input name="keyword" type="text" value="<?php echo $keyword?>" class="input input-sou1" placeholder="客户名称、联系人、手机">
          </li>
          <label class="btn2 color4 btn-sou-ks">
            <input type="submit" name="Submit" value="" />
            <i class="fa fa-search"></i>搜索 </label>
          <li class="btn-sou-gj"><a class="btn2 search-toggle"><i class="fa fa-search-plus"></i>高级搜索</a></li>
        </form>
        </span>
      </ul>
    </div>
    <div class="clear"></div>
    <div class="sousuo-gj" <?php if ($sou=="soudetail"){?>style="display:block;"<?php }?>>
      <form name="searchForm" action="?sou=soudetail" method="post">
        <?php $this->load->view('common/ziduan_sousuo.php');?>
        <div style="text-align:center; padding:10px; clear:both; border-top:2px solid #ECE9E9;">
          <input type="submit" class="btn2 sousuo" value="立即搜索" />
          <input type="button" class="btn2 close" value="清空条件" onClick=window.location.href="?" />
        </div>
      </form>
    </div>
  </div>
  <!--/工具栏--> 
  
  <!--列表-->
  <div class="table-container">
    <form method="post">
      <div style="font-size:18px; color:#f00; text-align:center; line-height:35px;">点击客户即可选中</div>
      <div class="">
        <table class="table tree_table">
          <thead>
            <tr class="">
              <th width="60" class="td_c" nowrap><a class="paixu" ziduan="id" paixu=""> 编号 </a></th>
              <?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"&&$n["inuse"]=="是"){?>
              <th width="160" class="td_c bhh"> <a class="paixu" ziduan="<?php echo $n['name']?>" paixu=""> <?php echo $n['title']?> </a> </th>
              <?php }}?>
      <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu head-<?php echo $v['name']?>" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <th width="100" class="td_c bhh head-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--普通字段结束-->
      <?php }?>
      <?php	
}}}
?>
            </tr>
          </thead>
          <?php 
 if (count($list)>0) {
 foreach($list as $arr=>$row) {?>
          <tbody>
            <tr class="tr" onclick=window.location.href="javascript:<?php if($this->common_model->is_mobile()==1){ //手机端?>M_ChoseOK(<?php echo $row['id']?>);<?php }else{?>$.dialog.open.origin.ChoseOK(<?php echo $row['id']?>);$.dialog.close();<?php }?>" style="cursor:pointer;" title="点击选中客户">
              <td class="td_c" nowrap><?php echo $row['id']?></td>
              <?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"&&$n["inuse"]=="是"){?>
              <td class="td_l bhh"><a class="cid<?php echo $row['id']?>" id="cid<?php echo $row['id']?>">
                <?php if ($row['chengjiao']=='是'){?>
                <span class='btn1 chengjiao'> 成交 </span>
                <?php }?>
                <?php echo $row['name']?></a>
                <?php if($row['isshare']=='是'&&$row['nowuser']==$this->session->userdata('realname')){?>
                <span title="我共享给别人的客户"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
                <?php }else if($row['isshare']=='是'&&$row['nowuser']!=$this->session->userdata('realname')){?>
                <span title="别人共享给我的客户"><i class="fabtn fa fa-share-alt-square fa-flip-horizontal" style="background-color:#4dd0a4;"></i></span>
                <?php }?></td>
              <?php }}?>
              
              
              
      <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <td class="td_c lb_teshu zd_<?php echo $v['type']?> body-<?php echo $v['name']?>"><?php echo $row[$v['name']];?></td>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?> <?php echo $v['name']=="name" ? 'none' : ''?>"><?php
	  
switch ($v['content'])
{
case "yyyy-MM-dd":
	 echo date("Y-m-d",strtotime($row[$v['name']]));
	 break;
	 
case "yyyy-MM-dd HH:mm":
	 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
	 break;
	 
case "yyyy-MM-dd HH:mm:ss":
	 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
	 break;
	 
default:

    if($v['type']=='textarea'&&strlen($row[$v['name']])>20){
		 
	echo str_cut($row[$v['name']],20,0);
		 
	}else{
		 
	echo $row[$v['name']];
		 
	}
	 
}
	  
?></td>
      <!--普通字段结束-->
      <?php }?>
      <?php }}}?>
            </tr>
          </tbody>
          <?php 
 }} else {
?>
          <tbody>
            <tr>
              <td class="td_c" colspan="47"> 抱歉，暂无相关记录！ </td>
            </tr>
          </tbody>
          <?php }?>
        </table>
      </div>
      <!--工具栏-->
      <div class="b-toolbar">
        <div class="inner"> 
          <!--菜单按钮列-->
          <div class="b-list" style="display:none;">
            <ul class="icon-list bottom-list">
              <?php if ($this->common_model->check_lever(12)){?>
              <li><a class="btn2 col-del" onclick="dels();"><i class="fa fa-trash-o"></i>批量删除</a></li>
              <?php }?>
              <?php if ($this->common_model->check_lever(36)){?>
              <li><a class="btn2" onclick="share();"><i class="fa fa-share-alt"></i>共享客户</a></li>
              <?php }?>
              <?php if ($this->common_model->check_lever(37)){?>
              <li><a class="btn2 " onClick="zhuanyi()"><i class="fa fa-exchange"></i>转移客户</a></li>
              <?php }?>
              <?php if ($this->common_model->check_lever(37)){?>
              <li><a class="btn2" onClick="zhuanyi_gh()"><i class="fa fa-users"></i>转移到公海</a></li>
              <?php }?>
              <!--<li><a class="btn2 alert2" href="kongbai.html" data-title="设置下次联系" data-width="620" data-height="360" data-chkall="1"><i class="fa fa-calendar"></i>设置下次联系</a></li>-->
              <div class="clear"></div>
            </ul>
          </div>
          <!--/菜单按钮列--> 
          
          <!--分页代码开始-->
          <?php $this->load->view('common/inc_pages.php');?>
          <!--分页代码结束--> 
        </div>
      </div>
      <!--/工具栏-->
      
    </form>
  </div>
  
  <!--/列表--> 
  
  <!--内容底部-->
  <div class="line20"></div>
  <?php $this->load->view('common/inc_foot.php');?>
</div>

<script>
function M_ChoseOK(cid){
	<?php if($choose_type){?>
	  <?php if($choose_type=='caiwu'){?>
		  location.href='/index.php/<?php echo $choose_type?>/add?cid='+cid+'&outin=<?php echo $choose_outin?>';
	  <?php }else{?>
		  location.href='/index.php/<?php echo $choose_type?>/add?cid='+cid;	  
	  <?php }?>
	<?php }else{?>
	layer.alert('参数错误', {icon: 0});
	<?php }?>
}
</script>
</body>
</html>