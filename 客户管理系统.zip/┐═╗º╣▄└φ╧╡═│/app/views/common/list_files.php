<table class="table tree_table">
  <thead>
    <tr class="">
      <th width="60" nowrap style="display:none;"><a class="paixu" ziduan="id" paixu=""> 编号 </a></th>
      <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      
      <?php if($v['name']=='filepath'){?>
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> 预览 </a> </th>
      <?php }else{//普通字段?>
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      <?php }?>
      
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <th width="100" class="td_c bhh head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a> </th>
      
      <!--普通字段结束-->
      <?php }?>
      <?php			
}}}
?>
      <th width="100" class="td_c bhh">管理</th>
    </tr>
  </thead>
  <?php 
	if (count($list)>0) {
	foreach($list as $arr=>$row) {?>
  <tbody>
    <tr class="tr">
      <td class="td_c" style="display:none;"><?php echo $row['id']?></td>
      <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      
      <?php if($v['name']=='filepath'){?>
      <td class="td_c lb_teshu zd_<?php echo $v['type']?>"><?php
	  
        $houzui=explode('.',$row[$v['name']]); 
        $houzui=$houzui[1]; 
		
if(strpos('jpg|png|gif',$houzui)!== false){ 
?>
        
<span class="picview"><img src="<?php echo $row[$v['name']];?>"></span>    

 <?php
}else{
?>
        <span class="picview"><img src="/themes/default/images/noview.png"></span>
<?php }?></td>
      <?php }else{//普通字段?>
      <td class="td_c lb_teshu zd_<?php echo $v['type']?>"><?php echo $row[$v['name']];?></td>
      <?php }?>
      
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?>"><?php
//时间字段转化
if($v['type']=='datetime'){
    if($row[$v['name']]=='0000-00-00 00:00:00'||empty($row[$v['name']])){
		echo '';	
	}else{
		switch ($v['content'])
		{
		case "yyyy-MM-dd":
			 echo date("Y-m-d",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm":
			 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm:ss":
			 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
			 break;
		default:
			 echo $row[$v['name']];
		}
	}
}else{
echo $row[$v['name']];	
}
?></td>
      <!--普通字段结束-->
      <?php }?>
      <?php			
}}}
?>
      <td class="td_c"><a class="btn1 mingxi" href="<?php echo $row['filepath']?>" download="<?php echo $row['title']?>"><i class="fa fa-download"></i>下载</a>
        <?php if ($this->common_model->check_lever(133)){?>
        <a class="btn1 edit alert1" href="<?php echo site_url('files/edit')?>?id=<?php echo $row['id']?>" data-title="编辑" data-width="620" data-height="360"><i class="fa fa-edit"></i>编辑</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(134)){?>
        <a class="btn1 del" onClick="art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('files/del')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-trash-o"></i>删除</a>
        <?php }?></td>
    </tr>
  </tbody>
  <?php 
 }} else {
?>
  <tfoot>
    <tr>
      <td class="td_c nodata" colspan="50"> 抱歉，暂无相关记录！ </td>
    </tr>
  </tfoot>
  <?php }?>
</table>
 