<?php if(!defined('BASEPATH')) exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>查看</title>
<meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,initial-scale=1.0,user-scalable=no" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<?php $this->load->view('common/inc_styles.php');?>
<style type="text/css">
.tree-list .col-1 { padding-left:1%; width:24%; }
.tree-list .col-2 { width:65%; }
.tree-list .col-3 { width:10%; text-align:center; }
.pretty { margin-right:5px; }
</style>
<script type="text/javascript">
    $(function () {
        //初始化表单验证
        $("#form1").initValidform();
        //初始化分类的结构
        initCategoryHtml('.tree-list', 1);
        //初始化分类的事件
        $('.tree-list').initCategoryTree(true);

        //权限全选
        $("input[name='checkall']").click(function () {
            if ($(this).prop("checked") == true) {
                $(this).parent().parent().siblings(".col").find("input[type='checkbox']").prop("checked", true);
            } else {
                $(this).parent().parent().siblings(".col").find("input[type='checkbox']").prop("checked", false);
            }
        });
    });
</script>
</head>
<body class="mainbody">
<div class="mian-page-div">
  <div class="tab-content" style="width:99%; margin:0 auto; min-height:250px;">
    <dl>
      <div class="tree-list">
        <div class="thead">
          <div class="col col-1">部门</div>
          <div class="col col-2">人员</div>
          <div class="col col-3">全选</div>
        </div>
        <ul>
          <?php foreach ($select_group as $arr=>$row) {?>
          <li class="layer-1">
            <div class="tbody">
              <div class="col index col-1"> <?php echo $row['name']?> </div>
              <div class="col col-2">
                <?php 
 foreach ($users as $arr1=>$row1) {
 if ($row1['groupid']==$row['id']) {
 ?>
                <span class="pretty primary">
                <input type="checkbox" name="user" value="<?php echo $row1['realname']?>" onClick="allusers()" <?php if($row1['realname']==$this->session->userdata('realname')){?>disabled="disabled"<?php }?>/>
                <label><i class="mdi mdi-check"></i> <?php echo $row1['realname']?> </label>
                </span>
                <?php }}?>
              </div>
              <div class="col col-3"> <span class="pretty primary" onClick="allusers()">
                <input type="checkbox" name="checkall"/>
                <label><i class="mdi mdi-check"></i> 全选 </label>
                </span> </div>
            </div>
          </li>
          <?php }?>
        </ul>
      </div>
    </dl>
  </div>
  <!--/内容--> 
  
  <!--工具栏-->
  <div class="h30"></div>
  <div class="page-footer">
    <div class="btn-wrap">
      <input type="hidden" id="users" value="">
      <input type="submit" value="确认选择" class="btn submit" onClick="javascript:$.dialog.open.origin.$('#tousers').val(document.getElementById('users').value);art.dialog.close();parent.layclose();"/>
      <input type="button" value="关闭" class="btn close" onclick="art.dialog.close();parent.layclose();" />
    </div>
  </div>
  <!--/工具栏--> 
</div>
<script>
function allusers(){
    obj = document.getElementsByName("user");
    check_val = [];
    for(k in obj){
        if(obj[k].checked)
            check_val.push(obj[k].value);
    }
	$("#users").val(check_val);
}
</script>
</body>
</html>