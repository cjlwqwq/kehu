<?php if($this->common_model->is_mobile()==1){ //手机端?>
<div class="location"> <a href="javascript:history.back(-1);" class="back"><i class="fa fa-reply-all"></i></a> <span id="mhead_title_name"></span> <span class="m_right"> <a href="javascript:void(0);" class="m_menu"><i class="fa fa-bars"></i></a></span> </div>
<div style="height:40px; clear:both;"></div>
<?php }?>
