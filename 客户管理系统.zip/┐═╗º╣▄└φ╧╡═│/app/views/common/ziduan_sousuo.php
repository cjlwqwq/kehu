<?php 
if (count($ziduan_sousuo)>0) {
//var_dump($ziduan_sousuo);exit;
foreach($ziduan_sousuo as $arr=>$v) {
?>
<?php if($v['type']=='text'||$v['type']=='textarea'||$v['type']=='area'||$v['type']=='money'){?>

<dl>
  <dt><?php echo $v['title']?>：</dt>
  <input name="<?php echo $v['name']?>" type="text" value="<?php echo ${$v['name']}?>" class="input"/>
</dl>
<?php }else if($v['type']=='yes'){?>
<?php if($v['table_name']=='caiwu'&&$v['name']=='outin'){?>
<dl>
  <dt><?php echo $v['title']?>：</dt>
  <div class="rule-multi-radio">
    <input type="radio" name="<?php echo $v['name']?>" value="" <?php echo ${$v['name']}=='' ? 'checked' : '' ?> />
    <label>所有</label>
    <input type="radio" name="<?php echo $v['name']?>" value="1" <?php echo ${$v['name']}=='1' ? 'checked' : '' ?> />
    <label>收入</label>
    <input type="radio" name="<?php echo $v['name']?>" value="0"  <?php echo ${$v['name']}=='0' ? 'checked' : '' ?> />
    <label>支出</label>
  </div>
</dl>
<?php }else{?>
<dl>
  <dt><?php echo $v['title']?>：</dt>
  <div class="rule-multi-radio">
    <input type="radio" name="<?php echo $v['name']?>" value="" <?php echo ${$v['name']}=='' ? 'checked' : '' ?> />
    <label>所有</label>
    <input type="radio" name="<?php echo $v['name']?>" value="是" <?php echo ${$v['name']}=='是' ? 'checked' : '' ?> />
    <label>是</label>
    <input type="radio" name="<?php echo $v['name']?>" value="否" <?php echo ${$v['name']}=='否' ? 'checked' : '' ?> />
    <label>否</label>
  </div>
</dl>
<?php }?>
<?php }else if($v['type']=='radio'){?>
<?php 
if(!empty($v['content'])){
$selectres = explode("|",$v['content']);
?>
<dl>
  <dt><?php echo $v['title']?>：</dt>
  <div class="rule-multi-radio">
    <?php foreach ($selectres as $key => $value) {?>
    <input id="<?php echo $v['name']?>_1" type="radio" name="<?php echo $v['name']?>" value="<?php echo $value?>" <?php echo ${$v['name']}==$value ? 'checked' : '' ?>/>
    <label for="<?php echo $v['name']?>_1"><?php echo $value?></label>
    <?php }?>
  </div>
</dl>
<?php }?>
<?php }else if($v['type']=='select'||$v['type']=='checkbox'){?>
<?php 
if(!empty($v['content'])){
$selectres = explode("|",$v['content']);
?>
<dl>
  <dt><?php echo $v['title']?>：</dt>
  <select name="<?php echo $v['name']?>" >
    <option value="">请选择...</option>
    <?php foreach ($selectres as $key => $value) {?>
    <option value="<?php echo $value?>" <?php echo ${$v['name']}==$value ? 'selected' : '' ?>><?php echo $value?></option>
    <?php }?>
  </select>
</dl>
<?php }?>
<?php }else if($v['type']=='datetime'){?>
<?php 
$sname='start_'.$v['name'];
$ename='end_'.$v['name'];
?>
<dl>
  <dt><?php echo $v['title']?>：</dt>
  <input name="start_<?php echo $v['name']?>" type="text" value="<?php echo ${$sname}?>" class="input rule-date-input" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd'})"/>
  ~
  <input name="end_<?php echo $v['name']?>" type="text" value="<?php echo ${$ename}?>" class="input rule-date-input" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd'})"/>
</dl>
<?php }else if($v['type']=='users'){?>
<dl>
  <dt> <?php echo $v['title']?>：</dt>
  <select name="<?php echo $v['name']?>">
    <option value="">请选择...</option>
    <?php foreach ($users as $arr=>$row) {?>
    <option value="<?php echo $row['realname']?>" <?php echo ${$v['name']}==$row['realname'] ? 'selected' : ''?>><?php echo $row['realname']?></option>
    <?php }?>
  </select>
</dl>
<?php }?>
<?php		
}}
?>
