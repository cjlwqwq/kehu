<table class="table tree_table">
  <thead>
    <tr class="">
      <th width="60" nowrap style="display:none;"><a class="paixu" ziduan="id" paixu=""> 编号 </a></th>
      <th width="100" nowrap <?php if(!empty($id)){?>style="display:none;"<?php }?>> <?php foreach($ziduan_xitong as $arr=>$n) {
		  if($n["name"]=="name"){//客户名称?>

        <a class="paixu" ziduan="<?php echo $n['name']?>" paixu=""> <?php echo $n['title']?> </a>

        <?php }}?>
      </th>
      <?php 
//自定义字段表头
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <th width="100" class="td_c bhh lb_teshu head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a>

      </th>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <th width="100" class="td_c bhh head-<?php echo $v['name']?>"> <a class="paixu" ziduan="<?php echo $v['name']?>" paixu=""> <?php echo $v['title']?> </a>

      </th>
      
      <!--普通字段结束-->
      <?php }?>
      <?php			
}}}
?>
      <th width="100" class="td_c bhh">管理</th>
    </tr>
  </thead>
  <?php 
	if (count($list)>0) {
	foreach($list as $arr=>$row) {?>
  <tbody>
    <tr class="tr">
      <td class="td_c" style="display:none;"><?php echo $row['id']?></td>
      <td nowrap="nowrap" class="td_l body-name" <?php if(!empty($id)){?>style="display:none;"<?php }?>>
        <a class="cid<?php echo $row['cid']?>" onClick="Views('view_shouhou',<?php echo $row['cid']?>,'<?php echo $row['name']?>')">
        <?php $yichengjiao = $this->mysql_model->get_rows('kehu',array('isdel'=>0,'id'=>$row['cid']),'chengjiao');
		echo $yichengjiao=='是' ? '<span class="btn1 chengjiao"> 成交 </span>' : '' ; echo $row['name']?></a>
        <?php
		$isshare = $this->mysql_model->get_rows('kehu',array('isdel'=>0,'id'=>$row['cid']),'isshare');
		$share_users = $this->mysql_model->get_rows('kehu',array('isdel'=>0,'id'=>$row['cid']),'share_users');
		
		if($this->session->userdata('roleid')==0&&$isshare=='是'){?>
        <span class="sharebtn" title="共享类客户" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $share_users?>"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
        <?php }else{?>
        <?php if($isshare=='是'&&$row['nowuser']==$this->session->userdata('realname')){?>
        <span class="sharebtn" title="我共享给别人" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $share_users?>"><i class="fabtn color3 fa fa-share-alt-square"></i></span>
        <?php }else if($isshare=='是'&&$row['nowuser']!=$this->session->userdata('realname')&&in_array($this->session->userdata('realname'),explode(",",$share_users))){?>
        <span class="sharebtn" title="别人共享给我" nowuser="<?php echo $row['nowuser']?>" share_users="<?php echo $share_users?>"><i class="fabtn fa fa-share-alt-square fa-flip-horizontal" style="background-color:#4dd0a4;"></i></span>
        <?php }?>
        <?php }?>
</td>
      <?php
//自定义字段内容
if (count($ziduan_liebiao)>0) {
foreach($ziduan_liebiao as $arr=>$v) {
	if($v['liebiao']==1){
?>
      <?php if($v['lb_teshu']==1){//特殊字段?>
      <!--特殊字段开始-->
      <td class="td_c lb_teshu zd_<?php echo $v['type']?> body-<?php echo $v['name']?>"><?php echo $row[$v['name']];?></td>
      <!--特殊字段结束-->
      <?php }else{//普通字段?>
      <!--普通字段结束-->
      <td class="td_c zd_<?php echo $v['type']?> body-<?php echo $v['name']?>">
	  
      
<?php
//时间字段转化
if($v['type']=='datetime'){
    if($row[$v['name']]=='0000-00-00 00:00:00'||empty($row[$v['name']])){
		echo '';	
	}else{
		switch ($v['content'])
		{
		case "yyyy-MM-dd":
			 echo date("Y-m-d",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm":
			 echo date("Y-m-d H:i",strtotime($row[$v['name']]));
			 break;
		case "yyyy-MM-dd HH:mm:ss":
			 echo date("Y-m-d H:i:s",strtotime($row[$v['name']]));
			 break;
		default:
			 echo $row[$v['name']];
		}
	}
}else{
echo $row[$v['name']];	
}
?>
      
      
      </td>
      <!--普通字段结束-->
      <?php }?>
      <?php			
}}}
?>
      <td class="td_c bhh"><?php if ($this->common_model->check_lever(53)){?>
        <a class="btn1 edit alert1" href="<?php echo site_url('shouhou/edit')?>?cid=<?php echo $row['cid']?>&id=<?php echo $row['id']?>" data-title="编辑" data-width="620" data-height="550"><i class="fa fa-edit"></i>编辑</a>
        <?php }?>
        <?php if ($this->common_model->check_lever(54)){?>
        <a class="btn1 del" onClick="art.dialog({content: '是否确定删除？',icon: 'error',ok: function () {art.dialog.open('<?php echo site_url('shouhou/del')?>?id=<?php echo $row['id']?>');},cancelVal: '关闭',cancel: true })"><i class="fa fa-trash-o"></i>删除</a>
        <?php }?></td>
    </tr>
  </tbody>
  <?php 
 }} else {
?>    <tfoot>
      <tr>
        <td class="td_c nodata" colspan="50"> 抱歉，暂无相关记录！ </td>
      </tr>
    </tfoot>
  <?php }?>
</table>
<script>
$(function() {
  $(".body-issolve").each(function(){
    if($.trim($(this).text())=="否"){
		$(this).parents('tr').find('.body-etime').text('');
		$(this).parents('tr').find('.body-solvecontent').text('');
	}
  });
})
</script>