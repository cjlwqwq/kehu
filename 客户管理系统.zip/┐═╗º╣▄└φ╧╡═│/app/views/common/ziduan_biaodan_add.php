<?php 
if (count($ziduan_biaodan)>0) {
foreach($ziduan_biaodan as $arr=>$v) {

if($v['bd_teshu']==1){
?>
<!--客户：客户名称-->
<?php if($v['table_name']=='kehu'&&$v['name']=='name'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="name"&&$n["inuse"]=="是"){
$get_value = '';
?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="name" type="text" value="<?php echo $get_value?>" class="input normal" <?php if($n["bitian"]=="1"){?>datatype="*"<?php }?> ajaxurl="<?php echo site_url('kehu/ajax_name')?>?act=edit&id=<?php echo empty($id) ? '0' : $id?>" />
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end--> 
<!--客户：手机号字段-->
<?php if($v['table_name']=='kehu'&&$v['name']=='mobile'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="mobile"&&$n["inuse"]=="是"){
$get_value = '';	
?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="mobile" type="text" value="<?php echo $get_value?>" class="input normal" <?php if($n["bitian"]=="1"){?>datatype="*"<?php }?> ajaxurl="<?php echo site_url('kehu/ajax_mobile')?>?act=edit&id=<?php echo empty($id) ? '0' : $id?>" />
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end--> 
<!--联系人：手机号字段-->
<?php if($v['table_name']=='linkman'&&$v['name']=='mobile'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="mobile"&&$n["inuse"]=="是"){
$get_value = '';	
?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="mobile" type="text" value="<?php echo $get_value?>" class="input normal" <?php if($n["bitian"]=="1"){?>datatype="m" errormsg="手机号格式错误"<?php }?> ajaxurl="<?php echo site_url('kehu/ajax_mobile')?>?act=edit&id=<?php echo empty($id) ? '' : $id?>" />
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end--> 
<!--跟单：下次联系-->
<?php if($v['table_name']=='gendan'&&$v['name']=='nexttime'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="nexttime"&&$n["inuse"]=="是"){
$get_value = '';
$remind = '';	
?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="nexttime" type="text" class="input rule-date-input" value="<?php echo $get_value?>" onfocus="WdatePicker({dateFmt:'yyyy-MM-dd HH:mm'})" <?php if($n["bitian"]=="1"){?>datatype="*" nullmsg="请选择日期"<?php }?>/>
    &nbsp;  
    提前：

      <select name='remind'>
        <option value="1" <?php echo $remind==1 ? 'selected' :''?>>1小时</option>
        <option value="2" <?php echo $remind==2 ? 'selected' :''?>>2小时</option>
        <option value="3" <?php echo $remind==3 ? 'selected' :''?>>3小时</option>
        <option value="24" <?php echo $remind==24 ? 'selected' :''?>>1　天</option>
        <option value="48" <?php echo $remind==48 ? 'selected' :''?>>2　天</option>
        <option value="72" <?php echo $remind==72 ? 'selected' :''?>>3　天</option>
        <option value="168" <?php echo $remind==168 ? 'selected' :''?>>1　周</option>
      </select>

    提醒 <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?></dd>
</dl>
<?php }}}?>
<!--end--> 
<!--订单：订单编号-->
<?php if($v['table_name']=='dingdan'&&$v['name']=='number'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="number"&&$n["inuse"]=="是"){	
?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="number" type="text" class="input normal <?php echo DINGDANNUMBER==1 ? 'readonly' : ''?>" value="<?php echo $number ?>" <?php if($n["bitian"]=="1"){?>datatype="*"<?php }?>   <?php echo DINGDANNUMBER==1 ? 'readonly' : ''?> style="width:205px;"/>
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end--> 
<!--订单：欠款-->
<?php if($v['table_name']=='dingdan'&&$v['name']=='qkmoney'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="qkmoney"&&$n["inuse"]=="是"){
$get_value = '';	
?>
<dl>
  <dt> 欠款 <font color="#F00">*</font></dt>
  <dd class="int_check nochange">
    <input name="qkmoney" type="text" value="<?php echo $get_value?>" class="input normal" datatype="/^-?[1-9]+(\.\d+)?$|^-?0(\.\d+)?$|^-?[1-9]+[0-9]*(\.\d+)?$/" style="width:165px;" readonly/>
    <span class="Validform_checktip">欠款自动计算</span> </dd>
</dl>
<script>
$("input[name='money']").on("change",function(){
var qknum = $("input[name='money']").val()-$("input[name='ysmoney']").val()
if((qknum.toString()).indexOf(".")!= -1) {
	qknum = (qknum).toFixed(2); //含有小数点
}
$("input[name='qkmoney']").val(qknum);
});
$("input[name='ysmoney']").on("change",function(){
var qknum = $("input[name='money']").val()-$("input[name='ysmoney']").val()
if((qknum.toString()).indexOf(".")!= -1) {
	qknum = (qknum).toFixed(2); //含有小数点
}
$("input[name='qkmoney']").val(qknum);
});
</script>
<?php }}}?>
<!--end--> 
<!--合同：合同编号-->
<?php if($v['table_name']=='hetong'&&$v['name']=='number'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="number"&&$n["inuse"]=="是"){?>
<dl>
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="number" type="text" class="input normal <?php echo HETONGNUMBER==1 ? 'readonly' : ''?>" value="<?php echo $number ?>" <?php if($n["bitian"]=="1"){?>datatype="*"<?php }?>   <?php echo HETONGNUMBER==1 ? 'readonly' : ''?> style="width:205px;"/>
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end--> 
<!--合同：欠款-->
<?php if($v['table_name']=='hetong'&&$v['name']=='qkmoney'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="qkmoney"&&$n["inuse"]=="是"){
$get_value = '';	
?>
<dl>
  <dt> 欠款 <font color="#F00">*</font></dt>
  <dd class="int_check nochange">
    <input name="qkmoney" type="text" value="<?php echo $get_value?>" class="input normal" datatype="/^-?[1-9]+(\.\d+)?$|^-?0(\.\d+)?$|^-?[1-9]+[0-9]*(\.\d+)?$/" style="width:165px;" readonly/>
    <span class="Validform_checktip">欠款自动计算</span> </dd>
</dl>
<script>
$("input[name='money']").on("change",function(){
var qknum = $("input[name='money']").val()-$("input[name='ysmoney']").val()
if((qknum.toString()).indexOf(".")!= -1) {
	qknum = (qknum).toFixed(2); //含有小数点
}
$("input[name='qkmoney']").val(qknum);
});
$("input[name='ysmoney']").on("change",function(){
var qknum = $("input[name='money']").val()-$("input[name='ysmoney']").val()
if((qknum.toString()).indexOf(".")!= -1) {
	qknum = (qknum).toFixed(2); //含有小数点
}
$("input[name='qkmoney']").val(qknum);
});
</script>
<?php }}}?>
<!--end--> 
<!--产品：缩略图-->
<?php if($v['table_name']=='chanpin'&&$v['name']=='pic'){
foreach($ziduan_biaodan as $arr=>$n) {
if($n["name"]=="pic"&&$n["inuse"]=="是"){
$get_value = '';
?>
<dl class="buguding">
  <dt> <?php echo $n['title'];?> <?php echo $n["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input id="pic_data" name="pic" type="hidden" value="<?php echo $get_value?>" class="input normal" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> />
    <span id="pic_view" class="picview"><img src="<?php echo $get_value?$get_value:'/themes/default/images/nopic.png'?>"></span>
    <button type="button" class="btn2 color1 layui-btn-danger" id="pic"><i class="fa fa-cloud-upload"></i>上传图片</button>
    <?php echo !empty($n["tip"]) ? '<span class="Validform_checktip">'.$n['tip'].'</span>' : ''?> </dd>
</dl>
<?php }}}?>
<!--end-->

<?php

}else{
		
if($v['type']=='text'){ //单行文本 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="<?php echo $v['name']?>" type="text" value="<?php echo $get_value?>" class="input normal" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> />
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<?php 
}else if($v['type']=='textarea'){ //多行文本 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <textarea name="<?php echo $v['name']?>" class="input" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> ><?php echo $get_value?></textarea>
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?></dd>
</dl>
<?php 
}else if($v['type']=='money'){ //金额 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="<?php echo $v['name']?>" type="text" value="<?php echo $get_value?>" class="input small" <?php echo $v['bitian']==1 ? 'datatype="/^-?[1-9]+(\.\d+)?$|^-?0(\.\d+)?$|^-?[1-9]+[0-9]*(\.\d+)?$/" errormsg="请输入正确的金额"' : ''?> />
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<?php 
}else if($v['type']=='yes'){ //是否 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <div class="rule-single-checkbox single-checkbox"><a href="javascript:;"><i class="on">否</i><i class="off">是</i></a>
      <input name="<?php echo $v['name']?>" type="text" value="<?php echo $get_value == '是' ? '是' : '否'?>" style="display: block;">
    </div>
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?></dd>
</dl>
<?php 
}else if($v['type']=='radio'){ //单选 
$get_value = '';
?>
<?php if(!empty($v['content'])){
    $selectres = explode("|",$v['content']);
	?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <div class="rule-multi-radio"><span>
      <?php foreach ($selectres as $key => $n) {?>
      <input id="<?php echo $v['name']?>_1" type="radio" name="<?php echo $v['name']?>" value="<?php echo $n?>" <?php echo $n == $get_value ? 'checked="checked"' : ''?> <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> />
      <label for="<?php echo $v['name']?>_1"><?php echo $n?></label>
      <?php }?>
      </span></div>
    <a class="btn1 color1 alert1" href="<?php echo site_url('ziduan/fastset')?>?id=<?php echo $v['id']?>" data-title="设置选项值" data-width="520" data-height="250"><i class="fa fa-plus-circle"></i>设置</a> <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?></dd>
</dl>
<?php 
    }else{
    echo '配置不能为空';
    }?>
<?php 
}else if($v['type']=='checkbox'){ //多选 
$get_value = '';
?>
<?php if(!empty($v['content'])){
    $ns = explode("|",$get_value);
    $selectres = explode("|",$v['content']);
	?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <div class="rule-multi-porp multi-porp">
      <ul>
        <?php foreach ($selectres as $key => $n) {?>
        <li <?php echo $n == $get_value ? 'class="selected"' : ''?>><a href="javascript:;"><?php echo $v['name']?></a><i class="fa-check-square-o-mark"></i></li>
      </ul>
      <?php }?>
      <span style="display:none;">
      <?php foreach ($selectres as $key => $n) {?>
      <input id="<?php echo $v['name']?>_1" name="<?php echo $v['name']?>[]" type="checkbox" value="<?php echo $n?>" <?php echo in_array($n, $ns) ? 'checked' : ''?> <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> >
      <label for="<?php echo $v['name']?>_1"><?php echo $n?></label>
      <?php }?>
      </span></div>
    <a class="btn1 color1 alert1" href="<?php echo site_url('ziduan/fastset')?>?id=<?php echo $v["id"]?>" data-title="设置选项值" data-width="520" data-height="250"><i class="fa fa-plus-circle"></i>设置</a> <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<?php }else{
    echo '配置不能为空';
    }?>
<?php 
}else if($v['type']=='select'){ //下拉 
$get_value = '';
?>
<?php if(!empty($v['content'])){
    $selectres = explode("|",$v['content']);
	?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">

      <select name="<?php echo $v['name']?>" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> >
        <option value="">请选择...</option>
        <?php foreach ($selectres as $key => $n) {?>
        <option value="<?php echo $n?>" <?php echo $n == $get_value ? 'selected' : ''?>><?php echo $n?></option>
        <?php }?>
      </select>

    <a class="btn1 color1 alert1" href="<?php echo site_url('ziduan/fastset')?>?id=<?php echo $v["id"]?>" data-title="设置选项值" data-width="520" data-height="250"><i class="fa fa-plus-circle"></i>设置</a> <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<?php
    }else{
      echo '配置不能为空';
    }?>
<?php 
}else if($v['type']=='datetime'){ //时间日期 
$get_value = '';
switch ($v['content'])
{
case "yyyy-MM-dd":
	 $get_value = date("Y-m-d",strtotime($get_value));
	 break;
	 
case "yyyy-MM-dd HH:mm":
	 $get_value = date("Y-m-d H:i",strtotime($get_value));
	 break;
	 
case "yyyy-MM-dd HH:mm:ss":
	 $get_value = date("Y-m-d H:i:s",strtotime($get_value));
	 break;
	 
default:
	 $get_value = $get_value;
}
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input name="<?php echo $v['name']?>" type="text" value="<?php echo $get_value?>" class="input rule-date-input" onfocus="WdatePicker({dateFmt:'<?php echo $v['content']?>'})" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> />
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?></dd>
</dl>
<?php 
}else if($v['type']=='area'){ //地区选择 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <div class="city-choose">
      <input name="<?php echo $v['name']?>" id="area_<?php echo $v['id']?>" class="form-control" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?> type="text" value="<?php echo $get_value?>" data-toggle="city-picker" readonly>
    </div>
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<script>              
$(function(){
var $area_<?php echo $v['id']?> = $('#area_<?php echo $v['id']?>');
});
</script>
<?php 
}else if($v['type']=='linkman'){ //客户联系人 
$get_value = '';
?>
<?php if(isset($cid)&&$cid>0){
$kehu_linkmans = $this->mysql_model->get_results('linkman', array('isdel' => 0, 'cid' => $cid));
?>
<dl>
  <dt> <?php echo $v['title'];?> <?php echo $v["bitian"]=="1" ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">

      <select name="<?php echo $v['name']?>" <?php if($v["bitian"]=="1"){?>datatype="*"<?php }?>>
        <option value="">请选择...</option>
        <?php foreach ($kehu_linkmans as $key => $n) {?>
        <option value="<?php echo $n['linkman']?>" <?php echo $n['linkman'] == $get_value ? 'selected' : ''?>><?php echo $n['linkman']?> - <?php echo $n['mobile']?></option>
        <?php }?>
      </select>

    <?php if ($this->common_model->check_lever(132)){?>
    <a class="btn1 color1 alert1" href="<?php echo site_url('linkman/add')?>?cid=<?php echo $cid?>" data-title="新增联系人" data-width="620" data-height="500"><i class="fa fa-plus-circle"></i>新增</a>
    <?php }?>
    <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?></dd>
</dl>
<?php
    }else{
      //echo '客户编号cid不存在';
 }?>
<?php 
}else if($v['type']=='upload'){ //单文件上传 
$get_value = '';
?>
<dl>
  <dt><?php echo $v['title']?> <?php echo $v['bitian']==1 ? '<font color="#F00">*</font>' : ''?> </dt>
  <dd class="int_check">
    <input id="<?php echo $v['name']?>_data" name="<?php echo $v['name']?>" type="hidden" value="<?php echo $get_value?>" class="input normal" <?php echo $v['bitian']==1 ? 'datatype="*"' : ''?>/>
    <span id="<?php echo $v['name']?>_view"><?php echo $get_value?></span>
    <button type="button" class="btn2 color1 layui-btn-danger" id="<?php echo $v['name']?>"><i class="fa fa-cloud-upload"></i>上传文件</button>
    <span class="layui-inline layui-word-aux"> 大小限制为<?php echo !empty($v["maxlimit"]) ? $v["maxlimit"] : '10'?>M </span> <?php echo !empty($v["tip"]) ? '<span class="Validform_checktip">'.$v['tip'].'</span>' : ''?> </dd>
</dl>
<?php }} }}?>
