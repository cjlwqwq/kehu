<?php
if (! defined('BASEPATH')) exit('No direct script access allowed');
include_once dirname(__FILE__).'/../../data/config.php';

$active_group = 'default';
$query_builder = TRUE;
$db = $db;