<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); 
define('USEQYWECHAT','1');
define('TOKEN','000');
define('ENCODINGAESKEY','000');
define('CORPID','000');
define('SECRET','000');
