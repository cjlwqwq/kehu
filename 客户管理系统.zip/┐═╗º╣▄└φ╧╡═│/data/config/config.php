<?php
$config['development'] = '1';