<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); 
define('MAIL_SMTP','smtp.exmail.qq.com');
define('MAIL_PORT','443');
define('MAIL_USER','test@126e.com');
define('MAIL_PWD','111');
define('MAIL_NAME','帮管客CRM');
