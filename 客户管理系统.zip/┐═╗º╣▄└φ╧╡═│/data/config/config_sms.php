<?php if(!defined('BASEPATH')) exit('No direct script access allowed'); 
define('SMS_SMSUSER','test2');
define('SMS_APIKEY','c9617018f689b0e391c813bd6');
